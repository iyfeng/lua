local hello = {}

require "Cocos2d"
require "extern"
require "MainScene"

-- cclog
cclog = function(...)
    print(string.format(...))
end

-- for CCLuaEngine traceback


function hello.newScene()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    
    require "hello2"
    cclog("result is " .. myadd(1, 1))
	
    ---------------
    local scene = cc.Scene:create()
    --local visibleSize = cc.Director:getInstance():getVisibleSize()
    --local origin = cc.Director:getInstance():getVisibleOrigin()

    local fonT = cc.LabelTTF:create("Sprite Test", "Verdana-BoldItalic", 20)
    fonT:setPosition(50,100)
    scene:addChild(fonT)
    local mainLayer = MainScene:createMS()
    --sprite:setPosition(visibleSize.width/2,visibleSize.height/2)
    --sprite:setPosition(0,0)
    scene:addChild(mainLayer)
    cc.Director:getInstance():replaceScene(scene)

    -- play background music, preload effect

    

end

return hello

--[[

]]--