function myadd(x, y)
    return x + y
end

function removeChildFromTable(table_name,value)
	for i,v in ipairs(table_name) do
		if v == value then
			table.remove(table_name,i)
		end
	end
end

function getCount(table_name)
	local count = 0
	for i,v in pairs(table_name) do
		count = count + 1
	end
	return count
end

function removeAll(table_name)
	for i,v in ipairs(table_name) do	
		table.remove(table_name,i)
	end
end

function tracebackex()
local ret = ""
local level = 2
ret = ret .. "stack traceback:\n"
while true do
   --get stack info
   local info = debug.getinfo(level, "Sln")
   if not info then break end
   if info.what == "C" then                -- C function
    ret = ret .. tostring(level) .. "\tC function\n"
   else           -- Lua function
    ret = ret .. string.format("\t[%s]:%d in function `%s`\n", info.short_src, info.currentline, info.name or "")
   end
   --get local vars
   local i = 1
   while true do
    local name, value = debug.getlocal(level, i)
    if not name then break end
    ret = ret .. "\t\t" .. name .. " =\t" .. tostringex(value, 3) .. "\n"
    i = i + 1
   end  
   level = level + 1
end
return ret
end

function tostringex(v, len)
if len == nil then len = 0 end
local pre = string.rep('\t', len)
local ret = ""
if type(v) == "table" then
   if len > 5 then return "\t{ ... }" end
   local t = ""
   for k, v1 in pairs(v) do
    t = t .. "\n\t" .. pre .. tostring(k) .. ":"
    t = t .. tostringex(v1, len + 1)
   end
   if t == "" then
    ret = ret .. pre .. "{ }\t(" .. tostring(v) .. ")"
   else
    if len > 0 then
     ret = ret .. "\t(" .. tostring(v) .. ")\n"
    end
    ret = ret .. pre .. "{" .. t .. "\n" .. pre .. "}"
   end
else
   ret = ret .. pre .. tostring(v) .. "\t(" .. type(v) .. ")"
end
return ret
end
