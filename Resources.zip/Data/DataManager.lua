local userDefault = cc.UserDefault:getInstance()

DataManager = {}  
function DataManager:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function DataManager:getInstance()  
    if self.instance == nil then  
        self.instance = self:new()
        self:init()  
    end  
    return self.instance  
end  

function DataManager:init()
  local sqlite3 = require("sqlite3")
  local path =  cc.FileUtils:getInstance():getWritablePath()
  self.db = sqlite3.open(path..'main.db')
  --表1，当前关卡，音乐状态，音效状态,生命数,最后时间
  self.db:exec[[
  CREATE TABLE IF NOT EXISTS main_tb (curLevel INTEGER,musicState INTEGER,soundState INTEGER);
  INSERT INTO main_tb VALUES ("1","1","1");
  ]]

  --表2，每个等级对应的分数，星星数
  self.db:exec[[
  CREATE TABLE IF NOT EXISTS level_tb (levelId INTEGER PRIMARY KEY,score INTEGER,star INTEGER);
  ]]  

  --表3，道具个数
  self.db:exec[[
  CREATE TABLE IF NOT EXISTS tool_tb (cntChange INTEGER,cntSame INTEGER,cntRow INTEGER,cntLine INTEGER);
  INSERT INTO tool_tb VALUES ("0","0","0","0");
  ]]
  
  --表4，任务关卡等级对应的分数，星星数
  self.db:exec[[
  CREATE TABLE IF NOT EXISTS task_tb (levelId INTEGER PRIMARY KEY,score INTEGER,star INTEGER);
  ]]
  

end  

--表1
function DataManager:mainTb() 
    return self.db:nrows("SELECT * FROM main_tb")
end

--表2
function DataManager:levelTb() 
    return self.db:nrows("SELECT * FROM level_tb")
end

--表3
function DataManager:toolTb() 
    return self.db:nrows("SELECT * FROM tool_tb")
end

--表4
function DataManager:taskTb() 
    return self.db:nrows("SELECT * FROM task_tb")
end

--获得当前关卡
function DataManager:getCurLevel()
  
  for row in self:mainTb() do
     return row.curLevel
  end
end

--获得当前音乐状态
function DataManager:getMusicState()
  for row in self:mainTb() do
    --print(row.musicState)
    return row.musicState
  end
end

--获得当前音效状态
function DataManager:getSoundState()
  for row in self:mainTb() do
    return row.soundState
  end
end


--更新当前关卡
function DataManager:updateCurLevel(levelTag)
  local updateStmt = assert(self.db:prepare("UPDATE main_tb SET curLevel = ? WHERE curLevel = main_tb.curLevel"))
  updateStmt:bind_values(levelTag)
  updateStmt:step()
  updateStmt:reset()
end

--更新当前关卡音乐状态
function DataManager:updateMusicState(levelTag)
  local updateStmt = assert(self.db:prepare("UPDATE main_tb SET musicState = ? WHERE musicState = main_tb.musicState"))
  updateStmt:bind_values(levelTag)
  updateStmt:step()
  updateStmt:reset()
end

--更新当前关卡音效状态
function DataManager:updateSoundState(levelTag)
  local updateStmt = assert(self.db:prepare("UPDATE main_tb SET soundState = ? WHERE soundState = main_tb.soundState"))
  updateStmt:bind_values(levelTag)
  updateStmt:step()
  updateStmt:reset()
end


--新增新一关分数，星星
function DataManager:addToLevelTb(score,star)
  local insertStmt = assert(self.db:prepare("INSERT INTO level_tb VALUES (NULL,?,?)"))
  insertStmt:bind_values(score,star)
  insertStmt:step()
  insertStmt:reset()
end

--获取关卡的分数和星星
function DataManager:getScore(levelID)  
  for row in self:levelTb() do
    if levelID == row.levelId then
      return row.score
    end
  end
end

function DataManager:getStar(levelID)  
  for row in self:levelTb() do
    if levelID == row.levelId then
      return row.star
    end
  end
end

--更新某一关卡的星星和分数
function DataManager:updateScoreAndStar(score,star,levelId)
  local updateStmt = assert(self.db:prepare("UPDATE level_tb SET score = ?,star = ? WHERE levelId = ?"))
  updateStmt:bind_values(score,star,levelId)
  updateStmt:step()
  updateStmt:reset()
end

--获取表2行数，即目前关卡树
function DataManager:getLevelFromLevelTb()
  local countStmt = assert(self.db:prepare("SELECT COUNT(1) FROM level_tb"))
  --countStmt:bind_values(score,star)
  countStmt:step()
  local r = countStmt:get_uvalues()
  return r
end


--新增任务新一关分数，星星
function DataManager:addToTaskTb(score,star)
  local insertStmt = assert(self.db:prepare("INSERT INTO task_tb VALUES (NULL,?,?)"))
  insertStmt:bind_values(score,star)
  insertStmt:step()
  insertStmt:reset()
end

--获取任务关卡的分数和星星
function DataManager:getTaskScore(levelID)  
  for row in self:taskTb() do
    if levelID == row.levelId then
      return row.score
    end
  end
end

function DataManager:getTaskStar(levelID)  
  for row in self:taskTb() do
    if levelID == row.levelId then
      return row.star
    end
  end
end


--获取表4行数，即任务关卡数
function DataManager:getLevelFromTaskTb()
  local countStmt = assert(self.db:prepare("SELECT COUNT(1) FROM task_tb"))
  --countStmt:bind_values(score,star)
  countStmt:step()
  local r = countStmt:get_uvalues()
  return r
end


---------获取和更新道具个数

function DataManager:getCntChange()  
  for row in self:toolTb() do
      return row.cntChange
  end
end

function DataManager:updateCntChange(cntChange)
  local updateStmt = assert(self.db:prepare("UPDATE tool_tb SET cntChange = ? WHERE cntChange = tool_tb.cntChange"))
  updateStmt:bind_values(cntChange)
  updateStmt:step()
  updateStmt:reset() 
end

function DataManager:getCntSame()  
  for row in self:toolTb() do
      return row.cntSame
  end
end

function DataManager:updateCntSame(cntSame)
  local updateStmt = assert(self.db:prepare("UPDATE tool_tb SET cntSame = ? WHERE cntSame = tool_tb.cntSame"))
  updateStmt:bind_values(cntSame)
  updateStmt:step()
  updateStmt:reset()
end

function DataManager:getCntRow()  
  for row in self:toolTb() do
      return row.cntRow
  end
end

function DataManager:updateCntRow(cntRow)
  local updateStmt = assert(self.db:prepare("UPDATE tool_tb SET cntRow = ? WHERE cntRow = tool_tb.cntRow"))
  updateStmt:bind_values(cntRow)
  updateStmt:step()
  updateStmt:reset()
end

function DataManager:getCntLine()  
  for row in self:toolTb() do
      return row.cntLine
  end
end

function DataManager:updateCntLine(cntLine)
  local updateStmt = assert(self.db:prepare("UPDATE tool_tb SET cntLine = ? WHERE cntLine = tool_tb.cntLine"))
  updateStmt:bind_values(cntLine)
  updateStmt:step()
  updateStmt:reset()
end


--重置 表
function DataManager:mainReset()
  self.db:exec("DELETE FROM main_tb;DROP TABLE IF EXISTS main_tb")
end

function DataManager:levelReset()
  self.db:exec("DELETE FROM level_tb;DROP TABLE IF EXISTS level_tb")
end

function DataManager:toolReset()
  self.db:exec("DELETE FROM level_tb;DROP TABLE IF EXISTS tool_tb")
end

function DataManager:taskReset()
  self.db:exec("DELETE FROM level_tb;DROP TABLE IF EXISTS tool_tb")
end

db = DataManager:getInstance()