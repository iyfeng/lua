LevelInfo = {}  
function LevelInfo:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function LevelInfo:getInstance(indexType)  
    if self.instance == nil or self.index ~= indexType then  
        self.instance = self:new()
        self.index = indexType
        self:initWithFile(indexType)  
    end  
    return self.instance  
end  

function LevelInfo:initWithFile(indexType)
  cclog(plistLevel,indexType)
  local plistFile
  if indexType == taskIndex then
    plistFile = cc.FileUtils:getInstance():fullPathForFilename(plistBigLevel)
  else
    plistFile = cc.FileUtils:getInstance():fullPathForFilename(string.format(plistLevel,indexType))
  end
  print(plistFile)
  self.dict = cc.FileUtils:getInstance():getValueVectorFromFile(plistFile)
end 

function LevelInfo:getVersion()
  local l = getClickedLevel()
  local version = tonumber(self.dict[l]["Version"])
  return version
end

function LevelInfo:getLevel()
  local l = getClickedLevel()
  local level = tonumber(self.dict[l]["Level"])
  return level
end


function LevelInfo:getMask()
  local l = getClickedLevel()
  local m = Split(self.dict[l]["Mask"],",")
  local mask = {}
  for i=1,MapHeight do
    mask[i] = {}
     for j=1,MapWidth do
       mask[i][j] = tonumber(m[j+(i-1)*MapWidth])
     end
  end 
  return mask
end

function LevelInfo:getDropRate()
  local l = getClickedLevel()
  local d = Split(self.dict[l]["DropRate"],",")
  local dropRate = {}
  for i=1,table.getn(d) do
    local tmp = Split(d[i],":")
    dropRate[i] = {}
    dropRate[i].basicType = tonumber(tmp[1])
    dropRate[i].blockType = tonumber(tmp[2])
    dropRate[i].blockRate = tonumber(tmp[3])
  end
  return dropRate
end

function LevelInfo:getScoreTarget()
  local l = getClickedLevel()
  local scores = Split(self.dict[l]["Score"],":")
  for i=1,3 do
    scores[i] = tonumber(scores[i])
  end
  return scores
end

function LevelInfo:getTarget(l)
  if l == nil then
    l = getClickedLevel()
  end
--  print("l",l)
  local target = Split(self.dict[l]["Target"],":")
  local targets = {typ = tonumber(target[1]),clicks = tonumber(target[2]),other = tonumber(target[3])}
  return targets
end

function LevelInfo:getHintPoint()
  local l = getClickedLevel()
  if self.dict[l]["HintPoint"] == nil or self.dict[l]["HintPoint"] == "" then
    return false
  end
  local hint = Split(self.dict[l]["HintPoint"],",")
  if hint == nil then
    return false
  else
    local hints = {}
    for i=1,table.getn(hint) do
    local tmp = Split(hint[i],":")
    hints[i] = cc.p(tmp[1],tmp[2])
    end
    return hints
  end
end

function LevelInfo:getMap()
  self:setMapInfo()

  local l = getClickedLevel()
  print("map l",l)
  local m = Split(self.dict[l]["Map"],",")
  local maps = {}
  for i=1,MapHeight+2*2 do
    maps[i] = {}
      for j=1,MapWidth+2*2 do
        maps[i][j] = {}
        if j == 1 or i == 1 or i == MapHeight + 2*2 or j == MapWidth +2*2 or
          j == 2 or i == 2 or i == MapHeight + 2*2-1 or j == MapWidth +2*2-1 
          then
          maps[i][j].basic = 0
          mapInfo[i][j].type = maps[i][j].basic
        else
          local k =  j-2+(i-3)*MapWidth        
          if string.find(m[k],":") == nil then
          maps[i][j].basic = tonumber(m[k])
          maps[i][j].hp = 0
          mapInfo[i][j].type = maps[i][j].basic
          mapInfo[i][j].hp = maps[i][j].hp 
          else
          local tmp = Split(m[k],":")
          maps[i][j].basic = tonumber(tmp[1])
          maps[i][j].hp = tonumber(tmp[2])
          mapInfo[i][j].type = maps[i][j].basic
          mapInfo[i][j].hp = maps[i][j].hp 
          end
        end
        if mapInfo[i][j].type == 6 then
          countBigBoss = countBigBoss + 1
        elseif mapInfo[i][j].type == 8 then
          countRecover = countRecover + 1
          table.insert(targetRecover,cc.p(i,j))
        elseif mapInfo[i][j].type == 9 then
          countWeakOther = countWeakOther + 1
          table.insert(targetWeakOther,cc.p(i,j))
        elseif mapInfo[i][j].type == 18 then
          countDoctor = countDoctor + 1
          table.insert(targetDoctor,cc.p(i,j))
        end
     end
  end
  self.countBigBoss = countBigBoss
  self.countRecover = countRecover
  self.countWeakOther = countWeakOther
  self.countDoctor = countDoctor

  return maps
end

function LevelInfo:getHintText()
  local l = getClickedLevel()
  print("check this")
  if self.dict[l]["HintText"] == nil then
    return false
  end
  local hint = Split(self.dict[l]["HintText"],":")
  if hint == nil then
    return false
  else
    local hints = Split(hint[2],"|")
    for i=1,10 do
      hints[i] = tonumber(hints[i])
    end
    return tonumber(hint[1]),hints
  end
end

function LevelInfo:setMapInfo()
  --mapInfo = {}
  targetRecover = {}
  targetWeakOther = {}
  targetDoctor = {}

  countGerm = 0 --普通细菌
  countBigBoss = 0 --大boss
  countRecover = 0 --回合后若未死亡，回满血
  countWeakOther = 0 --回合后使周围8个虚弱
  countDoctor = 0 --每回合可以恢复一定的生命值 
  for i=1,MapHeight + 4 do
  mapInfo[i] = {}
  for j=1,MapWidth + 4 do
    mapInfo[i][j] = {}
    if i == 2 and j > 2 and j < MapWidth + 3 then
      mapInfo[i][j].isEmpty = 1
    else
      mapInfo[i][j].isEmpty = 2
    end
    if i > 2 and i < MapHeight + 3 and j > 2 and j < MapWidth + 3 then
      mapInfo[i][j].tag = j - 2 + (i - 3)*MapWidth
    end
    mapInfo[i][j].moveflag = false
  end
  end
end

function LevelInfo:getMagicType()
  local l = getClickedLevel()
  local magicType = self.dict[l]["MagicGuide"]
  --print("magicType",magicType)
  if magicType == nil then
    return false
  else
    return tonumber(magicType)
  end
end

function LevelInfo:getReward()
  local l = getClickedLevel()
  local rew = Split(self.dict[l]["Reward"],":")
  --print("magicType",magicType)
  if rew == nil then
    return false
  else
    if rew[1] == 4 then rew[1] = 2 end
    local reward = {typ = tonumber(rew[1]),cnt = tonumber(rew[2])}
    return reward
  end
end