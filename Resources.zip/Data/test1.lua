Test1 = class("Test1")
Test1.__index = Test1
function Test1.create()
 local o = Test1.new()
 return o
end

function Test1:print1()
	print("test1 print")
end