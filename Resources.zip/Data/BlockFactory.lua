require "View/BasicBlock"
require "View/HpPanel"
require "View/BossBlock"
require "View/GermBlock"
require "View/BlockBlock"
require "View/WallBlock"
require "View/BoxBlock"
require "View/BigBossBlock"
require "View/GoodGermsBlock"
require "View/WeakOthersBlock"
require "View/RecoverBlock"
require "View/ReboundBlock"
require "View/PartBounceBlock"
require "View/BombBlock"
require "View/PipeBlock"
require "View/DoctorBlock"
require "View/GermsDirectionBlock"

BlockFactory = {}   

function BlockFactory:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o;  
end  
  
--[[
	BlockTypeNone =0,--无，地图里相当于空白
    BlockTypeGerms =1,--普通细菌
    BlockTypeBoss =2,--Boss
    BlockTypeBlock = 3,--障碍1
    BlockTypeWall = 4,--障碍，打不破
    BlockTypeBox = 5,--障碍2
    BlockTypeBigBoss = 6,--大boss
    BlockTypeGood = 7,--有益细菌，不能死亡，要保护
    BlockTypeRecover = 8,--回合后若未死亡，回满血
    BlockTypeWeakOther = 9,--回合后使周围8个虚弱
    BlockTypeRebound = 10,--细菌碰到后原路返回
    BlockTypePartBounceUp = 11,--碰撞后转90度
    BlockTypePartBounceLeft = 12,
    BlockTypePartBounceDown = 13,
    BlockTypePartBounceRight = 14,
    BlockTypeBomb = 15,--炸弹，由多个物品合成，不可预先配置
    BlockTypePipeLR = 16,//双向通过的管道,左右
    BlockTypePipeUD = 17,//上下通过的管道,左右
    BlockTypeDoctor = 18,//每回合可以恢复一定的生命值
    BlockTypeOther,//其他
    BlockTypeBasic//基本
}
]]--

local create_func = {
	{model = 	BasicBlock.create},
	{model = 	GermBlock.create},
	----[[
	{model = 	BossBlock.create},
	{model = 	BlockBlock.create},
	{model = 	WallBlock.create},
	{model = 	BoxBlock.create},
	{model = 	BigBossBlock.create},
	{model = 	GoodGermsBlock.create},
	{model = 	RecoverBlock.create},
	{model = 	WeakOthersBlock.create},
	{model = 	ReboundBlock.create},
	{model = 	PartBounceBlockUp.create},
	{model = 	PartBounceBlockLeft.create},
	{model = 	PartBounceBlockDown.create},
	{model = 	PartBounceBlockRight.create},
    {model =    BombBlock.create},
	{model = 	PipeBlock.create},
	{model = 	PipeBlock.create},
	{model = 	DoctorBlock.create}
	--]]--
}
function BlockFactory.create(basicType,germHp)  
    local factory = create_func[basicType+1].model(germHp) 
	return factory  
end  
 
  
