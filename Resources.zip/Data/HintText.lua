HintText = {}  
function HintText:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function HintText:getInstance()  
    if self.instance == nil  then  
        self.instance = self:new()
        self:initWithFile()  
    end  
    return self.instance  
end  

function HintText:initWithFile()
  local plistFile = cc.FileUtils:getInstance():fullPathForFilename(plistHint)
  self.dict = cc.FileUtils:getInstance():getValueVectorFromFile(plistFile)
end 

function HintText:getTexts()
	local text = {}
	for i=1,#self.dict do
		text[i] = {}
		text[i].key = tonumber(self.dict[i]["Key"])
		text[i].text = self.dict[i]["Text"]
	end
	return text
end

function HintText:getHintTextByKey(key)
	local text = self:getTexts()
	for i=1,#text do
		if text[i].key == key then
			return text[i].text
		end
	end
	return nil
end


hintText = HintText:getInstance()