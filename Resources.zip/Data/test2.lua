require "Data/test1"
Test2 = class("Test2",Test1.create())
Test2.__index = Test2
function Test2.create()
 local o = Test2.new()
 return o
end

function Test2:print1()
	self.super:print1()
	print("test2 print")
end