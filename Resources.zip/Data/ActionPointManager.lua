ActionPointManager = {}  
maxAP = 5
TimeToBack = 1800
TimeToBackTk =  40 --86400
local ud =cc.UserDefault:getInstance()
function ActionPointManager:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function ActionPointManager:getInstance()  
    if self.instance == nil  then  
        self.instance = self:new()
        self:init()  
    end  
    return self.instance  
end 

function ActionPointManager:init() 
	local lastUp = ud:getDoubleForKey("time")
	if lastUp == 0 then
		ud:setIntegerForKey("ap",maxAP)
		ud:setDoubleForKey("time",socket.gettime())
	end
	self:refreshAp()
end

function ActionPointManager:refreshAp()
	local ap = ud:getIntegerForKey("ap")
	if ap >= maxAP then
		ud:setIntegerForKey("ap",maxAP)
		return
	end
	local lastUp = ud:getDoubleForKey("time")
	local now = socket.gettime()
	local rt = now - lastUp
	while rt >= TimeToBack and ap < maxAP do
		rt = rt - TimeToBack
		lastUp = lastUp + TimeToBack
		ap = ap + 1
	end
	ud:setDoubleForKey("time",lastUp)
	ud:setIntegerForKey("ap",ap)
end

function ActionPointManager:getAp()
	self:refreshAp()
	return ud:getIntegerForKey("ap")
end

function ActionPointManager:isApFull()
	local ap = self:getAp()
	return ap >= maxAP
end

function ActionPointManager:getRemainTime()
	local lastUp = ud:getDoubleForKey("time")
	local now = socket.gettime()
	if now - lastUp >= TimeToBack then
		return 0 
	end
	return TimeToBack - (now - lastUp)
end

function ActionPointManager:useOne()
	self:refreshAp()
	local ap = ud:getIntegerForKey("ap")
	if ap <= 0 then
		return false
	end
	ap = ap - 1
	ud:setIntegerForKey("ap",ap)
	if ap == maxAP - 1 then
		ud:setDoubleForKey("time",socket.gettime())
	end
	return true
end

function ActionPointManager:addOne()
	self:refreshAp()
	local ap = ud:getIntegerForKey("ap")
	if ap >= maxAP then
		return 
	end
	ap = ap + 1
	ud:setIntegerForKey("ap",ap)
end

function ActionPointManager:add5Ap()
	self:refreshAp()
	local ap = ud:getIntegerForKey("ap")
	if ap >= maxAP then
		return 
	end
	ap = math.min(ap+5,maxAP)
	ud:setIntegerForKey("ap",ap)
end


function ActionPointManager:lastPassTimeToZero()
	ud:setDoubleForKey("timeTk",0)
end

function ActionPointManager:lastPassTime()
	ud:setDoubleForKey("timeTk",socket.gettime())
end

function ActionPointManager:getRemainTimeTk()
	local lastUp = ud:getDoubleForKey("timeTk")
	local now = socket.gettime()
	if now - lastUp >= TimeToBackTk then
		return 0 
	end
	return TimeToBackTk - (now - lastUp)
end

apM = ActionPointManager:getInstance()