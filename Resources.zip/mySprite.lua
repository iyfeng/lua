require "extern"

local function closeCallback()
        cc.Director:getInstance():endToLua()
end

MyMenu = class("MyMenu",
	function()
		return cc.Menu:create()
	end
	)
MyMenu.__index = MyMenu

MyMenu.type = 0
function MyMenu:createMS( filename1,filename2 )
	local myMenu = MyMenu.new()
	myMenu:myInit(filename1,filename2)
	return myMenu
end

function MyMenu:myInit( filename1,filename2)
	--local s = cc.Director:getInstance():getVisibleSize()
	local  CloseItem = cc.MenuItemImage:create(filename1,filename2)
	CloseItem:registerScriptTapHandler(closeCallback)
	--CloseItem:setPosition(s.width/2,s.height/2)
	CloseItem:setPosition(0,0)
	--self:setPosition(0,0)
	self:addChild(CloseItem)

end






