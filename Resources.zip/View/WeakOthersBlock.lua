WeakOthersBlock = {}  
WeakOthersBlock = class("WeakOthersBlock",
    function()
        return BasicBlock.create()
    end)
WeakOthersBlock.__index = WeakOthersBlock







function WeakOthersBlock.create(hp)
    local germ = WeakOthersBlock.new()
    germ:initWithHp(hp)
    return germ
end


function WeakOthersBlock:initWithHp(hp)
    self:setTexture(string.format(pngWeakOthers,1))
    self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function WeakOthersBlock:beHited( ... )
	local i,j = Map.getTileCoordinateFromSprite(self)
    gameScene = self:getParent():getParent()
    if self:smashed("weakHit",pngWeakOthers,"weakDie",0.7) == true then
       audio:playEffect("audio/SND014.mp3")
        countWeakOther = countWeakOther - 1
        removeFromTable(targetWeakOther,cc.p(i+2,j+2))
        local idx = gameScene.boss[3]
        gameScene.toGet[idx]:setText(countWeakOther)
        return 0.7
    end
    return 0.1
end

function WeakOthersBlock:result()
    GameState = GameStateDroping
    local pi,pj = Map.getTileCoordinateFromSprite(self)
    pi,pj = pi+2,pj+2
    audio:playEffect("audio/SND017.mp3")
    self:doAnimate(jsonAniBoss,"BossAnimation","weakLaugh",0.3,self:bossState(pngWeakOthers))
    local sp =  cc.Sprite:create(pngWeakEffect)
    sp:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self:addChild(sp)
    local scaleby = cc.ScaleBy:create(0.6,4)
    local fadeout = cc.FadeOut:create(0.6)
    local delay = cc.DelayTime:create(0.6)
    local function disappear()
        sp:removeFromParent()
    end
    local function reduce()
        for i=pi-1,pi+1 do
            
            for j=pj-1,pj+1 do
                local sprite = Map.getBlockSprite(self:getParent(),i,j)
                if sprite ~= nil and sprite:isGerm() == true then
                    sprite:reduceOneType()
                end
            end
        end
        
        print("WeakOthersBlock GameState2",GameState)
    end
    local disCall = cc.CallFunc:create(disappear)
    local redCall = cc.CallFunc:create(reduce)
    local seq = cc.Sequence:create(scaleby,fadeout,disCall,redCall)
    sp:runAction(seq)
    


end

