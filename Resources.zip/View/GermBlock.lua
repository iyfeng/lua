require "View/GermScore"
require "View/HintDialog"
GermBlock = {}  
GermBlock = class("GermBlock",
    function()
        return BasicBlock.create()
    end)
GermBlock.__index = GermBlock

local director = cc.Director:getInstance()
local scheduler = director:getScheduler()


local function getcondp(weight)
    local sum = 0
    local len = #weight
    for i=1,len do
        sum = sum + weight[i]
    end
    for i=1,len do
        weight[i] = weight[i]/sum
    end

    local sameArray = {}
    local diffArray = {}

    for i=1,len do
        for j = 1,len do
            local obj = {}
            obj.first = i
            obj.second = j
            obj.p = weight[i]*weight[j]
            if j == i then
                table.insert(sameArray,obj)
            else
                table.insert(diffArray,obj)
            end
        end
    end

    local ii = 1
    while ii <= #sameArray do
      if sameArray[ii].p <= 0 then
        table.remove(sameArray,ii)
      else
        ii = ii + 1
      end
    end
    -- for i=1,#sameArray do
    --     print("sameArray p ",sameArray[i].p)
    -- end
    while #sameArray > 1 do 
        math.randomseed(socket.gettime())
        local idx1 = math.random(#sameArray)
        local idx2 = math.random(#sameArray)
        while idx1 == idx2 do
            idx2 = math.random(#sameArray)
        end
        local min = math.min(sameArray[idx1].p,sameArray[idx2].p)
        sameArray[idx1].p = sameArray[idx1].p-min
        sameArray[idx2].p = sameArray[idx2].p-min
        local first = sameArray[idx1].first
        local second = sameArray[idx2].first
        for i=1,#diffArray do
            if diffArray[i].first == first and diffArray.second == second then
                diffArray[i].p = diffArray[i].p + min
            end
            if diffArray[i].first == second and diffArray.second == first then
                diffArray[i].p = diffArray[i].p + min
            end
        end
        local ii = 1
        while ii <= #sameArray do
          if sameArray[ii].p <= 0 then
            table.remove(sameArray,ii)
          else
            ii = ii + 1
          end
        end
    end

    local step = 0
    --print("sameArray p ",#sameArray)
    
    while #sameArray > 0 and sameArray[1].p > 0 and step < 5 do 
        math.randomseed(socket.gettime())
        local idx = math.random(#diffArray)
        while diffArray[idx].first == sameArray[1].first or diffArray[idx].second == sameArray[1].first do
            idx = math.random(#diffArray)
        end
        local min = math.min(sameArray[1].p,diffArray[idx].p/2)
        sameArray[1].p = sameArray[1].p - min
        diffArray[idx].p = diffArray[idx].p - min
        local first = sameArray[1].first
        local second = diffArray[idx].first
        local third = diffArray[idx].second
        for i=1,#diffArray do
            if diffArray[i].first == first and diffArray[i].second == third then
                diffArray[i].p = diffArray[i].p + min
            end
            if diffArray[i].first == second and diffArray[i].second == first then
                diffArray[i].p = diffArray[i].p + min
            end
        end 
        step = step+1
    end

    local condp = {}
    for i=1,len do 
        condp[i] = {}
        sum = 0
        for j=1,len do 
            if j == i then
                if sameArray[1] and sameArray[1].first == i then
                    condp[i][j] = sameArray[1].p 
                    sum = sum + condp[i][j]
                else
                    condp[i][j] = 0
                    sum = sum + condp[i][j]
                end
            else
                for k=1,#diffArray do 
                    if diffArray[k].first == i and diffArray[k].second == j then
                        condp[i][j] = diffArray[k].p
                        sum = sum + condp[i][j]
                        --print("condp",condp[i][j],i,j)
                        break
                    end
                end
            end
        end
        for j=1,len do
            if sum ~= 0 then
                condp[i][j] = condp[i][j]/sum
            end
            --print("condp",condp[i][j],i,j)
        end 
    end
    return condp
end




function GermBlock.create(type)
    local germ = GermBlock.new()
    germ:initWithItemType(type)
    return germ
end


GermBlock.GermsTypeNone = 0--空白的
GermBlock.GermsType1=1
GermBlock.GermsType2=2
GermBlock.GermsType3=3
GermBlock.GermsType4=4
GermBlock.GermsType5=5--随机生成一个，包括其他值




function GermBlock:initWithItemType(type)
    
    self.canTouch = false
    if type == self.GermsTypeNone or type == nil then
        --print("why type = 0")
        self.itemType = type
        return self
    end
    if type > self.GermsType5 then
        type = self.GermsType5
    end
    if type == self.GermsType5 then
        dpRate = lv:getDropRate()      
        local dpRateRate = {}
        local seeks = 0
        for i=1,#dpRate do
            seeks = seeks + dpRate[i].blockRate
            table.insert(dpRateRate,dpRate[i].blockRate)
        end
        randoms = 0
        condps = getcondp(dpRateRate)[lastGenerateGermsType]
        math.randomseed(socket.gettime())
        local seek = math.random()
        for i=1,#condps do           
            if seek > randoms and seek <= randoms + condps[i] then
                type = dpRate[i].blockType
                lastGenerateGermsType = type
                break
            else
                randoms = randoms + condps[i]
            end
        end
        --print("randoms",randoms,#condps,condps[1],condps[2],condps[3],condps[4])
        if randoms == 0 then
            seek = math.random(seeks)
            for i=1,#dpRate do
                if seek > randoms and seek <= randoms + dpRate[i].blockRate then
                    type = dpRate[i].blockType
                    lastGenerateGermsType = type
                    break
                else
                    randoms = randoms + dpRate[i].blockRate
                end
            end
        end
    end
    --self = self:init()
    --cclog("basic type %d",self.type)

    self.itemType = type
    self:setTexture(string.format(pngGerm,self.itemType))
    ----[[
    if self.itemType == self.GermsType4 then
        self.canTouch = true
        self:germ4Click()
    end
    --]]--
    --self.sprite = cc.Sprite:create(string.format(pngGerm,self.itemType))
    --self:addChild(self.sprite)
    
end

function GermBlock:updateOneType()
    self:doDieAnimate()
    self.itemType = self.itemType + 1
    if self.itemType == self.GermsType5 then
        self.itemType = 0
        self:createDirections(self)
        return
    end    
    
    --self:setTexture(pngNull)
    if self.itemType == self.GermsType4 then
        self.canTouch = true 
        self:germ4Click() 
    end
    --self:setTexture(string.format(pngGerm,self.itemType))

end

function GermBlock:updateToType4()
    
    self.itemType = self.GermsType4 
    self:setTexture(string.format(pngGerm,self.itemType))
    self.canTouch = true 
    self:germ4Click() 
end

function GermBlock:reduceOneType()   
    if self.itemType == self.GermsType1 or self.itemType == self.GermsTypeNone then
        return
    end
    self.canTouch = false
    self.itemType = self.itemType - 1
    self:setTexture(string.format(pngGerm,self.itemType))
end

function GermBlock:doDieAnimate()
    if self.itemType <= self.GermsType3 and self.itemType >= self.GermsType1 then
        self:doAnimate(jsonAniGerm,"GermAnimation",string.format("aniGerm%d",self.itemType),0.166,string.format(pngGerm,self.itemType+1))
    end
end


function GermBlock:germ4Click()
    local function onTouchBegan(touch, event)
        --local target = tolua.cast(event:getCurrentTarget(),"cc.Sprite")
        --print("GameState",GameState)
        local gameScene = self:getParent():getParent()
        local locationInNode = self:convertToNodeSpace(touch:getLocation())
        local s = self:getContentSize()
        local rect = cc.rect(0, 0, s.width, s.height)

        --local i,j = Map.getTileCoordinateFromPos(target:getParent():getLayer("layer"),locationInNode)
        --print("maoInfo isEmpty hp type tag",mapInfo[i+2][j+2].isEmpty,mapInfo[i+2][j+2].hp,mapInfo[i+2][j+2].type,mapInfo[i+2][j+2].tag)
        if GameState == GameStateDroping then
            Map.dirTime = 0.05
            return true
        end

        local hints = lv:getHintPoint()
        local magicType = lv:getMagicType()
        if hints ~= false and hints[havStep+1] ~= nil and magicType == false then
           -- print("first setp 222")
            local i,j = hints[havStep+1].y,hints[havStep+1].x
            i,j = i+3,j+3
            local i1,j1 = Map.getTileCoordinateFromSprite(self)
            i1,j1 = i1+2,j1+2
            if not (i1 == i and j1 == j) then
                --print("first setp 111")
                return false
            end
        end

        if magicType ~= false and havStep == 0 and gameScene.firstStep == nil and gameScene.magHintFlag == true then
            return false
        else
            print("m,h,g",magicType,havStep,gameScene.MagicClicked)
        end

        if self.canTouch == false then
            return false
        end
        
        if GameState ~= GameStateWaiting then
            --print("GameState",GameState)
            return false
        end
        if cc.rectContainsPoint(rect, locationInNode) then
            --print("GameState",GameState)
            self:stopAllActions()
            if gameScene.hintsp then
                gameScene.hintsp:stopAllActions()
            end
            if gameScene.entry ~= nil then
                scheduler:unscheduleScriptEntry(gameScene.entry)
                gameScene.entry = nil
            end
            local i,j = Map.getTileCoordinateFromSprite(self)
            local mapbg = self:getParent()
            local gameScene = self:getParent():getParent()

            local co = coroutine.create(function()
            if not (getClickedIndex() == 1 and getClickedLevel() <= 5) then   
                if self:isH() ~= 0 or self:isV() ~= 0 or self:isS()~= 0 then
                    Map.existBomb = true
                    Map.BombI = i + 2
                    Map.BombJ = j + 2 
                    Map.bombH,Map.bombHI = self:isH()
                    Map.bombV,Map.bombVI = self:isV()
                    Map.bombS,Map.bombSI = self:isS()
                    --Map.bombType = Map.bombH + Map.bombV + Map.bombS
                end
            end
            coroutine.yield()
            end)
            coroutine.resume(co)
            gameScene.numClicks = gameScene.numClicks-1

            --已使用步数+1
            havStep = havStep + 1 
            print("havStep",havStep)
            if havStep == 1 then
                apM:useOne()
            end
            if gameScene:getChildByTag(5000) ~= nil then
                print("havStep",havStep)
                gameScene:getChildByTag(5000):disappear()
            end


            if gameScene:getChildByTag(5002) ~= nil then
                gameScene:getChildByTag(5002):removeFromParent()
            end

            gameScene.clicks:setText(gameScene.numClicks)
            germScore = 90
            self:createDirections(self)  
            GameState = GameStateExploding

            if gameScene.hintsp ~= nil then
                --print(gameScene.hintsp:getDescription())
                gameScene.hintsp = nil
                gameScene.hintExist = nil
            end         
            return true
        end
        return false
    end

    local function onTouchMoved(touch, event)
        cclog("grem moved")
    end

    local function onTouchEnded(touch, event)
        --local target = tolua.cast(event:getCurrentTarget(),"cc.Sprite")
        cclog("germ ended")
    end

    local listener1 = cc.EventListenerTouchOneByOne:create()
    listener1:setSwallowTouches(true)
    listener1:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    listener1:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    listener1:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener1, self)
end

function GermBlock:createDirections(target)
    audio:playEffect("audio/SND006.mp3")
    self:updateCount()
    germScore = germScore + 10
    totalScore = totalScore + germScore
    parent = target:getParent()
    gameScene = parent:getParent()
    parent:addChild(GermScore.create(germScore,target))
    gameScene:updateScoreBar()
    for i = 0,3 do
        local germDir = GermsDirectionBlock.create(i)
        germDir:setInfo(target)
        germDir:setTag(i+1000)
        target:getParent():addChild(germDir)
        germDir:setLocalZOrder(dirZOrder)
        --print("pos ",i,germDir:getPos())
        germDir:flyTo()
    end
    local i,j = Map.getTileCoordinateFromSprite(self)
   -- print("i,j,hp",mapInfo[i+2][j+2].hp,i,j)
    parent = target:getParent()
    --target:setTexture(pngNull)
    effect:doAnimation(target,parent,"bb",0.133)
    target:removeFromParent()

    if gameScene.hintsp ~= nil then
        --print(gameScene.hintsp:getDescription())
        gameScene.hintsp = nil
        gameScene.hintExist = nil
    end 
    --[[
    local function remove()
        target:removeFromParent()
    end
    remBack = cc.CallFunc:create(remove)
    delay = cc.DelayTime:create(0.133)
    target:runAction(cc.Sequence:create(delay,remBack))
    ]]--
    mapInfo[i+2][j+2].hp = 0
    mapInfo[i+2][j+2].isEmpty = 1
    
end

function GermBlock:updateCount()
    --如果为消灭个数

    if lv:getTarget().typ == 3 then  
        countGerm = countGerm - 1
        if countGerm >= 0 then
            self:getParent():getParent().toGet[1]:setText(countGerm)
        end
    end

end

function GermBlock:checkIsH(p)
    local i,j = Map.getTileCoordinateFromSprite(self)
    i,j = i+2,j+2
    local isH = true
    if j-p < 3 then
        return false
    end
    for k=j-p,j-p+3 do
        if Map.getBlockSprite(self:getParent(),i,k) == nil then
            return false
        end
        isH = Map.getBlockSprite(self:getParent(),i,k):isType4() and isH
    end
    return isH
end

function GermBlock:checkIsV(p)
    local i,j = Map.getTileCoordinateFromSprite(self)
    i,j = i+2,j+2
    local isV = true
    if i-p < 3 then
        return false
    end
    for k=i-p,i-p+3 do
        if Map.getBlockSprite(self:getParent(),k,j) == nil then
            return false
        end
        isV = Map.getBlockSprite(self:getParent(),k,j):isType4() and isV
    end
    return isV
end

function GermBlock:checkIsS(pi,pj)
    local i,j = Map.getTileCoordinateFromSprite(self)
    i,j = i+2,j+2
    local isS = true
    if j-pj < 3 then
        return false
    end
    if i-pi < 3 then
        return false
    end
    for k=i-pi,i-pi+1 do
        for l=j-pj,j-pj+1 do
            if Map.getBlockSprite(self:getParent(),k,l) == nil then
                return false
            end
            isS = Map.getBlockSprite(self:getParent(),k,l):isType4() and isS
        end
    end
    return isS
end

function GermBlock:isH()
    for i=0,3 do
        if self:checkIsH(i) then
            
            return 1,i
        end
    end
    return 0
end

function GermBlock:isV()
    for i=0,3 do
        if self:checkIsV(i) then
            return 2,i
        end
    end
    return 0
end

function GermBlock:isS()
    local p = {cc.p(1,1),cc.p(0,1),cc.p(1,0),cc.p(0,0)}
    for i=1,4 do
        if self:checkIsS(p[i].x,p[i].y) then
            return 4,i
        end
    end
    return 0
end

function GermBlock:useTool(tlType)
    local function onTouchBegan(touch, event)
        local locationInNode = self:convertToNodeSpace(touch:getLocation())
        local s = self:getContentSize()
        local rect = cc.rect(0, 0, s.width, s.height)
        local gameScene = self:getParent():getParent()
        magic = gameScene:getChildByTag(2500)
        if GameState ~= GameStateTool then
            --print("GameState",GameState)
            return false
        end

        local hints = lv:getHintPoint()
        local magicType = lv:getMagicType()
        if hints ~= false and hints[1] ~= nil and magicType ~= false and havStep == 0 and gameScene.firstStep == nil and gameScene.magHintFlag  == true then

            
            local i,j = hints[1].y,hints[1].x
            i,j = i+3,j+3
            local i1,j1 = Map.getTileCoordinateFromSprite(self)
            i1,j1 = i1+2,j1+2
            if not (i1 == i and j1 == j) then
                --print("first setp")
                return false
            end
        end

        --print(magic.cancelBtn:getDescription(),magic.magicLabel:getDescription())
        if cc.rectContainsPoint(rect, locationInNode) then 
            GameState = GameStateExploding  -- set this state not for the meaning but let other germs can not be clicked.   
            --print("magic",magic.magicLabel)
            --if magic.magicLabel then
                magic.magicLabel:setVisible(false)
            --end
            magic.cancelBtn:setVisible(false)
            magic:getChildByTag(100):setVisible(false)
            
            gameScene.firstStep = true

            if gameScene:getChildByTag(5002) ~= nil then
                print("child moved 5002")
                gameScene:getChildByTag(5002):removeFromParent()
            else
                print("child moved error 5002")
            end

            if gameScene:getChildByTag(5003) ~= nil then
                print("child moved 5003")
                gameScene:getChildByTag(5003):removeFromParent()
            else
                print("child moved error 5003")
            end

            if tlType == magicSame then
                gameScene:magicCleanSame(magic.magicTool,self)
            elseif tlType == magicRow then
                gameScene:magicCleanRow(magic.magicTool,self)
            elseif tlType == magicLine then
                gameScene:magicCleanLine(magic.magicTool,self)
            elseif tlType == magicCross then
                gameScene:magicToCross(magic.magicTool,self)
            end
            return true
        end
        return false
    end
    local function onTouchMoved(touch, event)
        cclog("germ moved")
    end

    local function onTouchEnded(touch, event)
        --local target = tolua.cast(event:getCurrentTarget(),"cc.Sprite")
        cclog("germ ended")
    end


    local eventDispatcher = self:getEventDispatcher()
    if self.listener1 then
        eventDispatcher:removeEventListener(self.listener1)
    end
    self.listener1 = cc.EventListenerTouchOneByOne:create()
    self.listener1:setSwallowTouches(true)
    self.listener1:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    self.listener1:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    self.listener1:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
    
    eventDispatcher:addEventListenerWithSceneGraphPriority(self.listener1, self)
end