



local director = cc.Director:getInstance()
local winSize = director:getWinSize()

HintDialog = class("HintDialog")
HintDialog.__index = HintDialog
HintDialog._pointType = nil

function HintDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, HintDialog)
    return target
end

--tag
hGirl = 151
hdlgBar = 152
hHiText = 153
hRuleBar = 154




function HintDialog:init()
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonHintDlg)
	self:addChild(self._widget)
	self.girl = self._widget:getChildByTag(hGirl)
	self.girl:setPositionType(ccui.PositionType.absolute)
	self.dlgBar = self._widget:getChildByTag(hdlgBar)	
	self.hiText = self.dlgBar:getChildByTag(hHiText)
	self.ruleBar = self._widget:getChildByTag(hRuleBar)
	self.ruleBar:setVisible(false)
	self.girlPos = cc.p(self.girl:getPosition())
	self.dlgBarPos = cc.p(self.girl:getPosition())
	self.preGPos = cc.p(-self.girlPos.x/2,self.girlPos.y)
	--self.preBPos = cc.p(self.dlgBarPos.x/2,-self.dlgBarPos.y/2)

end

function HintDialog:appear(text)
	self.ruleBar:setVisible(false)
	self.girl:setVisible(true)
	self.dlgBar:setVisible(true)
	self.girl:setPositionType(ccui.PositionType.absolute)
	self.girl:setPosition(self.preGPos)
	self.dlgBar:setScale(0.0)
	self.dlgBar:setRotation(-30)
	self.hiText:setText(text)
	self.girl:runAction(cc.MoveTo:create(0.3,self.girlPos))
	local big = cc.ScaleTo:create(0.1,1)
	local rota = cc.RotateBy:create(0.2,30)
	local delay = cc.DelayTime:create(0.3)
	self.dlgBar:runAction(cc.Sequence:create(delay,big,rota))
end

function HintDialog:disappear()
	
	self.girl:runAction(cc.MoveTo:create(0.3,self.preGPos))
	--self.girl:setVisible(false)
	local function dlgBarMiss()
		self.dlgBar:setVisible(false)
		self.girl:setVisible(false)
		self:setHintInfo()
	end
	local dMiss = cc.CallFunc:create(dlgBarMiss)
	local small = cc.ScaleTo:create(0.1,0.01)
	local delay = cc.DelayTime:create(0.1)
	
	self.dlgBar:runAction(cc.Sequence:create(small,delay,dMiss))
end

function HintDialog:setHintInfo()
	local hintExist,hints = lv:getHintText()
	if hintExist == false then return end

	self.ruleBar:setVisible(true)
	print(#hints)

	if self.ruleBar:getChildByTag(500) == nil then
		local hiLine = ccui.ImageView:create()
		hiLine:loadTexture(pngNull)
		hiLine:setTag(500)
		
		local barW = self.ruleBar:getContentSize().width/80
		local n = #hints
		local origin = 0
		for i=1,n do
			print("hints",hints[i])
			local sp = self:getSpriteById(hints[i],hiLine)
			local scale = sp:getScale()
			local spW = sp:getContentSize().width*scale			
			sp:setPositionX(origin)
			origin = origin + spW + barW
			--hiLine:addChild(sp,0,i+200)
		end
		local barH = self.ruleBar:getContentSize().height
		hiLine:setPosition(-(origin-barW)/2,-0.05*barH)
		self.ruleBar:addChild(hiLine)
	end
end

function HintDialog:getSpriteById(id,parent)
	local sp
	local sca
	if id > 0 and id <= 17 then
		sp = ccui.ImageView:create()
		sp:loadTexture(string.format(pngHi,id))
		sca = 1
	elseif id > 116 and id <= 123 then
		sp = BombBlock.createGui(id-116)
		sca = 1.5
	end

	if sp ~= nil then
		local spH = sp:getContentSize().height
		local spW = sp:getContentSize().width
		local parentH = parent:getContentSize().height
		--local parentW = parent:getContentSize().width
		--local scaleY = parentH/spH/3
		if id == 11 then
			local scaleX = parentH/spW/8.5 * sca
			--sp:setScaleY(scaleY)
			sp:setScale(scaleX)
		elseif id == 10 then
			local scaleY = parentH/spH/8 * sca
			sp:setScale(scaleY)
			--sp:setScaleX(scaleY*4)
		else
			local scaleY = parentH/spH/5 * sca
			sp:setScale(scaleY)
		end

		--sp:setPositionY(-spH/2)
		parent:addChild(sp)
	end
	return sp
end

function HintDialog.create(text)
	if text == nil then return end
	local dlg = HintDialog.extend(cc.Layer:create())
	dlg:init()
	dlg:setTag(5000)
	dlg:setLocalZOrder(300)
	return dlg
end