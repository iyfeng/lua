

local director = cc.Director:getInstance()
local schedule = director:getScheduler()

ActionPoint = class("ActionPoint")
ActionPoint.__index = ActionPoint
ActionPoint._pointType = nil

function ActionPoint:init(parent)
	--db:updateActionPoint(5)
	lives = apM:getAp()
	--self:loadTexture(pngHeart)
	local heart = parent:getChildByName("heart")
	local heartScale = heart:getScale()

	
	--爱心数
	self.labelAtlas = heart:getChildByName("num")
	--self.labelAtlas:setFontName(fontName)
	self.labelAtlas:setFontSize(30)
	self.labelAtlas:setText(string.format("%d",lives))

	--时间
	self.timeback = parent:getChildByName("timeback")

	self.timeAtlas = self.timeback:getChildByName("time")
	self.timeAtlas:setFontName(fontName)


	self:updateTime()



    heart:setTouchEnabled(true)
	local function refillCallBack(sender,event)
		local toBig = cc.ScaleTo:create(0.1,1.1*heartScale)
		local toSmall = cc.ScaleTo:create(0.1,heartScale)
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			local function refillDlg()
				if self._clicked == nil then
					self._clicked = false
					cclog("can be clicked and dlg will be called here")
					if apM:getAp() <= 0 then
						addMaskBg(heart:getParent():getParent())
						local dlg = MoreLivesDialog1.create(self)
   						heart:getParent():getParent():addChild(dlg)
   					else
   						self._clicked = nil
   					end
				else
					cclog("can not click again")
				end
				if apM:getAp() > 0 then
					apM:useOne()
				end
				if apM:isApFull() then
					apM:add5Ap()
				end
				self:updateLives()
			end
			--self:runAction(cc.Sequence:create(cc.MoveTo:create(0.6,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(refillDlg)))
			refillDlg()
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	heart:addTouchEventListener(refillCallBack)
	--parent:addChild(self,5000)

	--self.entry = schedule:scheduleScriptFunc(updateTimes,0.1,false)
end

function ActionPoint:getTimeVisible(lives)
	if apM:isApFull() then
		self.timeback:setVisible(false)
		return false
	else
		self.timeback:setVisible(true)
		return true
	end
end


function ActionPoint:updateLives(lives)
	if lives == nil then
		lives = apM:getAp()
	end
	self.labelAtlas:setText(string.format("%d",lives))
	return self:getTimeVisible(lives)
end

function ActionPoint:updateTime()
	if self:updateLives() == false then return end 
	local time = apM:getRemainTime()
	--print("time",time)
	local min = math.floor(time/60)
	local sec = time%60
	local mins = min > 9.5 and string.format("%d",min) or string.format("0%d",min)
	local secs = sec > 9.5 and string.format("%d",sec) or string.format("0%d",sec)
	local timeTxt = string.format("%s:%s",mins,secs)
	self.timeAtlas:setText(timeTxt)
end




function ActionPoint.create(parent)
	local point = ActionPoint.new()
	point:init(parent)
	--point:registerScriptHandler(point.onExit)
	return point
end


