--Add particleFile here
--with follows formating
--parXXXX = "particle/XXXX.plist"
parLevelUnlock = "particle/levelUnlock.plist"
parLevelWin = "particle/levelWin.plist"
parLivesHeal = "particle/livesHeal.plist"
parPartUnclock = "Particle/partUnclock.plist"
parRecoverHp = "particle/recoverHp.plist"
parScoreToBomb = "particle/scoreToBomb.plist"
parTouchHint = "particle/touchHint.plist"
parLock1 = "particle/unclock1.plist"


EffectManager = {}  
function EffectManager:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function EffectManager:getInstance()  
    if self.instance == nil then  
        self.instance = self:new()
        self:init()  
    end  
    return self.instance  
end  

function EffectManager:init()
  self.armTag = 2000
  self.armature = nil
  self.sjtarmature = nil
end

function EffectManager:doAnimationWithFile(fileName,armatureName,parent,layer,animationName,time,armTag)
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(fileName)
    local armature =  ccs.Armature:create(armatureName)
    armature:getAnimation():play(animationName)
    
    if parent.getWorldPosition then
      armature:setPosition(parent:getWorldPosition())
    else
      armature:setPosition(parent:getPosition())
      armature:setScale(parent:getScale())
    end
    
    layer:addChild(armature,2,armTag)
    local function remove()
        if layer:getChildByTag(armTag) ~= nil then
            layer:removeChildByTag(armTag)
        end
    end
    rem = cc.CallFunc:create(remove)
    delay = cc.DelayTime:create(time)
    layer:runAction(cc.Sequence:create(delay,rem))
    return armature
end

function EffectManager:doAnimation(parent,layer,animationName,time)
  self.armature = self:doAnimationWithFile(jsonAniEffect,"EffectAnimation",parent,layer,animationName,time,2000)
end

function EffectManager:doSjtAnimation(parent,layer,animationName,time)
  self.sjtarmature = self:doAnimationWithFile(jsonAniSjt,"sjtAnimation",parent,layer,animationName,time,2001)
end


function EffectManager:getParticleWithFile(layer,parent,fileName)
  local particle = cc.ParticleSystemQuad:create(fileName)
-- particle:setTag(10086)
  if parent.getWorldPosition then
    particle:setPosition(parent:getWorldPosition())
    --print("particleWorldPos:",parent:getWorldPosition())
  else
    particle:setPosition(parent:getPosition())
    --print("particlePos:",parent:getPosition())
  end
  layer:addChild(particle,100,10086)
  particle:setAutoRemoveOnFinish(true)
  return particle
end

function EffectManager:setParticleForLevelUnlock(layer,parent)
  --self:getParticleWithFile(layer,parent,parLevelUnlock)
  local particle = self:getParticleWithFile(layer,parent,parLevelUnlock)
  -- particle:setScale(parent:getScaleX())
end

--主界面，大房间粒子
function EffectManager:setParticleForTouchHint(layer,parent)
  local particle = self:getParticleWithFile(layer,parent,parTouchHint)
--   print(parent:getContentSize().width,parent:getContentSize().height)
-- print(parent:getContentSize().width*parent:getScaleX(),parent:getContentSize().height*parent:getScaleY())
  -- particle:setPosVar(cc.p(parent:getContentSize().width*parent:getScaleX(),parent:getContentSize().height*parent:getScaleY()))
  particle:setPosVar(cc.p(100,120))
end

--进入房间后，大关卡的粒子
function EffectManager:setParticleForPart(layer,parent)
  local particle = self:getParticleWithFile(layer,parent,parTouchHint)
  particle:setStartSize(20)
  particle:setEndSize(10)

end

-- 第16关粒子
function EffectManager:setParticleForLevel(layer,parent)
  local particle = self:getParticleWithFile(layer,parent,parTouchHint)
  particle:setStartSize(20)
  particle:setEndSize(10)
end