PartBounceBlock = {}  
PartBounceBlock = class("PartBounceBlock",
    function()
        return BasicBlock.create()
    end)
PartBounceBlock.__index = PartBounceBlock

function PartBounceBlock.create(hp)
    local germ = PartBounceBlock.new()
    germ:initWithHp(hp)
    return germ
end


function PartBounceBlock:initWithHp(hp)
    self:setTexture(pngNull)
    self.boun = cc.Sprite:create(pngPartBoun)
    self.bounce = cc.Sprite:create(pngPartBounce)
    self.boun:setAnchorPoint(0.5,0)
    self.bounce:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self.boun:setPosition(self:getContentSize().width/2,0)
    self.bounce:setTag(11)
    self.boun:setTag(10)
    self:addChild(self.bounce)
    self:addChild(self.boun)
end
local co
function PartBounceBlock:beHited()
	--self:removeAllChildrenWithCleanup(false)
	local scaleBy = cc.ScaleBy:create(0.03,0.8)
	local moveBy = cc.MoveBy:create(0.03,cc.p(0,-4))
    audio:playEffect("audio/SND007.mp3")
	co = coroutine.create(function ()
		self.boun:runAction(cc.Sequence:create(scaleBy,scaleBy:reverse()))
		self.bounce:runAction(cc.Sequence:create(moveBy,moveBy:reverse()))
		coroutine.yield()
	end)
	coroutine.resume(co)
	
end

function PartBounceBlock:set_Rotation(dir)
	self:setRotation(dir)
end

PartBounceBlockUp = {}  
PartBounceBlockUp = class("PartBounceBlockUp",
    function()
        return PartBounceBlock.create()
    end)
PartBounceBlockUp.__index = PartBounceBlockUp

function PartBounceBlockUp.create(hp)
    local germ = PartBounceBlockUp.new()
    germ:initWithHp(hp)
    germ:set_Rotation(-45)
    return germ
end


PartBounceBlockLeft = {}  
PartBounceBlockLeft = class("PartBounceBlockLeft",
    function()
        return PartBounceBlock.create()
    end)
PartBounceBlockLeft.__index = PartBounceBlockLeft

function PartBounceBlockLeft.create(hp)
    local germ = PartBounceBlockLeft.new()
    germ:initWithHp(hp)
    germ:set_Rotation(-135)
    return germ
end

PartBounceBlockDown = {}  
PartBounceBlockDown = class("PartBounceBlockDown",
    function()
        return PartBounceBlock.create()
    end)
PartBounceBlockDown.__index = PartBounceBlockDown

function PartBounceBlockDown.create(hp)
    local germ = PartBounceBlockDown.new()
    germ:initWithHp(hp)
    germ:set_Rotation(135)
    return germ
end

PartBounceBlockRight = {}  
PartBounceBlockRight = class("PartBounceBlockRight",
    function()
        return PartBounceBlock.create()
    end)
PartBounceBlockRight.__index = PartBounceBlockRight

function PartBounceBlockRight.create(hp)
    local germ = PartBounceBlockRight.new()
    germ:initWithHp(hp)
    germ:set_Rotation(45)
    return germ
end

