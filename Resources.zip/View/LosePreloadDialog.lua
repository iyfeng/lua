require "View/ExchangeMagicDialog"

local director = cc.Director:getInstance()
local winSize = director:getWinSize()

LosePreDlg = class("LosePreDlg")
LosePreDlg.__index = LosePreDlg
LosePreDlg._pointType = nil

function LosePreDlg.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, LosePreDlg)
    return target
end

function LosePreDlg:init(levelType)
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonLosePreDlg)
	self:addChild(self._widget)
	local background = self._widget:getChildByTag(dlgBg)
	local endBtn = background:getChildByTag(dlgEndGame)
	local addMvsBtn = background:getChildByTag(dlgAddMoves)
	
	local toBig1 = cc.ScaleBy:create(0.7,0.97,1.02)
	local toSmall1 = toBig1:reverse()
	local bigSmallRepeat = cc.Sequence:create(toBig1,toSmall1)
	addMvsBtn:runAction(cc.RepeatForever:create(bigSmallRepeat))
	

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local gameScene = self:getParent()
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:getParent()._clicked = false
				self:removeFromParent()
				gameScene:addChild(LoseDialog.create(levelType))
			end
			--self:runAction(cc.Sequence:create(cc.MoveTo:create(0.6,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
			self:runAction(cc.CallFunc:create(destroy))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	endBtn:addTouchEventListener(closeCallBack)


	local function playCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local gameScene = self:getParent()
		audio:playEffect("audio/SND008.mp3")
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local dlg = ExchangeMagicDialog.create(5,self)
			local function replaceSce()
				self:getParent()._clicked = false
	    		self = nil
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(replaceSce)))
			self:getParent():addChild(dlg)

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	addMvsBtn:addTouchEventListener(playCallBack)
	
end


function LosePreDlg.create(levelType)
	local dlg = LosePreDlg.extend(cc.Layer:create())
	dlg:init(levelType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	audio:playEffect("audio/XL003.mp3")
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(1000)
	return dlg
end