

LevelPoint = class("LevelPoint")
LevelPoint.__index = LevelPoint
LevelPoint._pointType = nil




function LevelPoint.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, LevelPoint)
    return target
end

function LevelPoint:init(levelType,levelId )
	if levelType == totalLevel + 1 then
		self:loadTexture(pngSpNext)
	else
		--print("lll",levelType)
		self:loadTexture(string.format(pngSpPlayed,lv:getTarget(levelType).typ + 1))
		local labelAtlas = ccui.TextField:create()
		labelAtlas:setFontName(fontName)
    	labelAtlas:setFontSize(32)
    	labelAtlas:setPositionType(ccui.PositionType.percent)
    	labelAtlas:setPositionPercent(cc.p(0,0.1))
    	labelAtlas:setText(string.format("%d",levelId))
    	starCnt = db:getInstance():getStar(levelId)

    	if levelId > taskIndex then
    		labelAtlas:setText(string.format("%d",levelId-taskIndex))
    		starCnt = db:getInstance():getTaskStar(levelType)
    	end

	    if starCnt ~= nil then
		    for i=1,starCnt do
		    	self:addStar(i,false)
		    end 
	    end   
	    self:addChild(labelAtlas,2,2)
	end
    self:setPosition(cc.p(self:getContentSize().width/2,self:getContentSize().height/2 + self:getContentSize().height/7))
    self:setTag(roomBack + levelType)
    self:setTouchEnabled(true)

end

function LevelPoint:addStar(starType,aniFlag)
	local star = ccui.ImageView:create()	
	local scale = self:getScale()
	local starScale = star:getContentSize().width/(self:getContentSize().width/3)*scale
	--star:setScale(0.3)
	--star:setAnchorPoint(0.5,0)
	star:setPositionType(ccui.PositionType.percent)
	star:setPositionPercent(cc.p(0.3 * (starType-2),-0.3))
	--star:setTag(starType+140)
	local function loadStar()
		star:loadTexture(string.format(pngSpStar,starType))
	end
	if aniFlag == true then
		--star:setVisible(false)
		star:runAction(cc.Sequence:create(cc.DelayTime:create((starType-1)*0.8),cc.CallFunc:create(loadStar),cc.FadeIn:create(0.8))) 
	else
		loadStar()
	end
	self:addChild(star)
end

function LevelPoint:setLockedByFlag(locked)
	if locked ~= true then return end
	local backg = ccui.ImageView:create()
	backg:loadTexture(pngSpMask)
	backg:setLocalZOrder(self:getLocalZOrder() + 10)
	self:addChild(backg)

	--设置tag
	backg:setTag(10) 
end

function LevelPoint.create(levelType,levelId )
	local point = LevelPoint.extend(ccui.ImageView:create())
	point:init(levelType,levelId)
	return point
end

--播放下一关解锁动画
function LevelPoint:playUnlockAnimation(levelType)
	parent = self:getParent():getParent():getParent()
	local levelTag = getClickedLevel()
	if levelType > taskIndex then
		levelTag = totalLevel
	end
	parent:addSpLine(levelTag+1,true)
	parent.LevelButton[levelTag + 1].locked = false	
	--增加星星
	local starCnt
	if levelType > taskIndex then
		starCnt = db:getInstance():getStar(math.floor(levelType/taskIndex)*totalLevel)
	else
		starCnt = db:getInstance():getStar(levelType)
	end
	if starCnt ~= nil then
		for i=1,starCnt do
				parent.LevelButton[levelTag]:addStar(i,true)
		end
	end
	local bcg = self:getChildByTag(10)
	if bcg ~= nil then
		bcg:runAction(cc.FadeOut:create(0.4))
		
		-- lhf添加粒子效果测试
		local function addPar1()
			-- lhf音乐
			audio:playEffect("audio/SND004.mp3")
			effect:getParticleWithFile(parent,parent.LevelButton[levelTag],parLevelWin)
		end
		local function addPar2()
			-- lhf音乐
			audio:playEffect("audio/SND003.mp3")
			effect:getParticleWithFile(parent,bcg,parLevelUnlock)
		end
        parent:runAction(cc.Sequence:create(cc.CallFunc:create(addPar1),cc.DelayTime:create(0.5),cc.CallFunc:create(addPar2)))
	end
end

--播放下一关解锁动画
function LevelPoint:playUnlockAnimationTk(levelType)
	parent = self:getParent():getParent():getParent()
	local levelTag = (math.floor(levelType/taskIndex)-2)*3 + levelType%taskIndex
	

	--增加星星
	local function starAni()
		starCnt = db:getInstance():getTaskStar(levelTag)
		if starCnt ~= nil then
			for i=1,starCnt do
					parent.quests[levelType%taskIndex]:addStar(i,true)
			end
		end
	end
	local starCall = cc.CallFunc:create(starAni)
	local bcg = self:getChildByTag(10)
	if bcg ~= nil then
		bcg:runAction(cc.FadeOut:create(0.4))
		
		-- lhf添加粒子效果测试
		local function addPar1()
			-- lhf音乐
			audio:playEffect("audio/SND004.mp3")
			effect:getParticleWithFile(parent,parent.quests[levelType%taskIndex],parLevelWin)
		end
		local function addPar2()
			-- lhf音乐
			audio:playEffect("audio/SND003.mp3")
			effect:getParticleWithFile(parent,bcg,parLevelUnlock)
		end
        parent:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(addPar2),cc.DelayTime:create(0.5),starCall))
	end
end
