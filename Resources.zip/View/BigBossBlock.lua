BigBossBlock = {}  
BigBossBlock = class("BigBossBlock",
    function()
        return BasicBlock.create()
    end)
BigBossBlock.__index = BigBossBlock







function BigBossBlock.create(hp)
    local germ = BigBossBlock.new()
    germ:initWithHp(hp)
    return germ
end


function BigBossBlock:initWithHp(hp)

    self:setTexture(string.format(pngBigBoss,1))
    self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function BigBossBlock:beHited()
    gameScene = self:getParent():getParent()
	if self:smashed("bigBossHited",pngBigBoss,"bigBossDie",0.9) == true then
        audio:playEffect("audio/SND014.mp3")
        countBigBoss = countBigBoss - 1
        print("bigBossHited")
        local idx = gameScene.boss[1]
        gameScene.toGet[idx]:setText(countBigBoss)
        return 0.9
    end
    return 0.1
end
