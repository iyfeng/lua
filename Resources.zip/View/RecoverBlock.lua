RecoverBlock = {}  
RecoverBlock = class("RecoverBlock",
    function()
        return BasicBlock.create()
    end)
RecoverBlock.__index = RecoverBlock







function RecoverBlock.create(hp)
    local germ = RecoverBlock.new()
    germ:initWithHp(hp)
    return germ
end


function RecoverBlock:initWithHp(hp)
    self:setTexture(string.format(pngRecover,1))
    self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function RecoverBlock:beHited( ... )	
    local i,j = Map.getTileCoordinateFromSprite(self)
    gameScene = self:getParent():getParent()
    if self:smashed("recoverHited",pngRecover,"recoverDie",0.7) == true then
        countRecover = countRecover - 1
        audio:playEffect("audio/SND013.mp3")
        removeFromTable(targetRecover,cc.p(i+2,j+2))
        local idx = gameScene.boss[2]
        gameScene.toGet[idx]:setText(countRecover)
        return 0.7
    end
    return 0.1
end

function RecoverBlock:result( ... )
    local i,j = Map.getTileCoordinateFromSprite(self)
    self.hpPanel:updateHp(mapInfo[i+2][j+2].hp)
    if self.remainHp ~= mapInfo[i+2][j+2].hp then
        -- lhf添加粒子效果测试
        -- print("pos1:",self.hpPanel:getContentSize().width,self.hpPanel:getPositionY())
        self.hpPanel:setPosition(100,100)
        -- print("pos2:",self.hpPanel:getPositionX(),self.hpPanel:getPositionY())
        self:doAnimate(jsonAniBoss,"BossAnimation","recoverLaugh",0.5,string.format(pngRecover,1))
        effect:getParticleWithFile(self,self.hpPanel,parRecoverHp)
        audio:playEffect("audio/SND016.mp3")
        self.hpPanel:setPosition(0,0)
    end
    
    self.remainHp = mapInfo[i+2][j+2].hp
    
end

