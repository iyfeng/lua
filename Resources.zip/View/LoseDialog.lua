local director = cc.Director:getInstance()
local winSize = director:getWinSize()

LoseDialog = class("LoseDialog")
LoseDialog.__index = LoseDialog
LoseDialog._pointType = nil

function LoseDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, LoseDialog)
    return target
end

function LoseDialog:init(levelType )
	local gameScene = self:getParent()
	if gameScene and gameScene.entry then
		schedule:unscheduleScriptEntry(gameScene.entry)
		 gameScene.entry = nil
	end
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonLoseDlg)
	self:addChild(self._widget)
	local background = self._widget:getChildByTag(dlgBg)
	local closeBtn = background:getChildByTag(dlgClose)
	local retryBtn = background:getChildByName("playButton")
	local levelLbl = background:getChildByTag(dlglevlbl-1):getChildByTag(dlglevlbl)
	local heartImg = background:getChildByTag(dlgHeart-2):getChildByTag(dlgHeart)
	local levelsta = background:getChildByName("levelPanel"):getChildByName("staticlevel")

    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniHeartBreak)
    self.armature =  ccs.Armature:create("HeartBreak")
    self.armature:getAnimation():play("Animation1")
    self.armature:setPosition(heartImg:getWorldPosition())--(0.398*winSize.width,0.708*winSize.height)--(340,340)
    self.armature:setScale(0.5);
    self:addChild(self.armature)

	local toBig1 = cc.ScaleBy:create(0.7,0.97,1.02)
	local toSmall1 = toBig1:reverse()
	local bigSmallRepeat = cc.Sequence:create(toBig1,toSmall1)
	retryBtn:runAction(cc.RepeatForever:create(bigSmallRepeat))

	--设置关卡等级显示
	if levelType < taskIndex then
		levelLbl:setText(levelType)
	else
		levelsta:setText("Quest")
		local queT = levelType % taskIndex
		levelLbl:setText(queT)
	end
	
	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:getParent()._clicked = false
				self:removeFromParent()
				local _indexT = levelType < taskIndex and math.floor((levelType-1)/15)+1 or math.floor(levelType/10000)
				runLevelScene(_indexT)
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.6,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	local function retryCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local gameScene = self:getParent()
		-- if gameScene.entry then
		-- 	schedule:unscheduleScriptEntry(gameScene.entry)
		-- end
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function retry()
				self:getParent()._clicked = false
				self:removeFromParent()
				runGameScene(levelType)				
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(retry)))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	retryBtn:addTouchEventListener(retryCallBack)
	
end


function LoseDialog.create(levelType )
	local dlg = LoseDialog.extend(cc.Layer:create())
	dlg:init(levelType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(1000)
	return dlg
end