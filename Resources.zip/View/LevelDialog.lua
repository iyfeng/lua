local director = cc.Director:getInstance()
local winSize = director:getWinSize()

LevelDialog = class("LevelDialog")
LevelDialog.__index = LevelDialog
LevelDialog._pointType = nil

function LevelDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, LevelDialog)
    return target
end

function LevelDialog:init(levelType )
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonLevelDlg)
	self:addChild(self._widget)
	local background = self._widget:getChildByTag(dlgBg)
	local closeBtn = background:getChildByTag(dlgClose)
	local playBtn = background:getChildByTag(dlgPlay)
	local levelLbl = background:getChildByTag(dlglevlbl-1):getChildByTag(dlglevlbl)
	local txScore = background:getChildByTag(dlgprops):getChildByTag(dlgScore)
	txScore:setText(lv:getScoreTarget()[1])
	
	local toBig1 = cc.ScaleBy:create(0.7,0.97,1.02)
	local toSmall1 = toBig1:reverse()
	local bigSmallRepeat = cc.Sequence:create(toBig1,toSmall1)
	playBtn:runAction(cc.RepeatForever:create(bigSmallRepeat))

	--设置关卡等级显示
	local clkIndex = getClickedIndex() - 1

	setClickedLevel(levelType)
	levelLbl:setText(levelType + clkIndex * totalLevel)

	local star = db:getStar(levelType + clkIndex * totalLevel)
	if star==nil then
		star=0
	end
	if star ==0 then 
		for i=dlgStarPanel+1,dlgStarPanel+3,1 do
			local starPanel = background:getChildByTag(dlgStarPanel):getChildByTag(i)
			starPanel:setVisible(false)
		end
	else
		for i=dlgStarPanel-1,dlgStarPanel-3,-1 do
			local starPanel = background:getChildByTag(dlgStarPanel):getChildByTag(i)
			starPanel:setVisible(false)
		end
		for i=dlgStarPanel+4,dlgStarPanel+3+star,1 do
			local stars = background:getChildByTag(dlgStarPanel):getChildByTag(i)
			stars:setVisible(true)
		end
	end

	

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:getParent()._clicked = false
				removeMaskBg(self:getParent())
				self:removeFromParent()
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	closeBtn:addTouchEventListener(closeCallBack)


	local function playCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function replaceSce()
				cclog("game Start level %d",levelType + clkIndex * totalLevel)
				runGameScene(levelType + clkIndex * totalLevel)
			end
			self:runAction(cc.CallFunc:create(replaceSce))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	playBtn:addTouchEventListener(playCallBack)
	
end


function LevelDialog.create(levelType )
	local dlg = LevelDialog.extend(cc.Layer:create())
	dlg:init(levelType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(1000)
	return dlg
end