ReboundBlock = {}  
ReboundBlock = class("ReboundBlock",
    function()
        return BasicBlock.create()
    end)
ReboundBlock.__index = ReboundBlock







function ReboundBlock.create(hp)
    local germ = ReboundBlock.new()
    germ:initWithHp(hp)
    return germ
end


function ReboundBlock:initWithHp(hp)
    self:setTexture(pngNull)
    self.sp1 = cc.Sprite:create(pngBounce)
    self.sp2 = cc.Sprite:create(pngBounceCov)
    self.sp1:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self.sp2:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self:addChild(self.sp1)
    self:addChild(self.sp2)
    local rotateBy = cc.RotateBy:create(10,360)
    self.sp1:runAction(cc.RepeatForever:create(rotateBy))
end

function ReboundBlock:beHited()
    if self.scale == nil then
        self.scale = self:getScale()
    end
    -- print("scale",self.scale)
	local big = cc.ScaleTo:create(0.1,0.96*self.scale)
    local samll = cc.ScaleTo:create(0.1,self.scale)
	self:runAction(cc.Sequence:create(big,samll))
    audio:playEffect("audio/SND021.mp3")
end