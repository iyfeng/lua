local director = cc.Director:getInstance()
local winSize = director:getWinSize()
local schedule = director:getScheduler()

QuestDialog = class("QuestDialog")
QuestDialog.__index = QuestDialog
QuestDialog._pointType = nil

local balY = winSize.height % 5
QuestDialog.pointH = (winSize.height - balY)/5

function QuestDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, QuestDialog)
    return target
end

function  QuestDialog:init(indexType,flag,aniFlag)
	print("enter")
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonQuestDlg)

	self:addChild(self._widget)
	local background = self._widget:getChildByName("bgDlg")
	local returnBtn = background:getChildByName("close")
	self.questPtModel = background:getChildByName("quest")
	self.playBtn = background:getChildByName("playButton")
	self.txFinish = background:getChildByName("allFinText")
	self.txNextTime = background:getChildByName("nextTimeText")
	self.timeLeft = background:getChildByName("time")

	self:visibleInfo(flag)
	self:updateTime()

	local function updateTimes()
		self:updateTime()
	end

	if flag == true then
		self.entry = schedule:scheduleScriptFunc(updateTimes,1,false)
	end

	--add Stars Panel
	self.quests = {}
	local questPtOrgX,questPtOrgY = self.questPtModel:getPosition()
	local size = self.questPtModel:getSize()

	for i=1,3 do
		local levelTyTk = (indexType-2)*3+i
		local targetTmp = LevelPoint.create(levelTyTk,taskIndex + i)
		local scale = self.pointH/targetTmp:getContentSize().height * 0.8
		targetTmp:setScale(scale)
		targetTmp:getChildByTag(2):setScale(0.8/scale)
		targetTmp:setPosition(questPtOrgX+(i-1)*size.width*1.5,questPtOrgY)	
		if aniFlag ~= true and levelTyTk > db:getLevelFromTaskTb() then
			targetTmp:setLockedByFlag(true)
		end

		if aniFlag == true and levelTyTk > db:getLevelFromTaskTb()-1 then
			targetTmp:setLockedByFlag(true)
		end

		background:addChild(targetTmp,2,1000+i)
		table.insert(self.quests,background:getChildByTag(1000+i))
	end


	local function returnCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local parent = self:getParent()
		if ccui.TouchEventType.ended == event then
		audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:removeFromParent()
				parent:addChild(UnlockPartDialog.create(indexType))
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))			
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	returnBtn:addTouchEventListener(returnCallBack)

	local function playCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			setClickedIndex(taskIndex)
			runGameScene(getBigLevel()+1+indexType*taskIndex)
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	self.playBtn:addTouchEventListener(playCallBack)	
end

function QuestDialog:visibleInfo(flag)
	self.playBtn:setTouchEnabled(not flag)
	self.playBtn:setVisible(not flag)
	self.txFinish:setVisible(flag)
	self.txNextTime:setVisible(flag)
	self.timeLeft:setVisible(flag)
end	

function QuestDialog:updateTime()
	if apM:getRemainTimeTk() == 0 then
		self:visibleInfo(false)
		if self.entry then
			schedule:unscheduleScriptEntry(self.entry)
		end
	 	return 
	end 
	local time = apM:getRemainTimeTk()
	--print("time",time)
	local h = math.floor(time/3600)
	local min = math.floor((time%3600)/60)
	local sec = time%60

	local hour = min > 9.5 and string.format("%d",h) or string.format("0%d",h)
	local mins = min > 9.5 and string.format("%d",min) or string.format("0%d",min)
	local secs = sec > 9.5 and string.format("%d",sec) or string.format("0%d",sec)
	local timeTxt = string.format("%s:%s:%s",hour,mins,secs)
	self.timeLeft:setText(timeTxt)
end


function QuestDialog.create(indexType,flag,aniFlag)
	local dlg = QuestDialog.extend(cc.Layer:create())
	dlg:init(indexType,flag,aniFlag)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end