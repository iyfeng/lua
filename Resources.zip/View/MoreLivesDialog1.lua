require "View/MoreLivesDialog2"

local director = cc.Director:getInstance()
local winSize = director:getWinSize()

MoreLivesDialog1 = class("MoreLivesDialog1")
MoreLivesDialog1.__index = MoreLivesDialog1
MoreLivesDialog1._pointType = nil

function MoreLivesDialog1.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, MoreLivesDialog1)
    return target
end

function  MoreLivesDialog1:init(heart )
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonMoreLivesDlg1)

	self:addChild(self._widget)
	local background = self._widget:getChildByTag(dlgBg)
	local closeBtn = background:getChildByTag(dlgClose)
	local buynowBtn = background:getChildByTag(dlgBuyNow)
	local heartHeal = background:getChildByTag(dlgHeartHeal)

	effect:getParticleWithFile(self,heartHeal,parLivesHeal)

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				removeMaskBg(self:getParent())
				self:getParent()._clicked = false
				if effect ~=nil then 
	  				self:removeChildByTag(10086)
	    		end
	    		heart._clicked = nil
				self:removeFromParent()
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	-- 弹出第二层对话框
	local function buynowCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			print("buynow")
			audio:playEffect("audio/SND008.mp3")
			local dlg = MoreLivesDialog2.create(heart)
			
			local function destroy()
			self:getParent()._clicked = false
			if effect ~=nil then 
  				self:removeChildByTag(10086)
    		end
    		self = nil
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
			self:getParent():addChild(dlg)

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	buynowBtn:addTouchEventListener(buynowCallBack)
	
end

function MoreLivesDialog1.create(heart)
	local dlg = MoreLivesDialog1.extend(cc.Layer:create())
	dlg:init(heart)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end