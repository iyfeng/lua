BasicBlock = {}  
BasicBlock = class("BasicBlock",
    function()
        return cc.Sprite:create()
    end
)
BasicBlock.__index = BasicBlock





function BasicBlock:init()
	self.type = self.BlockType.BlockTypeBasic
	self.movePositions = {}
	self.hasMoved = true
	self.makeSeq = -1
	self.canBreak = true
    self.isMask = false
    return self
end

function BasicBlock.create()
	local basic = BasicBlock.new()
	basic:init()
	return basic
end



BasicBlock.BlockType = {
	BlockTypeNone =0,--无，地图里相当于空白
    BlockTypeGerms =1,--普通细菌
    BlockTypeBoss =2,--Boss
    BlockTypeBlock = 3,--障碍1
    BlockTypeWall = 4,--障碍，打不破
    BlockTypeBox = 5,--障碍2
    BlockTypeBigBoss = 6,--大boss
    BlockTypeGood = 7,--有益细菌，不能死亡，要保护
    BlockTypeRecover = 8,--回合后若未死亡，回满血
    BlockTypeWeakOther = 9,--回合后使周围8个虚弱
    BlockTypeRebound = 10,--细菌碰到后原路返回
    BlockTypePartBounceUp = 11,--碰撞后转90度
    BlockTypePartBounceLeft = 12,
    BlockTypePartBounceDown = 13,
    BlockTypePartBounceRight = 14,
    BlockTypeBomb = 15,--炸弹，由多个物品合成，不可预先配置
    BlockTypePipeLR = 16,--双向通过的管道,左右
    BlockTypePipeUD = 17,--上下通过的管道,左右
    BlockTypeDoctor = 18,--每回合可以恢复一定的生命值
    BlockTypeOther = 19,--其他
    BlockTypeBasic = 20--基本
}


BasicBlock.Direction = {   
    DirectionUp=0,
    DirectionDown=1,
    DirectionLeft=2,
    DirectionRight=3,   
    DirectionStop=4,
}

function BasicBlock:resetBeforeMove()
	for i=1,#self.movePositions do 
     table.remove(self.movePositions)
 	end

 	self.makeSeq = -1
 	self.hasMoved = false
 	self.currentMovePos = 0
end

function BasicBlock:addMovePoint(point)
	table.insert(self.movePositions,point)
end

function BasicBlock:printMovePath()
	-- body
end

function BasicBlock:countMoveStep()
	local re = self.makeSeq
	for i=1,#self.movePositions  do
		local value1 = self.movePositions[i].y
		local value2 = self.movePositions[i+1].y
		re = re + value2 - value1
	end
	return re
end

function BasicBlock:getMaxHp()
	return 0
end

function BasicBlock:setMaxHp(hp)
	-- body
end

function BasicBlock:getAnimateFromResourceHead(frome,to,delay,string)
    --play animate
end

function BasicBlock:smashed(animationHit,backImage,animationDie,timeDie)
    --print("self.remainHp",mapInfo[6][4].isEmpty)
    -- lhf音乐
    audio:playEffect("audio/SND013.mp3")
    self.remainHp = self.remainHp-1
    self.hpPanel:updateHp(self.remainHp)
    if self.maxHp ~= nil and self.remainHp ~= 0 then
        self:doAnimate(jsonAniBoss,"BossAnimation",animationHit,0.1,self:bossState(backImage))
        --print("paly hit ani")
    end
    if self.remainHp == 0 then
        self:removeChild(self.hpPanel)
        self:setTexture(pngNull)
        local function die()
            local i,j = Map.getTileCoordinateFromSprite(self)
            mapInfo[i+2][j+2].isEmpty = 1
            mapInfo[i+2][j+2].type = 1
            mapInfo[i+2][j+2].hp = 0 
            if self.maxHp ~= nil then
                self:doAnimate(jsonAniBoss,"BossAnimation",animationDie,timeDie,pngNull)
            end
        end
        
        local function disappear()
            local i,j = Map.getTileCoordinateFromSprite(self)
            mapInfo[i+2][j+2].isEmpty = 1
            mapInfo[i+2][j+2].type = 1
            mapInfo[i+2][j+2].hp = 0 
            self:removeFromParent()
        end
        ----[[
        if timeDie ~= nil then
            local dieCall = cc.CallFunc:create(die)
            local disCall = cc.CallFunc:create(disappear)
            local delay = cc.DelayTime:create(timeDie)
            local delayD = cc.DelayTime:create(0.2)
            self:runAction(cc.Sequence:create(dieCall,delay,disCall,delayD))
        else
        --]]--
            disappear()
        end
        return true
    else
        --playAnimation here
    end
    return self.remainHp <= 0
end

function BasicBlock:isType4()
    local i,j = Map.getTileCoordinateFromSprite(self)
    i,j = i+2,j+2
    return mapInfo[i][j].isEmpty == 0 and self.itemType == 4
end

function BasicBlock:isGerm()
    local i,j = Map.getTileCoordinateFromSprite(self)
    i,j = i+2,j+2
    return mapInfo[i][j].isEmpty == 0
end

function BasicBlock:doAnimate(jsonName,arnatureName,animationName,time,backImage)
    ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonName)
    self.armature =  ccs.Armature:create(arnatureName)
    self.armature:getAnimation():play(animationName)
    self.armature:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self:setTexture(pngNull)
    self:addChild(self.armature,2,20)

    local function remove()
        self:setTexture(backImage)
        if self:getChildByTag(20) ~= nil then
            self:removeChildByTag(20)
        end
    end
    rem = cc.CallFunc:create(remove)
    delay = cc.DelayTime:create(time)
    self:runAction(cc.Sequence:create(delay,rem))
end

function BasicBlock:bossState(pngBoss)
    local state = math.floor((1-self.remainHp/self.maxHp)*5+1)
    if state < 1 or state > 5 then
        state = 1
    end
    --print("boss state",state)
    return string.format(pngBoss,state)
end