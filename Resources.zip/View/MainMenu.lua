

require "View/InOneRoomLayer"
require "View/AudioHelper"
require "View/SettingDialog"
require "View/MoreLivesDialog1"

local director = cc.Director:getInstance()
local visibleSize = director:getVisibleSize()
local origin = director:getVisibleOrigin()
local winSize = director:getWinSize()
local sfCache = cc.SpriteFrameCache:getInstance()
local schedule = director:getScheduler()


MainMenu = class("MainMenu")
MainMenu._curNode = nil



function MainMenu.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, MainMenu)
    return target
end



function MainMenu:init()
	local widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonMainMenuLayer)

	local function addAnimationToNode(node,animationName,zorder)
		ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniMainMenu)
	    local armature =  ccs.Armature:create("MainSceneAnimation")
	    armature:getAnimation():play(animationName)
	    armature:setPosition(self:convertToWorldSpace(cc.p(node:getPosition())))
	    local scale = node:getScale()
	    --print("scale x y",self:convertToWorldSpace(cc.p(node:getPosition())).x,self:convertToWorldSpace(cc.p(armature:getPosition())).x)
	    armature:setScale(scale)
	    --armature:setPosition(node:getContentSize().width/2,node:getContentSize().height/2)
	    node:setVisible(false)
	    print("here assert")
	    self:addChild(armature,zorder,20)
	end
	
	local roomCount = 2
	local roomTag = 10
	--门
	local doors = {}
	for i = 1,roomCount do
		local dtemp = widget:getChildByName(string.format("Door%d",i))
		dtemp:setTouchEnabled(true)
		table.insert(doors,dtemp)
	end
	--cclog("set assert here")
	--开门函数回调
	local function  openTheDoor(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("clicked")
			cur = sender:getTag() - roomTag
			-- lock a room
			if cur ~= 3 then
				audio:playEffect("audio/SND001.mp3")
				addAnimationToNode(doors[cur],string.format("Door%d",cur),2)
				local function runScene()
					runInRoomScene(cur)
					----lhf添加粒子效果测试
					self:removeChildByTag(10086)
				end
				sender:runAction(cc.Sequence:create(cc.DelayTime:create(5/6),cc.CallFunc:create(runScene)))
			else
				audio:playEffect("audio/SND002.mp3")
				cclog(" can not open the door")

				-- lhf设置界面
				
			end
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			--sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end

	for i=1,roomCount do
		doors[i]:addTouchEventListener(openTheDoor)
	end
	--doors[1]:loadTexture("backg.png",0)
	local cat = widget:getChildByName("Cat")
	local tree = widget:getChildByName("Tree")
	local tip = widget:getChildByName("Tips")

	addAnimationToNode(cat,"Cat",20)
	addAnimationToNode(tree,"Tree",20)
	addAnimationToNode(tip,"Tips",20)

	--lhf添加粒子效果测试
	-- for i=1,3 do
		effect:setParticleForTouchHint(self,doors[1])
	-- end
	local setting = widget:getChildByName("Setting")
	local function settingDlg(sender,event)
		if ccui.TouchEventType.ended == event then
			local Dlg = SettingDialog.create()
			self:addChild(Dlg)
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	setting:setTouchEnabled(true)
	setting:addTouchEventListener(settingDlg)

	self:addChild(widget)
end






function MainMenu.CreateMainMenuScene()
	local sceneMain = cc.Scene:create()
	local layer = MainMenu.extend(cc.LayerColor:create())
	layer:init()
    sceneMain:addChild(layer)
    return sceneMain
end