BoxBlock = {}  
BoxBlock = class("BoxBlock",
    function()
        return BasicBlock.create()
    end)
BoxBlock.__index = BoxBlock







function BoxBlock.create(hp)
    local germ = BoxBlock.new()
    germ:initWithHp(hp)
    return germ
end


function BoxBlock:initWithHp(hp)
    self:setTexture(pngBox)
    self.remainHp = hp
    --self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function BoxBlock:beHited( ... )
	self:smashed()
end