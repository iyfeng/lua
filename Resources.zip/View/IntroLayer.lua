local hello = {}

require "View/MainMenu"




function hello.newScene(backfunc)
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    require "hello2"
    cclog("result is " .. myadd(1, 1))

    ---------------
    local director = cc.Director:getInstance()
    local visibleSize = director:getVisibleSize()
    local origin = director:getVisibleOrigin()
    local winSize = director:getWinSize()

    local function backToUpdate()
        local scene = backfunc()
        if scene ~= nil then
            director:replaceScene(scene)
        end
    end

    --Create BackMneu
    local function createLayerMenu()
        cc.MenuItemFont:setFontName("Arial")
        cc.MenuItemFont:setFontSize(24)
        local backMenuItem = cc.MenuItemFont:create("Back")
        backMenuItem:setPosition(cc.p(winSize.width - 50, origin.y + 25))
        backMenuItem:registerScriptTapHandler(backToUpdate)

        local backMenu = cc.Menu:create()
        backMenu:setPosition(0, 0)
        backMenu:addChild(backMenuItem)
        return backMenu
    end
    local function createLayer()
        local background = cc.Sprite:create(pngIntroBg)
        background:setRotation(-90)
        background:setPosition(winSize.width/2,winSize.height/2)
        local layer = cc.Layer:create()
        layer:addChild(background)
        return layer
    end
    local function onEnter()
        sceneMain =  MainMenu:CreateMainMenuScene()
        director:replaceScene(cc.TransitionFade:create(1,sceneMain))
    end
            --LayerCallBack
    local function onLayerEvent(event)
        --cclog("game event: "..event)
        if event == "enter" then
                onEnter()
        end
    end
        
    -- run
    local sceneGame = cc.Scene:create()
    sceneGame:addChild(createLayer())
    sceneGame:addChild(createLayerMenu())
    sceneGame:registerScriptHandler(onLayerEvent) 
    audio:playEffect("audio/XL001.mp3")
    audio:playMusic("audio/bgm.mp3")
    director:replaceScene(sceneGame)

end

return hello 