TPanel = {}  
TPanel = class("TPanel",
    function()
        return ccui.ImageView:create()
    end)
TPanel.__index = TPanel







function TPanel.create(Cnt,parent)
    local germ = TPanel.new()
    germ:initWithCnt(Cnt,parent)
    return germ
end


function TPanel:initWithCnt(Cnt,parent)
	self:loadTexture(pngNull)
	local numberBg = ccui.ImageView:create()
	numberBg:loadTexture(pngMagicBg)
	self:addChild(numberBg)
	--numberBg:setScale(20)
	local scale = parent:getContentSize().width/self:getContentSize().width*0.5
	self.label = ccui.TextField:create()
	self.label:setFontName(fontName)
	self.label:setFontSize(32)
	self.label:setAnchorPoint(0.5, 0.5)
	print("cnt",Cnt)
	if Cnt <= 0 then 
		self.label:setText("+")
	else
		self.label:setText(string.format("%d",Cnt))
	end
	local scaleY = numberBg:getContentSize().height/self.label:getContentSize().height*0.9
	self.label:setScale(scaleY)
	numberBg:addChild(self.label,10)
	numberBg:setAnchorPoint(0.5, 0.5)
	self:setPositionType(ccui.PositionType.percent)
	self:setPositionPercent(cc.p(0.4,0.4))
	numberBg:setScale(scale)
	parent:addChild(self)
	--cclog("anchor self %f %f",self:getAnchorPoint().x,self:getAnchorPoint().y)
	--cclog("anchor label %f %f",self.label:getAnchorPoint().x,self.label:getAnchorPoint().y)
	return self
end

function TPanel:updateCnt(Cnt)
	if Cnt <= 0 then 
		self.label:setText("+")
	else
		self.label:setText(string.format("%d",Cnt))
	end
end