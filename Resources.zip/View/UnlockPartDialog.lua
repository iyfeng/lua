require "View/UnlockByPayDialog"
require "View/QuestDialog"

local director = cc.Director:getInstance()
local winSize = director:getWinSize()

UnlockPartDialog = class("UnlockPartDialog")
UnlockPartDialog.__index = UnlockPartDialog
UnlockPartDialog._pointType = nil

function UnlockPartDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, UnlockPartDialog)
    return target
end

function  UnlockPartDialog:init(indexType)
	print("enter")
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonUnlockPartDlg)
	setClickedIndex(taskIndex)
	lv = nil
	lv = LevelInfo:getInstance(taskIndex)
	self:addChild(self._widget)
	local background = self._widget:getChildByName("bgDlg")
	local txUnlockPart = background:getChildByName("UnlockPart")
	local closeBtn = background:getChildByName("close")
	local byFaceBtn = background:getChildByName("byFaceButton")
	local unLockNowBtn = background:getChildByName("unlockNowButton")
	local playQuestBtn = background:getChildByName("playQuestButton")

	txUnlockPart:setText(string.format("Unlock Part %d ?",indexType+1))

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			setClickedIndex(indexType)
			lv = nil
			lv = LevelInfo:getInstance(indexType)
			local function destroy()
				self:getParent()._clicked = false
				removeMaskBg(self:getParent())
				self:removeFromParent()
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	local function facebookCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			print("facebookCallBack")
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	byFaceBtn:addTouchEventListener(facebookCallBack)

	local function unlockNowCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local parent = self:getParent()
		if ccui.TouchEventType.ended == event then
			local function destroy()
				self:removeFromParent()
				parent:addChild(UnlockByPayDialog.create(indexType))
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))			
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	unLockNowBtn:addTouchEventListener(unlockNowCallBack)

	local function palyQuestCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local parent = self:getParent()
		if ccui.TouchEventType.ended == event then
			local function destroy()
				self:removeFromParent()
				if apM:getAp() <= 0 then
					local dlg = MoreLivesDialog1.create(parent.heart)
					parent:addChild(dlg)   							
				else
					local canPlay = (apM:getRemainTimeTk() ~= 0)
					parent:addChild(QuestDialog.create(indexType,canPlay,false))
				end
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))			
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	playQuestBtn:addTouchEventListener(palyQuestCallBack)
	
end

function UnlockPartDialog.create(indexType)
	local dlg = UnlockPartDialog.extend(cc.Layer:create())
	dlg:init(indexType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end