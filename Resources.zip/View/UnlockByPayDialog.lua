local director = cc.Director:getInstance()
local winSize = director:getWinSize()

UnlockByPayDialog = class("UnlockByPayDialog")
UnlockByPayDialog.__index = UnlockByPayDialog
UnlockByPayDialog._pointType = nil

function UnlockByPayDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, UnlockByPayDialog)
    return target
end

function  UnlockByPayDialog:init(indexType)
	print("enter")
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonUnlockByPayDlg)

	self:addChild(self._widget)
	local background = self._widget:getChildByName("bgDlg")
	local txUnlockPart = background:getChildByName("unLockPart")
	local closeBtn = background:getChildByName("close")
	local payBtn = background:getChildByName("priceButton")
	local txStatic = background:getChildByName("textStatic")
	
	txUnlockPart:setText(string.format("Unlock Part %d ?",indexType+1))

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
		audio:playEffect("audio/SND008.mp3")
			setClickedIndex(indexType)
			lv = nil
			lv = LevelInfo:getInstance(indexType)
			local function destroy()
				self:getParent()._clicked = false
				removeMaskBg(self:getParent())
				self:removeFromParent()
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	local function payCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			print("payCallBack")
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            local curTask = db:getLevelFromTaskTb()
					local needTask = (indexType-1)*3
					print("curTask,needTask",curTask,needTask)
					for i=1,needTask-curTask do
					 	db:addToTaskTb(1,1)
					end
					setClickedIndex(indexType)
					lv = nil
					lv = LevelInfo:getInstance(indexType)
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    local function destroy()
						self:getParent()._clicked = false
						removeMaskBg(self:getParent())
						self:removeFromParent()
					end
					self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"nextpart",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	payBtn:addTouchEventListener(payCallBack)

	
	
end

function UnlockByPayDialog.create(indexType)
	local dlg = UnlockByPayDialog.extend(cc.Layer:create())
	dlg:init(indexType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end