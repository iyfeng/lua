AudioHelper = {} 
mp3SND = "audio/SND0%d%d.mp3"
mp3SND030 = "audio/SND030.mp3"
mp3XL = "audio/XL00%d.mp3"

function AudioHelper:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end  
  
function AudioHelper:getInstance()  
    if self.instance == nil then  
        self.instance = self:new()
        self:init()  
    end  
    return self.instance  
end  

function AudioHelper:init()
  	self:preloadEffectsAndBGMusic()
end


function AudioHelper:preloadEffectsAndBGMusic()
	cc.SimpleAudioEngine:getInstance():preloadMusic("audio/bgm.mp3")
	for i=1,23 do
		cc.SimpleAudioEngine:getInstance():preloadEffect(string.format(mp3SND,math.floor(i/10),i%10))
		if i<=3 then
			cc.SimpleAudioEngine:getInstance():preloadEffect(string.format(mp3XL,i))
		end
	end
	cc.SimpleAudioEngine:getInstance():preloadEffect(mp3SND030)
end

function AudioHelper:playEffect(name)
	if db:getSoundState() == 1 then
		cc.SimpleAudioEngine:getInstance():playEffect(name)
	else
		return
	end
end
function AudioHelper:isPlayingMusic( ... )
	return cc.SimpleAudioEngine:getInstance():isMusicPlaying()
end
function AudioHelper:playMusic(name)
	if not self:isPlayingMusic() then
		cc.SimpleAudioEngine:getInstance():playMusic(name,true)
	end
	-- print("playMusic",db:getSoundState())
	if db:getMusicState() == 0 then
		-- print("stopMusic")
		cc.SimpleAudioEngine:getInstance():pauseMusic()
	end
end