HpPanel = {}  
HpPanel = class("HpPanel",
    function()
        return cc.Sprite:create()
    end)
HpPanel.__index = HpPanel







function HpPanel.create(hp)
    local germ = HpPanel.new()
    germ:initWithHp(hp)
    return germ
end


function HpPanel:initWithHp(hp)
	local numberBg = cc.Sprite:create(pngNumberBg)
	self:addChild(numberBg)

	local fontX = 24
	local fontY = 29

	self.label = cc.LabelAtlas:_create(string.format("%d",hp),pngHpNum,fontX ,fontY,string.byte('0'))
	--self.label = cc.LabelTTF
	self.label:setAnchorPoint(0.5, 0.5)
	local scaleX = numberBg:getContentSize().width/self.label:getContentSize().width*0.5
	local scaleY = numberBg:getContentSize().height/self.label:getContentSize().height*0.5
	--self.label:setScale(scaleX)
	self.label:setScale(scaleY)
	self.label:setPosition(numberBg:getContentSize().width/2,numberBg:getContentSize().height/2)
	numberBg:addChild(self.label,10)
	numberBg:setAnchorPoint(-1, -1)
	--cclog("anchor self %f %f",self:getAnchorPoint().x,self:getAnchorPoint().y)
	--cclog("anchor label %f %f",self.label:getAnchorPoint().x,self.label:getAnchorPoint().y)
	return self
end

function HpPanel:updateHp(hp)
	self.label:setString(string.format("%d",hp))
end