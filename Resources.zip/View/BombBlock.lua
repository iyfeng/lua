
BombBlock = {}  
BombBlock = class("BombBlock",
    function()
        return BasicBlock.create()
    end)
BombBlock.__index = BombBlock

BombBlock.BombTypeNone=0
BombBlock.BombTypeH=1
BombBlock.BombTypeV=2
BombBlock.BombTypeS=4
BombBlock.BombTypeHV=3
BombBlock.BombTypeHS=5
BombBlock.BombTypeVS=6
BombBlock.BombTypeHVS=7





function BombBlock.create(hp)
    local germ = BombBlock.new()
    germ:initWithHp(hp)
    return germ
end


function BombBlock:initWithHp(hp)
    Map.BombHited = false
    self:setTexture(pngNull)
    self.isBomb = true
    if hp == BombBlock.BombTypeNone then
    	return
    end
    self.itemType = hp
    if self.itemType < self.BombTypeS then 
    	self.remainTimes = 4
    elseif self.itemType == self.BombTypeS then 
    	self.remainTimes = 2
    elseif self.itemType < self.BombTypeHVS then 
    	self.remainTimes = 6
    else
    	self.remainTimes = 8
    end
    self.body = cc.Sprite:create(pngSjtBody)
    local fontSize= 40
    --local fontY = 40
    self.number = cc.LabelAtlas:_create(string.format("%d",self.remainTimes),pngSjtFont,fontSize ,fontSize,string.byte('0'))
    self:addChild(self.body)
    self:addChild(self.number)   
    self.body:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self.number:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    self.number:setAnchorPoint(0.5, 0.5)
	local scaleX = self:getContentSize().width/self.number:getContentSize().width*0.5
	local scaleY = self:getContentSize().height/self.number:getContentSize().height*0.5
	--self.label:setScale(scaleX)
	self.number:setScale(scaleY)
	self.number:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    --self.number:setString(string.format("%d",self.remainTimes))
    if self.itemType%2 == 1 then
    	self.spH = cc.Sprite:create(pngSjtH)
    	self:addChild(self.spH)
    	self.spH:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    end
    if math.floor(self.itemType/2)%2 == 1 then
    	self.spV = cc.Sprite:create(pngSjtV)
    	self:addChild(self.spV)
    	self.spV:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    end
    if math.floor(self.itemType/4)%2 == 1 then
    	self.spS = cc.Sprite:create(pngSjtS)
    	self:addChild(self.spS)
    	self.spS:setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
    end
    return self
end

function BombBlock:beHited()
    if self.hitted == nil then
        self.hitted = true
    else
        return
    end	
    print("hitted now")
	local times = self.remainTimes
	local function subTimes()
        --print("fashe",self.remainTimes)
		times = times-1
        --if times < 1 then return end
        if self.spH ~= nil then
            self.spH:setVisible(false)
        end
        if self.spV ~= nil then
            self.spV:setVisible(false)
        end
		self.number:setString(string.format("%d",times))
        --print("times",times)
        if times >= 0 then
            effect:doSjtAnimation(self,self:getParent(),"sjttime",0.1)
            effect.sjtarmature:setLocalZOrder(self:getLocalZOrder()+1)
            self:addSjtPao()
        end
        -- lhf音乐
        audio:playEffect("audio/SND018.mp3")
	end
	local function createDirections()
        --print("dirback")
		self:createDirections()
	end
	local function removeBomb()
		local i,j = Map.getTileCoordinateFromSprite(self)
        -- if self.itemType == self.BombTypeHV then
        --     effect.armature:removeFromParent()
        -- end
        if self.itemType ~= self.BombTypeHVS then
	       self:removeFromParent()
        end
	    mapInfo[i+2][j+2].hp = 0
	    mapInfo[i+2][j+2].isEmpty = 1
        Map.existBomb = false 
        Map.BombHited = true 
	end

	local subBack = cc.CallFunc:create(subTimes)
	local dirBack = cc.CallFunc:create(createDirections)
	local remBack = cc.CallFunc:create(removeBomb)
	local delay = cc.DelayTime:create(0.2)
    local aRepeat
    if self.itemType ~= self.BombTypeHVS then

        aRepeat =  cc.Repeat:create(cc.Sequence:create(delay,cc.Spawn:create(subBack,dirBack)),self.remainTimes)
        self:runAction(cc.Sequence:create(delay,aRepeat,remBack))

    else
        aRepeat =  cc.Sequence:create(delay,dirBack)
        self:runAction(aRepeat)
    end
	--self:runAction(cc.Sequence:create(aRepeat,remBack))

end

function BombBlock:addSjtPao()
    local ifS = (math.floor(self.itemType/4)%2 == 1)
    local ifH = (self.itemType%2 == 1)
    local ifV = (math.floor(self.itemType/2)%2 == 1)

    -- if ifH and self.spH ~= nil then
    --     self.spH:removeFromParent()
    -- end
    -- if ifV and self.spV ~= nil then
    --     self.spV:removeFromParent()
    -- end    

    for i=0,359,90 do
        if (i % 180 == 90 and ifH) or (i % 180 == 0 and ifV) or (ifS and (not ifH) and (not ifV)) then
            effect:doSjtAnimation(self,self:getParent(),"sjtpao",0.1)
            effect.sjtarmature:setRotation(i)
        end
    end
end


function BombBlock:createDirections()
	local allow = {}
	if self.itemType == self.BombTypeH or self.itemType == self.BombTypeHS then
		allow = {true,true,false,false}
	elseif self.itemType == self.BombTypeV or self.itemType == self.BombTypeVS then
		allow = {false,false,true,true}
	elseif self.itemType == self.BombTypeS or self.itemType == self.BombTypeHV then
		allow = {true,true,true,true}
    elseif self.itemType == self.BombTypeHVS then
        allow = {false,false,false,false}
	else
		allow = {false,false,false,false}
	end
    if self.itemType ~= self.BombTypeHVS then
    for i = 0,3 do
    	if allow[i+1] == true then
	        local germDir = GermsDirectionBlock.create(i)
	        germDir:setInfo(self)
	        --print(target:getPosition())
	        self:getParent():addChild(germDir)
	        germDir:setLocalZOrder(dirZOrder)
	        --print("pos ",i,germDir:getPos())
	        germDir:flyTo(nil,germDir:getPos())
	    end
    end
    else
        self:mostPower()
    end
end

function BombBlock:mostPower()
    mapbg = self:getParent()
    --playAnimation
    local posFrom = cc.pAdd(cc.p(self:getPosition()),cc.p(mapbg:getPosition()))

    local posFromSp = cc.Sprite:create(pngNull)
    -- print("bombpos:",self:getPositionX(),self:getPositionY(),posFrom.x,posFrom.y)
    posFromSp:setPosition(self:getPosition())
    posFromSp:setVisible(false)
    self:getParent():addChild(posFromSp,100)
    self:runAction(cc.RepeatForever:create(cc.RotateBy:create(0.3,300)))
    
    local delay = cc.DelayTime:create(0.5)
    effect:doAnimation(posFromSp,self:getParent(),"jz",10)
    effect:doAnimation(posFromSp,self:getParent(),"fd",10)
    -- effect.armature:setScale(3)
    local function bobAll( ... )
        local light = cc.Sprite:create(pngLight) 
        light:setAnchorPoint(0.5,0.5)  
        self:getParent():addChild(light,50)
        array = {}
        local totalGerms = 0
        for i=3,12 do
            for j=3,10 do
                 local sprite2 = Map.getBlockSprite(mapbg,j,i)
                    if sprite2 ~= nil and sprite2:isGerm() == true then
                        totalGerms = totalGerms + 1
                    end
            end
        end
        local ddDelayTime = 0.05
        local changedGerms = 0
        for i=3,12 do
            for j=3,10 do --maxx-2
                 --print(j-2 + (i-2)*10)  
               local sprite = Map.getBlockSprite(mapbg,j,i)
                    if sprite ~= nil and sprite:isGerm() == true then
                        local function ddAni( ... )
                            local pointAdd =  cc.pAdd(cc.p(self:getPosition()),cc.p(sprite:getPosition()))
                            local midPos = cc.p(pointAdd.x / 2,pointAdd.y / 2)
                            light:setPosition(midPos)

                            local distance = cc.pGetDistance(cc.p(self:getPosition()),cc.p(sprite:getPosition()))
                            light:setScale(distance / light:getContentSize().width)
                            
                            local angle = math.atan2(-(sprite:getPositionY() - self:getPositionY()), sprite:getPositionX() - self:getPositionX() )
                            light:setRotation(angle*180/math.pi)
                            audio:playEffect("audio/SND030.mp3")
                            changedGerms = changedGerms + 1
                            effect:doAnimation(sprite,self:getParent(),"dd",21/60 + ddDelayTime * (totalGerms-changedGerms))
                         end
                    table.insert(array,cc.CallFunc:create(ddAni))
                    table.insert(array,cc.DelayTime:create(ddDelayTime))
                    end
                end
            end
        local function allBurst()
            light:removeFromParent()
            posFromSp:removeFromParent()

            for i=3,10 do
                for j=3,12 do --maxx-2
                    --print(j-2 + (i-2)*10)
                    local sprite = Map.getBlockSprite(mapbg,i,j)
                    if sprite ~= nil and (sprite:isGerm() == true or sprite.itemType == self.BombTypeHVS) then
                        mapInfo[i][j].isEmpty = 1
                        sprite.canBurst = true
                    end
                end
            end
            for i=3,10 do
                for j=3,12 do --maxx-2
                    --print(j-2 + (i-2)*10)
                    local sprite = Map.getBlockSprite(mapbg,i,j)
                    if sprite ~= nil and sprite.canBurst == true and sprite.itemType ~= self.BombTypeHVS then
                        sprite:createDirections(sprite)
                        sprite.canBurst = nil
                    elseif sprite ~= nil and sprite.itemType == self.BombTypeHVS then
                        for k = 0,3 do
                            local germDir = GermsDirectionBlock.create(k)
                            germDir:setInfo(sprite)
                            --print(target:getPosition())
                            sprite:getParent():addChild(germDir)
                            germDir:setLocalZOrder(dirZOrder)
                            --print("pos ",i,germDir:getPos())
                            germDir:flyTo()
                        end
                        sprite.canBurst = nil
                    end
                end
            end
        end
        local delayTime = cc.DelayTime:create(0.05)
        local function removeBomb()
            local i,j = Map.getTileCoordinateFromSprite(self)
            -- if self.itemType == self.BombTypeHV then
            --     effect.armature:removeFromParent()
            -- end
            --if self.itemType ~= self.BombTypeHVS then
               self:removeFromParent()
            --end
            mapInfo[i+2][j+2].type = 1
            mapInfo[i+2][j+2].hp = 0
            mapInfo[i+2][j+2].isEmpty = 1
            Map.existBomb = false 
            Map.BombHited = true 
        end
        local removeC =  cc.CallFunc:create(removeBomb)
        self:runAction(cc.Sequence:create(cc.Sequence:create(array),delayTime,cc.CallFunc:create(allBurst),removeC))

        --self:removeFromParent()
    end

   -- 转动雷电动画

    

    self:getParent():runAction(cc.Sequence:create(delay,cc.CallFunc:create(bobAll)))
    -- allBurst()
    -- self
end



function BombBlock.createGui(hp)
    local guiBomb = ccui.ImageView:create()
    guiBomb:loadTexture(pngNull)
    if hp == BombBlock.BombTypeNone then
        return
    end
    local remainTimes
    if hp < BombBlock.BombTypeS then 
        remainTimes = 4
    elseif hp == BombBlock.BombTypeS then 
        remainTimes = 2
    elseif hp < BombBlock.BombTypeHVS then 
        remainTimes = 6
    else
        remainTimes = 8
    end
    body = ccui.ImageView:create()
    body:loadTexture(pngSjtBody)
    local fontSize= 40
    local number = ccui.TextAtlas:create()
    number:setProperty(string.format("%d",remainTimes),pngSjtFont,fontSize ,fontSize,"0")
    guiBomb:addChild(body)
    guiBomb:addChild(number)   
    number:setAnchorPoint(0.5, 0.5)
    local scaleX = guiBomb:getContentSize().width/number:getContentSize().width*0.5
    local scaleY = guiBomb:getContentSize().height/number:getContentSize().height*0.5
    number:setScale(scaleY)
    if hp%2 == 1 then
        spH = ccui.ImageView:create()
        spH:loadTexture(pngSjtH)
        guiBomb:addChild(spH)
    end
    if math.floor(hp/2)%2 == 1 then
        spV = ccui.ImageView:create()
        spV:loadTexture(pngSjtV)
        guiBomb:addChild(spV)
    end
    if math.floor(hp/4)%2 == 1 then
        spS = ccui.ImageView:create()
        spS:loadTexture(pngSjtS)
        guiBomb:addChild(spS)
    end
    return guiBomb
end