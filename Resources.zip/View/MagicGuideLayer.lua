local director = cc.Director:getInstance()
local winSize = director:getWinSize()

MagicGuideLayer = class("MagicGuideLayer")
MagicGuideLayer.__index = MagicGuideLayer
MagicGuideLayer._pointType = nil
MapW = 18
MapH = 12
function MagicGuideLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, MagicGuideLayer)
    return target
end

function MagicGuideLayer:init(toolType,mapbg,guideFlag)
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonMagicGuideLayer)
	self:addChild(self._widget,500)
	self._widget:setTouchEnabled(false)
	self.cancelBtn = self._widget:getChildByName("magicCancel")
	self.magicTool = self._widget:getChildByName("magicTool")
	self.magicLabel = self._widget:getChildByName("magicLabel")
	self.magicTool:setVisible(true)
	self.magicTool:loadTexture(string.format(pngMagic,toolType))
	local magicText = nil
	if toolType == magicSame then
		magicText = "Clean the same slime as clicked"
	elseif toolType == magicRow then
		magicText = "Kill slime in same row as clicked"
	elseif toolType == magicLine then
		magicText = "Kill slime in same line as clicked"
	elseif toolType == magicCross then
		magicText = "Clicked and nearby slime will turn into purple slime"
	end
	self.magicLabel:setText(magicText)

	local mapMagic = cc.TMXTiledMap:create(tmxMagicBG)

	local tileW = mapMagic:getTileSize().width
	--设置道具的大小
	local scale = tileW/self.magicTool:getContentSize().width
	self.magicTool:setScale(scale)

	--设置地图的位置
	local mapPos = cc.p(mapbg:getPosition())
	local posX = mapPos.x
	local posY = mapPos.y

	local orgJ = math.floor(posX/tileW)+1
	local stI = math.floor(posY/tileW)+1
	local orgI = MapH - stI - MapHeight
	local orgX = posX - orgJ*tileW
	local orgY = posY - stI*tileW

	mapMagic:setPosition(orgX,orgY)
	magicLayer = mapMagic:getLayer("layer1")
	print("posY",posY,orgY)
	self:addChild(mapMagic,250,100)
	for i=1,MapH do
		for j=1,MapW do
			if j <= orgJ or j > orgJ+MapWidth or i <= orgI or i > orgI+MapHeight then
				magicLayer:setTileGID(1,cc.p(j-1,i-1))
			else
				local sp = Map.getBlockSprite(mapbg,i-orgI+2,j-orgJ+2)
				if sp and sp:isGerm() then
					sp:removeAllChildren()
					--print("self.magicLabel",self.magicLabel)
					--print("toolType toolType",toolType)
					sp:useTool(toolType)
					magicLayer:setTileGID(2,cc.p(j-1,i-1))
				else
					magicLayer:setTileGID(1,cc.p(j-1,i-1))
				end
			end
		end
	end
	local hints = lv:getHintPoint()
    local magicType = lv:getMagicType()
    local gameScene = mapbg:getParent()
    if hints ~= false and hints[1] ~= nil and guideFlag == true and gameScene.magHintFlag == true then
        local i,j = hints[1].y,hints[1].x
        i,j = i+3,j+3
        
        local sp = Map.getBlockSprite(mapbg,i,j)
        if sp ~= nil then
        	print("Clicked,cur",getClickedTolLevel(),db:getCurLevel())
        	self.cancelBtn:setEnabled(false)
			ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniHand)
	   		local armature =  ccs.Armature:create("handAnimation")
	   		local p = cc.pAdd(cc.p(sp:getPosition()),cc.p(mapbg:getPosition()))
	   		armature:setAnchorPoint(0.25,0.75)
	   		armature:getAnimation():play("hintHand")  	
		    armature:setPosition(p)
		    armature:setScale(sp:getScale())    
		    gameScene:addChild(armature,gameScene:getLocalZOrder()+mapbg:getLocalZOrder()+1,5003)
		else
			print("sp is nil")
		end
    end


	local function cancelCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		--local parent = self:getParent()
		if ccui.TouchEventType.ended == event then
			if toolType == magicSame then
				db:updateCntSame(db:getCntSame()+1)
				gameScene.cntCln:updateCnt(db:getCntSame())
			elseif toolType == magicRow then
				db:updateCntRow(db:getCntRow()+1)
				gameScene.cntHor:updateCnt(db:getCntRow())
			elseif toolType == magicLine then
				db:updateCntLine(db:getCntLine()+1)
				gameScene.cntVtl:updateCnt(db:getCntLine())
			elseif toolType == magicCross then
				db:updateCntChange(db:getCntChange()+1)
				gameScenes.cntCge:updateCnt(db:getCntChange())
			end

			GameState = GameStateWaiting
			self:removeFromParent()
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end

	end 
	self.cancelBtn:addTouchEventListener(cancelCallBack)	
end


function MagicGuideLayer.create(toolType,mapbg,guideFlag)
	local dlg = MagicGuideLayer.extend(cc.Layer:create())
	dlg:init(toolType,mapbg,guideFlag)
	dlg:setLocalZOrder(1000)
	return dlg
end