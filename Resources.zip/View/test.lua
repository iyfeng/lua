begin
{
	....
	curX = touchX

}
moved
{
	preX = curX
	curX = touchX
}
ended
{
	curX = touchX
}




Map = {}  
Map = class("Map",
    function()
        return cc.Sprite:create()
    end
)
Map.__index = Map





function Map:init(type)
	print("type",type)
end

function Map.create()
	local sp = Map.new()
	sp:init(type)
	return sp
end

local sprite = Map.create(12)