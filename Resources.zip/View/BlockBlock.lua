BlockBlock = {}  
BlockBlock = class("BlockBlock",
    function()
        return BasicBlock.create()
    end)
BlockBlock.__index = BlockBlock







function BlockBlock.create(hp)
    local germ = BlockBlock.new()
    germ:initWithHp(hp)
    return germ
end


function BlockBlock:initWithHp(hp)
    self:setTexture(pngBlock)
    self.remainHp = hp
    --self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function BlockBlock:beHited( ... )
	self:smashed()
end