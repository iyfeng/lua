GermsDirectionBlock = {}
GermsDirectionBlock = {}  
GermsDirectionBlock = class("GermsDirectionBlock",
    function()
        return cc.Sprite:create()
    end
)
GermsDirectionBlock.__index = GermsDirectionBlock

function GermsDirectionBlock:initWithDirection(dir)
	self.isHalf = false
    self.direction = dir
    self.moveTimes = 0
	self:setTexture(string.format(pngChipDir,dir))
end

function GermsDirectionBlock.create(dir)
	local basic = GermsDirectionBlock.new()
	basic:initWithDirection(dir)
	return basic
end

function GermsDirectionBlock:changeToDirection(dir)

    if dir==self.direction then
        return
    end
    self.direction = dir
    self:setTexture(string.format(pngChipDir,dir))
end

function GermsDirectionBlock:setInfo(target)

	local posX,posY = target:getPosition()
	local scale = target:getScale()
	local conW = target:getContentSize().width * scale/2
	--local conH = target:getContentSize().height
	self:setScale(scale)
	local pos1,pos2 = 0,0
	local ans1,ans2 = 1,1
	if self.direction == BasicBlock.Direction.DirectionUp then
		ans2 = 2
	elseif self.direction == BasicBlock.Direction.DirectionDown then
		ans2 = 0
		--ans1 = 0
	elseif self.direction == BasicBlock.Direction.DirectionLeft then
		ans1 = 0		
	elseif self.direction == BasicBlock.Direction.DirectionRight then
		ans1 = 2
	else
		self:removeFromParent()
		return
	end	

	self:setPosition(cc.p(posX+conW*pos1,posY+conW*pos2))		
	self:setAnchorPoint(0.5*ans1,0.5*ans2)	
end

function GermsDirectionBlock:getPos()
	--print(self:getParent():getDescription())
	local i,j = Map.getTileCoordinateFromSprite(self)
	
	if self.direction ~= BasicBlock.Direction.DirectionUp then
		--i = i-1
		--j = j+1
	end
	-- print("pos1 i j",i,j)
	return i,j
end


function GermsDirectionBlock:flyTo(halfFlag,startPosX,startPosY)
	-- print("possss:",halfFlag,startPosX,startPosY);
	local dirTime = 0.1
	local mapbg = self:getParent()
	local function canDrop()
		--print("here",germInFly,Map.BombHited)
		if germInFly == 0 and Map.BombHited == true then 
			if countRecover ~= 0 then
				for i=1,countRecover do
					--print("countRecover",countRecover,i,targetRecover[i].x,targetRecover[i].y)
					local sprite = Map.getBlockSprite(mapbg,targetRecover[i].x,targetRecover[i].y)
					sprite:result()
				end
			end
			print("here we go")
			local function dropNow()
				print("GameState",GameState)
				Map.drop(mapbg)
			end
			local maxDelay = math.max(unpack(delayT)) + 0.1
			delayT={0}
			--print("maxDelay",maxDelay)
			mapbg:runAction(cc.Sequence:create(cc.DelayTime:create(maxDelay),cc.CallFunc:create(dropNow)))
		end
	end
	canDropback = cc.CallFunc:create(canDrop)

	germInFly = germInFly+1
	--print("germInFly+",germInFly)
	local parent = self:getParent()
	local i,j = self:getPos()
	local closeRebound = false
	local movI,movJ = 0,0
	local tileW = self:getParent():getLayer("layer"):getMapTileSize().width/2
	
	if startPosX ~= nil then
		if (mapInfo[i+3][j+2].type == BasicBlock.BlockType.BlockTypeRebound or mapInfo[i+2][j+3].type == BasicBlock.BlockType.BlockTypeRebound) then
			closeRebound = true
		else
			closeRebound = false
		end
	end
	if self.direction == BasicBlock.Direction.DirectionUp then
		i = i - 1
		movI = tileW
		if self.beBounded == true then
			i = i + 1
			self.beBounded = nil
			movI = 0
		end
	elseif self.direction == BasicBlock.Direction.DirectionDown then
		i = i + 1
		movI = -tileW
		if self.beBounded == true then
			i = i - 1
			self.beBounded = nil
			movI = 0
		end
	elseif self.direction == BasicBlock.Direction.DirectionLeft then
		j = j - 1
		movJ = -tileW
		if self.beBounded == true then
			j = j + 1
			self.beBounded = nil
			movJ = 0
		end
	elseif self.direction == BasicBlock.Direction.DirectionRight then
		j = j + 1
		movJ = tileW
		if self.beBounded == true then
			j = j - 1
			self.beBounded = nil
			movJ = 0
		end
	else		
		if self.beBounded == true then
			self.beBounded = nil
		end
		germInFly = germInFly - 1
		--print("germInFly-1",germInFly)
		self:removeFromParent()
		mapbg:runAction(canDropback)
		return
	end
	--print("pos2 i j",i,j)
	--print("mapInfo",mapInfo[i+2][j+2].type)

	--边界
	if i < 0 or j < 0 or i > MapHeight+1 or j > MapWidth+1 then
		local function callDisappear()
			germInFly = germInFly - 1
			--print("germInFly-5",germInFly)
			self:removeFromParent()
		end
		callback = cc.CallFunc:create(callDisappear)
		--moveby = cc.MoveBy:create(0.2,cc.p(movJ,movI))
		--self:runAction(cc.Sequence:create(moveby,callback))
		self:runAction(cc.Sequence:create(callback,canDropback))
		return
	end

	local co
	if i == 6 and j == 2 then
		--print("maoInfo isEmpty hp type tag j",mapInfo[i+2][j+2].isEmpty,mapInfo[i+2][j+2].hp,mapInfo[i+2][j+2].type,mapInfo[i+2][j+2].tag,j,parent:getChildByTag(mapInfo[i+2][j+2].tag))
	end
	if i == 7 and j == 1 then
		--print("maoInfo isEmpty hp type tag j",mapInfo[i+2][j+2].isEmpty,mapInfo[i+2][j+2].hp,mapInfo[i+2][j+2].type,mapInfo[i+2][j+2].tag,j)
	end
	
	if mapInfo[i+2][j+2].type == 1 and mapInfo[i+2][j+2].isEmpty == 0 then   --普通怪物升一级
		local function callDisappear()
			
			if mapInfo[i+2][j+2].tag ~= nil and parent:getChildByTag(mapInfo[i+2][j+2].tag) ~= nil then
				co = coroutine.create(function ()
					if Map.getBlockSprite(parent,i+2,j+2).itemType == 0 then
						print("why always this happens",i+2,j+2)
						Map.getBlockSprite(parent,i+2,j+2):removeFromParent()
						
					end
					Map.getBlockSprite(parent,i+2,j+2):updateOneType()
					--print("tag",self:getTag())
					germInFly = germInFly - 1
					--print("germInFly-2",germInFly)
					self:removeFromParent()
					coroutine.yield()
					end)
				coroutine.resume(co)				
			elseif parent:getChildByTag(mapInfo[i+2][j+2].tag) == nil then
				self:flyTo()
				germInFly = germInFly - 1
			end
		end
		callback = cc.CallFunc:create(callDisappear)
		if halfFlag == nil then
			moveby = cc.MoveBy:create(dirTime*1.5,cc.p(movJ*2,movI*2))
		else
			moveby = cc.MoveBy:create(dirTime/2,cc.p(movJ,movI))
		end
		--self:runAction(cc.Sequence:create(moveby,callback))
	elseif mapInfo[i+2][j+2].type == 0 or mapInfo[i+2][j+2].isEmpty == 1 then  --图块为空

		local function callDisappear()			
			self:flyTo()
			germInFly = germInFly - 1
			--print("germInFly-3",germInFly)
			--[[
			if i == 1 and j == 3 then
				print("germInFly-3",germInFly)
			end
			]]--
		end
		callback = cc.CallFunc:create(callDisappear)
		if halfFlag == nil then
			moveby = cc.MoveBy:create(dirTime/2,cc.p(movJ,movI))
		else
			moveby = cc.MoveBy:create(0,cc.p(0,0))
		end
		--self:runAction(cc.Sequence:create(moveby,callback))
	elseif mapInfo[i+2][j+2].type == BasicBlock.BlockType.BlockTypeRebound then --圆盘反弹
		local dir
		if self.direction == BasicBlock.Direction.DirectionUp then
			dir = BasicBlock.Direction.DirectionDown
		elseif self.direction == BasicBlock.Direction.DirectionDown then
			dir = BasicBlock.Direction.DirectionUp
		elseif self.direction == BasicBlock.Direction.DirectionLeft then
			dir = BasicBlock.Direction.DirectionRight
		elseif self.direction == BasicBlock.Direction.DirectionRight then
			dir = BasicBlock.Direction.DirectionLeft
		end
		local function callDisappear()
			if mapInfo[i+2][j+2].tag ~= nil and parent:getChildByTag(mapInfo[i+2][j+2].tag) ~= nil then
			co = coroutine.create(function ()
				local delayTemp = parent:getChildByTag(mapInfo[i+2][j+2].tag):beHited()
				if delayTemp == nil then delayTemp = 0 end
				table.insert(delayT,delayTemp)	
				coroutine.yield()
				end)
			coroutine.resume(co)				
			end
			self:changeToDirection(dir)			
			self:flyTo()
			germInFly = germInFly - 1
			closeRebound = 0
			--print("germInFly-6",germInFly)
		end
		callback = cc.CallFunc:create(callDisappear)
		if halfFlag == nil then
			-- print("countnumber:",closeRebound)
			-- print("dfgd",cc.pGetDistance(cc.p(self:getPos()),cc.p(oldI,oldJ)),x,y,i,j)
			-- if self.direction == BasicBlock.Direction.DirectionDown then
			-- 	if not closeRebound then
			-- 		moveby = cc.MoveBy:create(dirTime/2 * 1.4,cc.p(movJ * 1.4,movI * 2.4))
			-- 		print("short")
			-- 	else
			-- 		moveby = cc.MoveBy:create(dirTime/2 * 1.4,cc.p(movJ * 1.4,movI * 1.4))
			-- 		print("long")
			-- 	end	
			-- else
			-- 	moveby = cc.MoveBy:create(dirTime/2 * 1.4,cc.p(movJ * 1.4,movI * 1.4))
			-- 	print("only one")
			-- end
			moveby = cc.MoveBy:create(dirTime/2 * 1.4,cc.p(movJ * 1.4,movI * 1.4))
		else
			self.beBounded = true
			moveby = cc.MoveBy:create(0,cc.p(0,0))
		end

	--45度弹簧
	elseif mapInfo[i+2][j+2].type >= BasicBlock.BlockType.BlockTypePartBounceUp and mapInfo[i+2][j+2].type <= BasicBlock.BlockType.BlockTypePartBounceRight then
		local dir
		local pos1,pos2 = 0,0
		local ans1,ans2 = 1,1
		local posX,posY = parent:getChildByTag(mapInfo[i+2][j+2].tag):getPosition()
		local conW = parent:getLayer("layer"):getMapTileSize().width/2
		if mapInfo[i+2][j+2].type == BasicBlock.BlockType.BlockTypePartBounceUp then
			if self.direction == BasicBlock.Direction.DirectionDown then
				dir = BasicBlock.Direction.DirectionLeft
				ans1 = 0
				pos1 = -1
			elseif self.direction == BasicBlock.Direction.DirectionRight then
				dir = BasicBlock.Direction.DirectionUp
				--i = i - 1
				ans2 = 0
				pos2 = 0.01
			else
				dir = BasicBlock.Direction.DirectionStop
				movJ = movJ/2
				movI = movI/2
			end
		elseif mapInfo[i+2][j+2].type == BasicBlock.BlockType.BlockTypePartBounceLeft then
			if self.direction == BasicBlock.Direction.DirectionUp then
				dir = BasicBlock.Direction.DirectionLeft
				ans1 = 0
				pos1 = -1
			elseif self.direction == BasicBlock.Direction.DirectionRight then
				dir = BasicBlock.Direction.DirectionDown
				ans2 = 0
				pos2 = -0.999
			else
				dir = BasicBlock.Direction.DirectionStop
				movJ = movJ/2
				movI = movI/2
			end
		elseif mapInfo[i+2][j+2].type == BasicBlock.BlockType.BlockTypePartBounceDown then
			if self.direction == BasicBlock.Direction.DirectionUp then
				dir = BasicBlock.Direction.DirectionRight
				ans1 = 0
			elseif self.direction == BasicBlock.Direction.DirectionLeft then
				dir = BasicBlock.Direction.DirectionDown
				ans2 = 0
				pos2 = -0.999
			else
				dir = BasicBlock.Direction.DirectionStop
				movJ = movJ/2
				movI = movI/2
			end
		elseif mapInfo[i+2][j+2].type == BasicBlock.BlockType.BlockTypePartBounceRight then
			if self.direction == BasicBlock.Direction.DirectionLeft then
				dir = BasicBlock.Direction.DirectionUp
				ans2 = 0
				pos2 = 0.01
				--i = i - 1
			elseif self.direction == BasicBlock.Direction.DirectionDown then
				dir = BasicBlock.Direction.DirectionRight
				ans1 = 0
			else
				dir = BasicBlock.Direction.DirectionStop
				movJ = movJ/2
				movI = movI/2
			end
		end

		local function callDisappear()
			if dir == BasicBlock.Direction.DirectionStop then
				germInFly = germInFly - 1
				self:removeFromParent()
				return
			end
			if mapInfo[i+2][j+2].tag ~= nil and parent:getChildByTag(mapInfo[i+2][j+2].tag) ~= nil then
			co = coroutine.create(function ()
				local delayTemp = parent:getChildByTag(mapInfo[i+2][j+2].tag):beHited()
				if delayTemp == nil then delayTemp = 0 end
				table.insert(delayT,delayTemp)		
				coroutine.yield()
				end)
			coroutine.resume(co)				
			end
			self:changeToDirection(dir)	
			self:setPosition(cc.p(posX+conW*pos1,posY+conW*pos2))		
			self:setAnchorPoint(0.5*ans1,0.5*ans2)
			--local co1 = coroutine.create(function ()
				self:flyTo(true)
			--	coroutine.yield()
			--	end)
			--coroutine.resume(co1)	
			germInFly = germInFly - 1			
			--print("germInFly-7",germInFly)
		end
		callback = cc.CallFunc:create(callDisappear)
		if halfFlag == nil then
			moveby = cc.MoveBy:create(dirTime*1,cc.p(movJ*2,movI*2))
		else
			moveby = cc.MoveBy:create(dirTime/2,cc.p(movJ,movI))
		end

	else                                                      --其他怪物
		local function callDisappear()
			if mapInfo[i+2][j+2].tag ~= nil and parent:getChildByTag(mapInfo[i+2][j+2].tag) ~= nil then
			co = coroutine.create(function ()
				local delayTemp = parent:getChildByTag(mapInfo[i+2][j+2].tag):beHited()
				if delayTemp == nil then delayTemp = 0 end
				table.insert(delayT,delayTemp)	
				coroutine.yield()
				end)
			coroutine.resume(co)				
			end
			self:removeFromParent()
			germInFly = germInFly - 1
			--print("germInFly-4",germInFly)
		end
		callback = cc.CallFunc:create(callDisappear)
		if halfFlag == nil then
			moveby = cc.MoveBy:create(dirTime,cc.p(movJ * 2,movI * 2))
		else
			moveby = cc.MoveBy:create(0,cc.p(0,0))
		end
		--self:runAction(cc.Sequence:create(moveby,callback))
	end 
	--print("delayT",delayT)
	--local delayTime = cc.DelayTime:create(0.7)
	self:runAction(cc.Sequence:create(moveby,callback,canDropback))
end



