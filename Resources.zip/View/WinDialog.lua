local director = cc.Director:getInstance()
local winSize = director:getWinSize()

WinDialog = class("WinDialog")
WinDialog.__index = WinDialog
WinDialog._pointType = nil

function WinDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, WinDialog)
    return target
end

function WinDialog:init(levelType )
	--通过判断相应分数所获得的星星数，来决定弹出的对话框，是否含有retry 按钮
	apM:addOne()
	local socTargets = lv:getScoreTarget()
	local star = 0
	for i=1,3 do
		if totalScore >=socTargets[i] then
			star = star + 1
		end
	end
	audio:playEffect("audio/XL002.mp3")
	self._levelType = levelType
	--print("lhfleveltype:",levelId,levelType)
	if star == 3 then
		self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonWinDlg)
	else
		self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonWinRetryDlg)
	end
	self:addChild(self._widget)
	local background = self._widget:getChildByName("bgDlg")
	local closeBtn = background:getChildByName("close")
	local nextBtn = background:getChildByName("nextButton")
	local levelsta = background:getChildByName("levelPanel"):getChildByName("staticlevel")
	local levelLbl = background:getChildByName("levelPanel"):getChildByName("levelnum")
	self.txScore = background:getChildByName("props"):getChildByName("targetNum")

	local toBig1 = cc.ScaleBy:create(0.7,0.97,1.02)
	local toSmall1 = toBig1:reverse()
	local bigSmallRepeat = cc.Sequence:create(toBig1,toSmall1)

	if star ==0 then
		for i=1,3 do
			local starPanel = background:getChildByName("threeStarsPanel"):getChildByName(string.format("bgStar%d",i))
			starPanel:setVisible(false)
		end
	else
		if star ~=3 then
			for i=1,3 do
				local starPanel = background:getChildByName("threeStarsPanel"):getChildByName(string.format("bgStar%d_gray",i))
				starPanel:setVisible(false)
			end
		end
		--显示星星的动画
		local  function displayStars()
			for i=dlgStarPanel+4,dlgStarPanel+3+star,1 do
				
				local stars = background:getChildByName("threeStarsPanel"):getChildByTag(i)
				local function playStars()
					self:starAnimation(stars,i-dlgStarPanel-3)
				end
				stars:runAction(cc.Sequence:create(cc.DelayTime:create(0.4+0.6*(i-dlgStarPanel-4)),cc.ScaleTo:create(0.15,0.6,0.8),cc.CallFunc:create(playStars)))
				
			end
		end
		self:runAction(cc.CallFunc:create(displayStars))
	end
	
	if star ~=3 then
		local retryBtn = background:getChildByName("RetryButton");
		local function retryCallBack(sender,event)
			local toBig = cc.ScaleBy:create(0.1,1.1)
			local toSmall = toBig:reverse()
			local bigSmall = cc.Sequence:create(toBig,toSmall)
			local gameScene = self:getParent()
			
			if ccui.TouchEventType.ended == event then
				audio:playEffect("audio/SND008.mp3")
				local function retry()
					self:getParent()._clicked = false
					self:removeFromParent()
					runGameScene(levelType)				
				end
				self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(retry)))

			elseif ccui.TouchEventType.began == event then
				sender:runAction(bigSmall) 
			end
		end
		retryBtn:addTouchEventListener(retryCallBack)
		
		retryBtn:runAction(cc.RepeatForever:create(bigSmallRepeat))
	else
		nextBtn:runAction(cc.RepeatForever:create(bigSmallRepeat))
	end

	--设置关卡等级显示
	if levelType < taskIndex then
		levelLbl:setText(levelType)
	else
		levelsta:setText("Quest")
		local queT = levelType % taskIndex
		print("queT,levelType",queT,levelType)
		levelLbl:setText(queT)
	end
	levelLbl:setPosition(100,200)
	self:setScoreAndStar()
	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:getParent()._clicked = false
				self = nil
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	--closeBtn:addTouchEventListener(closeCallBack)

	local function nextCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		local parent = self:getParent()
		clkIndex = getClickedIndex()
		cclog("game Start %d",levelType)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function replaceSce()
				if levelType > taskIndex then
					local idxType = math.floor(levelType/taskIndex)
					local gameScene,lvLayer = LevelLayer.create(idxType)
					director:replaceScene(gameScene)
					if levelType%taskIndex ~= 3 then
						apM:lastPassTime()
						lv = nil
						lv = LevelInfo:getInstance(taskIndex)
						local qtDlg = QuestDialog.create(idxType,true,true)
						gameScene:addChild(qtDlg)
						local i0 = (db:getLevelFromTaskTb()-1)%3+1
						local function delayCall()
							--print("it is call")
							qtDlg.quests[i0]:playUnlockAnimationTk(levelType)
						end
						qtDlg:runAction(cc.Sequence:create(cc.DelayTime:create(0.9),cc.CallFunc:create(delayCall)))
					else
						--print("totalLevel",totalLevel)
						apM:lastPassTimeToZero()
						lvLayer.LevelButton[totalLevel+1]:playUnlockAnimation(levelType)
					end
					return
				end
				if levelType  == curLevel then
					local gameScene,lvLayer = LevelLayer.create(curIndex)
					director:replaceScene(gameScene)
					local levelT = (levelType-1)%15 + 1 
					if levelT ~= totalLevel then
						updateLastLevel()
						local function pUCB()
							lvLayer.LevelButton[levelT + 1]:playUnlockAnimation(levelType)
						end
						local function dlgC()
							local lvDlg = LevelDialog.create(levelT+1)
							gameScene:addChild(lvDlg)
						end
						local pC = cc.CallFunc:create(pUCB)
						local dC = cc.CallFunc:create(dlgC)
						local delay = cc.DelayTime:create(2)
						gameScene:runAction(cc.Sequence:create(pC,delay,dC))
					else
						lvLayer.LevelButton[levelT + 1]:playUnlockAnimation(levelType)
					end
				else
					self:removeFromParent()
					local levelT = (levelType-1)%15 + 1
					if levelT ~= totalLevel then
						levelT = levelT + 1
					else
						levelT = 1
						setClickedIndex(clkIndex+1)
					end
					--print("clkIndex pre",getClickedIndex())
					if clkIndex ~= getClickedIndex() then
						--print("clicked index")
						clkIndex = getClickedIndex()
						lv = nil
						lv = LevelInfo:getInstance(clkIndex)
					end
					lvDlg = LevelDialog.create(levelT)
					parent:addChild(lvDlg)
				end
			end
			self:runAction(cc.CallFunc:create(replaceSce))

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end  
	nextBtn:addTouchEventListener(nextCallBack)
	closeBtn:addTouchEventListener(nextCallBack)
end


function WinDialog:starAnimation(cntStar,starOrder)
	--print(cntStar:getWorldPosition())
	-- doAnimate(jsonAniBoss,"BossAnimation",animationHit,0.1,self:bossState(backImage))
	effect:doAnimation(cntStar,self,"g01",40/60)
	if starOrder == 1 then
	 effect.armature:setRotation(-20)
	elseif starOrder == 3 then
		effect.armature:setRotation(20)
	end
	effect.armature:setScale(cntStar:getScaleX(),cntStar:getScaleY())
	effect:doAnimation(cntStar,self,"sg01",78/60)
	if starOrder == 1 then
	 effect.armature:setRotation(-20)
	elseif starOrder == 3 then
		effect.armature:setRotation(20)
	end
	effect.armature:setScale(cntStar:getScaleX(),cntStar:getScaleY())
	--print("cntStar",cntStar)
	self:runAction(cc.DelayTime:create(1))
end

function WinDialog:setScoreAndStar()
	self.txScore:setText(totalScore)
	local socTargets = lv:getScoreTarget()
	local star = 0
	print("second")
	for i=1,3 do
		if totalScore >=socTargets[i] then
			star = star + 1
		end
	end
	if self._levelType < taskIndex then
		if db:getScore(self._levelType) == nil then
			db:addToLevelTb(totalScore,star,self._levelType)
		end
		if db:getScore(self._levelType) ~= nil and db:getScore(self._levelType) < totalScore then
			db:updateScoreAndStar(totalScore,star,self._levelType)
		end
	else
		db:addToTaskTb(totalScore,star)
	end
end
function WinDialog.create(levelType )
	
	local dlg = WinDialog.extend(cc.Layer:create())
	dlg:init(levelType)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(1000)
	return dlg
end

