local director = cc.Director:getInstance()
local winSize = director:getWinSize()

SettingDialog = class("SettingDialog")
SettingDialog.__index = SettingDialog
SettingDialog._pointType = nil

function SettingDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, SettingDialog)
    return target
end

function  SettingDialog:init( ... )
	print("enter")
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonSettingDlg)

	self:addChild(self._widget)
	local background = self._widget:getChildByTag(dlgBg)
	local closeBtn = background:getChildByTag(dlgClose)
	local purchaseBtn = background:getChildByTag(dlgPurchase)
	local soundBtn,musicBtn
	if db:getMusicState() == 1 then
		musicBtn = background:getChildByTag(dlgMusic):getChildByTag(1)
		background:getChildByTag(dlgMusic):getChildByTag(0):setEnabled(false)
	else
		musicBtn = background:getChildByTag(dlgMusic):getChildByTag(0)
		background:getChildByTag(dlgMusic):getChildByTag(1):setEnabled(false)
	end
	if db:getSoundState() == 1 then
		soundBtn = background:getChildByTag(dlgSound):getChildByTag(1)
		background:getChildByTag(dlgSound):getChildByTag(0):setEnabled(false)
	else
		soundBtn = background:getChildByTag(dlgSound):getChildByTag(0)
		background:getChildByTag(dlgSound):getChildByTag(1):setEnabled(false)
	end

	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
		audio:playEffect("audio/SND008.mp3")
			local function destroy()
			self:getParent()._clicked = false
			self = nil
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	local function purchaseCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			print("purchaseCallBack")
			audio:playEffect("audio/SND008.mp3")
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	purchaseBtn:addTouchEventListener(purchaseCallBack)

	local function musicOnOff(sender,event)
	print("music")
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			
			if db:getMusicState() == 1 then
				db:updateMusicState(0)
				sender:loadTexture(pngMusicOff)
				cc.SimpleAudioEngine:getInstance():pauseMusic()
				audio:playEffect("audio/SND008.mp3")
			else
				db:updateMusicState(1)
				sender:loadTexture(pngMusicOn)
				audio:playEffect("audio/SND008.mp3")
				cc.SimpleAudioEngine:getInstance():resumeMusic()
			end
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	musicBtn:addTouchEventListener(musicOnOff)

	local function soundOnOff(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			print("sound")
			if db:getSoundState() == 1 then
				db:updateSoundState(0)
				sender:loadTexture(pngSoundOff)
				audio:playEffect("audio/SND008.mp3")
			else
				db:updateSoundState(1)
				sender:loadTexture(pngSoundOn)
				audio:playEffect("audio/SND008.mp3")
			end
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	soundBtn:addTouchEventListener(soundOnOff)
	
end

function SettingDialog.create()
	local dlg = SettingDialog.extend(cc.Layer:create())
	dlg:init()
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end