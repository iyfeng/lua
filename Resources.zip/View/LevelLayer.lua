require "View/LevelPoint"
require "View/ActionPoint"
require "View/LevelDialog"
require "View/GameScene"
require "View/MoreLivesDialog1"
require "View/UnlockPartDialog"

local director = cc.Director:getInstance()
local visibleSize = director:getVisibleSize()
local origin = director:getVisibleOrigin()
local winSize = director:getWinSize()
local sfCache = cc.SpriteFrameCache:getInstance()
local schedule = director:getScheduler()

LevelLayer = class("LevelLayer")
LevelLayer.__index = LevelLayer
LevelLayer._widget = nil
LevelLayer._indexType = nil

local balX = winSize.width % 8
local balY = winSize.height % 5
LevelLayer.pointW = (winSize.width - balX)/8
LevelLayer.pointH = (winSize.height - balY)/5
LevelLayer.originPX = balX/2 + (winSize.width - balX)/8 - winSize.width/2
LevelLayer.originPY = balY/2 + (winSize.height - balY)/5 - winSize.height/2
LevelLayer.LevelButton = {}

function LevelLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, LevelLayer)
    return target
end
function LevelLayer:init( indexType )
	self._indexType = indexType
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonLevelScene)
	--layer =cc.Layer:create()
	self:addChild(self._widget)
	self.roomLayer = self._widget:getChildByTag(roomBg)
	self.roomLayer:loadTexture(string.format(pngRoomPart,indexType))

	--增加爱心
	self.heart = ActionPoint.create(self._widget)


	self.LevelButton = {}
	for i=0,totalLevel+1 do
		if i == 0 then
			self.LevelButton[i] = self._widget:getChildByTag(roomBack)
			self.LevelButton[i]:setPositionPercent(cc.p(0.05,0.09))

		else
			self.LevelButton[i] = self:pointToScreen(i)
			self:addSpArrow(i)
		end
	end 
	self:setPointsLocked()
	-- print("lhfaddpar",indexType,totalLevel,self.LevelButton[totalLevel].locked,self.LevelButton[totalLevel+1].locked)
	-- lhf添加粒子效果测试 每小关的最后一关添加粒子，16关
	if self.LevelButton[totalLevel].locked ==false and self.LevelButton[totalLevel+1].locked == true then
		effect:setParticleForLevel(self,self.LevelButton[totalLevel+1])
	end

	--设置小关按钮和返回按钮的回调函数
	local function indexCallBack(sender,event)

		local levelTag = sender:getTag() - roomBack
		cclog("levelTag: %d",levelTag)
		setClickedLevel(levelTag)
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function replaceSce()
				local scene = nil

				--如果非返回键，并且关卡已锁，则返回
				-- if levelTag ~=0 and sender.locked == true then return end
				
				if levelTag == 0 then
					self:backToRoomScene()
				elseif levelTag ~= totalLevel + 1 then
					local indexType = self._indexType - 1
					--[[
					if levelTag > self:getUnlockedLevels()-1 then
						self:addSpLine(levelTag+1,true)
						self.LevelButton[levelTag + 1].locked = false
						
						--增加星星
						for i=1,3 do
								self.LevelButton[levelTag]:addStar(i,true)
						end
						
						--如果不是最后一关
						if levelTag ~= totalLevel then
							self.LevelButton[levelTag + 1]:playUnlockAnimation()
							updateLastLevel()
								
						end
						cclog("ing goto game")
						
						cclog("go to game ok")
					else
					
					end
					]]--

					if self._clicked ~= true then
						
						self._clicked = true
						if apM:getAp() <= 0 then
							addMaskBg(self)
							local dlg = MoreLivesDialog1.create(self.heart)
   							self:addChild(dlg)   							
   						else
   							addMaskBg(self)
							local dlg = LevelDialog.create(levelTag)							
							self:addChild(dlg)

							dlgX,dlgY = dlg:getPosition()
							dlg:setPosition(cc.p(dlgX,winSize.height))
							dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
						end
					
					end
				else

					self:unlockToRoomScene()
					-- lhf添加粒子效果测试
					if self:getChildByTag(10086) then
						self:removeChildByTag(10086)
					end

				end
			end
			sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	for i=0,totalLevel+1 do
			self.LevelButton[i]:addTouchEventListener(indexCallBack)
	end
end

function LevelLayer:getRoomType(indexType)
	return math.floor((indexType - 1)/totalIndex) + 1
end

function LevelLayer:backToRoomScene()
	audio:playEffect("audio/SND008.mp3")
	local roomType = self:getRoomType(self._indexType)
	cclog("roomType:%d,indexType %d",roomType,self._indexType)
	runInRoomScene(roomType)
end

function LevelLayer:pointToScreen(levelType)
	local x = points1[self._indexType][levelType].width 
	local y = points1[self._indexType][levelType].height
	local indexType = self._indexType - 1
	local levelId = levelType + indexType*totalLevel 
	local image = LevelPoint.create(levelType,levelId)
	image:setPosition(self.originPX + self.pointW * x,self.originPY + self.pointH * y)
	local scale = self.pointH/image:getContentSize().height * 0.8
	image:setScale(scale)
	if levelType ~= totalLevel + 1 then
		image:getChildByTag(2):setScale(0.8/scale)
		--image:getChildByTag(2):setText(string.format("%d",levelId))
		--cclog(image:getChildByTag(2):getFontName())
	end
	--cclog("image posX %f posY %f",image:getPosition())
	self.roomLayer:addChild(image)
	image:setLocalZOrder(10)
	return image
end

function LevelLayer:addSpLine(i,playFlag)
	if i == 1 then
		return
	end
	local line = ccui.ImageView:create()
	line:loadTexture(pngSpLine)
	local scale = nil
	line:setLocalZOrder(self.LevelButton[i]:getLocalZOrder() - 1)
	local curX,curY = self.LevelButton[i]:getPosition()
	local preX,preY = self.LevelButton[i-1]:getPosition()
	if curX == preX then
		scale = math.abs(curY - preY) / line:getContentSize().width * 0.8
		line:setScale(scale)
		if playFlag == false then
			line:setPosition(curX,(curY + preY)/2)
		else
			line:setPosition(curX,preY)
			line:runAction(cc.MoveTo:create(0.6,cc.p(curX,(curY + preY)/2)))
		end
		line:setRotation(90)
	end
	if curY == preY then
		scale = math.abs(curX - preX) / line:getContentSize().width * 0.6
		line:setScale(scale)
		
		if playFlag == false then
			line:setPosition((curX + preX)/2,curY)
		else
			line:setPosition(preX,curY)
			line:runAction(cc.MoveTo:create(0.6,cc.p((curX + preX)/2,curY)))
		end
		
	end
	self.roomLayer:addChild(line)
end

function LevelLayer:addSpArrow(i)
	if i == 1 then
		return
	end
	local arrow = ccui.ImageView:create()
	arrow:loadTexture(pngSpArrow)
	arrow:setAnchorPoint(0,0.5)
	local scale = self.pointH/2/arrow:getContentSize().width
	arrow:setScale(scale)
	arrow:setLocalZOrder(self.LevelButton[i]:getLocalZOrder() - 2)
	local curX,curY = self.LevelButton[i]:getPosition()
	local preX,preY = self.LevelButton[i-1]:getPosition()
	if curX == preX then
		if curY > preY then
			arrow:setRotation(-90)
		else
			arrow:setRotation(90)
		end		
	end
	if curY == preY then
		if curX > preX then
			
		else
			arrow:setRotation(180)
		end	
	end
	arrow:setPosition(preX,preY)
	self.roomLayer:addChild(arrow)
end


function LevelLayer:goIntoPlay( levelType )
	cclog("you choose Level %d to play",levelType);
end

function LevelLayer:unlockToRoomScene()
	local idxTemp = self._indexType
	cclog("in")
	if idxTemp == allIndex then
		print("new level coming soon")
		return
	end
	--若进入未解锁关，大关卡+1
	if self:checkIfToUnlock() == true then
		 idxTemp = idxTemp + 1
	end
	local roomType = self:getRoomType(idxTemp)
	local idxType = (idxTemp % totalIndex)~=0 and (idxTemp % totalIndex) or idxTemp
	cclog("idxType %d",idxType)
	
	if isTaskFinished(self._indexType) then
		local scene =  InOneRoomLayer.create( roomType )
		director:replaceScene(scene)
	
		--如果非解锁关，则返回
		if self:checkIfToUnlock() == false then return end
		
		updateLastLevel()
		local layer = scene:getChildByTag(0)
		local index = layer.roomLayer:getChildByTag(roomBack + idxType)
		local ix,iy = index:getPosition()
		local scale = index:getScale()
		local szP=index:getSizePercent()
		local scaleX = winSize.width*szP.x/index:getContentSize().width * scale
		local scaleY = winSize.height*szP.y/index:getContentSize().height * scale
		index:getChildByTag(20):setVisible(false)
		index:loadTexture(pngBgLocked)
		layer:addChild(layer.armature)
		layer.armature:setScaleX(scaleX)
		layer.armature:setScaleY(scaleY)
		layer.armature:setPosition(cc.p(ix + winSize.width/2,iy + winSize.height/2))

		layer.armature:getAnimation():play("unlocking")
		
		function unlockCallBack()
			layer.armature:setVisible(false)
			layer:setLevelUnLocked(idxType)
		end
		
		index.isLocked = false
		index:runAction (cc.Sequence:create(cc.DelayTime:create(0.6),cc.ScaleBy:create(0.1,0.3),cc.CallFunc:create(unlockCallBack),cc.ScaleBy:create(0.1,0.3):reverse()))
	else
		addMaskBg(self)
		self:addChild(UnlockPartDialog.create(self._indexType))
	end
end


--判断是否进入一个未解锁关
function LevelLayer:checkIfToUnlock()
	cclog("%d,%d",self._indexType,curIndex)
	if self._indexType < curIndex or self._indexType == allIndex then
		return false
	else
		return true
	end
end

--获得解锁关卡个数
function LevelLayer:getUnlockedLevels( ... )
	if self._indexType < curIndex then 
		return totalLevel+1
	elseif self._indexType == curIndex then
		return (curLevel-1)%totalLevel+1
	else
		return 0
	end
end

--设置所有未解锁关卡
function LevelLayer:setPointsLocked()
	for i=1,self:getUnlockedLevels() do
		self.LevelButton[i].locked = false
		self:addSpLine(i,false)
	end
	for i=self:getUnlockedLevels()+1,totalLevel+1 do	
		self.LevelButton[i].locked = true
		if i ~= totalLevel+1 then
			self.LevelButton[i]:setLockedByFlag(true)
		end
	end
end

function LevelLayer:onNodeEvent(event)
	print("cin sisida ",event)
	local function updateTime()
		self.heart:updateTime()
	end
	if event == "enter" then
		self.entry =  schedule:scheduleScriptFunc(updateTime,1,false)
	elseif event == "cleanup" then
		
		if self.entry  ~= nil then
			print("exit ok")
			schedule:unscheduleScriptEntry(self.entry )
		end
	end
end

function LevelLayer.create( indexType )
	setClickedIndex(indexType)
	lv = nil
	lv = LevelInfo:getInstance(indexType)
	local scene = cc.Scene:create()
	local layer = LevelLayer.extend(cc.Layer:create())
	local function onNodeEvent(event)
		layer:onNodeEvent(event)
	end
	layer:init(indexType)
	scene:addChild(layer)
	scene:registerScriptHandler(onNodeEvent)
	return scene,layer
end




function runLevelScene(indexType)
	local scene = LevelLayer.create(indexType)
	director:replaceScene(scene)
	--return scene
end