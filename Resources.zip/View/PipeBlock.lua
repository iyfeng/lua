PipeBlock = {}  
PipeBlock = class("PipeBlock",
    function()
        return BasicBlock.create()
    end)
PipeBlock.__index = PipeBlock







function PipeBlock.create(hp)
    local germ = PipeBlock.new()
    germ:initWithHp(hp)
    return germ
end


function PipeBlock:initWithHp(hp)
    self:setTexture(pngPipe)
    --self:addChild(HpPanel.create(hp))
end

function PipeBlock:beHited()
	
end