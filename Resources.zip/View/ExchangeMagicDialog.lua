local director = cc.Director:getInstance()
local winSize = director:getWinSize()

ExchangeMagicDialog = class("ExchangeMagicDialog")
ExchangeMagicDialog.__index = ExchangeMagicDialog
ExchangeMagicDialog._pointType = nil

function ExchangeMagicDialog.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, ExchangeMagicDialog)
    return target
end

function  ExchangeMagicDialog:init( magicType,data)
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonExchangeMagicDlg)

	self:addChild(self._widget)
-- title  Refill your lives
	local background = self._widget:getChildByName("bgDlg")
	local closeBtn = background:getChildByName("close")
	local buynowBtn = background:getChildByName("priceButton")
	local iapIcon = background:getChildByName("iapIconBG"):getChildByName("magicTool")
	
	local toolx3 = background:getChildByName("iapIconBG"):getChildByName("toolx3")
	if (magicType == 5) then
		toolx3:setVisible(false)
	else
		iapIcon:loadTexture(string.format(pngMagic,magicType))
	end
	local title = background:getChildByName("title")
	title:setText(ExchangeMagicDialog.getMagicTitle(magicType))
	local description = background:getChildByName("descriptionMagicTool")
	description:setText(ExchangeMagicDialog.getMagicDescription(magicType))


	-- self.magicTool:loadTexture(string.format(pngMagic,toolType))
	local function closeCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		
		if ccui.TouchEventType.ended == event then
			audio:playEffect("audio/SND008.mp3")
			local function destroy()
				self:getParent()._clicked = false
				if magicType == 5 then
					local levelType = self:getParent()._levelType
					local _indexT = levelType < taskIndex and math.floor((levelType-1)/15)+1 or math.floor(levelType/10000)
					runLevelScene(_indexT)
				else
					removeMaskBg(self:getParent())
					self:removeFromParent()					
				end
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end			
	end 
	closeBtn:addTouchEventListener(closeCallBack)

	-- 购买
	local function buynowCallBack(sender,event)
		local toBig = cc.ScaleBy:create(0.1,1.1)
		local toSmall = toBig:reverse()
		local bigSmall = cc.Sequence:create(toBig,toSmall)
		if ccui.TouchEventType.ended == event then
			-- print("buynow")
			audio:playEffect("audio/SND008.mp3")
			self:addMagicTool(magicType,data)
			local function destroy()
			self:getParent()._clicked = false
    		self = nil
			end
			self:runAction(cc.Sequence:create(cc.MoveTo:create(0.4,cc.p(self:getPositionX(),winSize.height)) ,cc.CallFunc:create(destroy)))
			-- self:getParent():addChild(dlg)

		elseif ccui.TouchEventType.began == event then
			sender:runAction(bigSmall) 
		end
	end 
	buynowBtn:addTouchEventListener(buynowCallBack)
	
end

function ExchangeMagicDialog.create(magicType,data)
	local dlg = ExchangeMagicDialog.extend(cc.Layer:create())
	dlg:init(magicType,data)
	dlgX,dlgY = dlg:getPosition()
	dlg:setPosition(cc.p(dlgX,winSize.height))
	dlg:runAction(cc.MoveTo:create(0.4,cc.p(dlg:getPositionX(),dlgY)))
	dlg:setLocalZOrder(2000)
	return dlg
end



function ExchangeMagicDialog.getMagicTitle(magicType)
	print("magicType:",magicType)
	local title
	local switch = {
		[0] = function()    -- for case 1
		title = "Cross tool package"
		end,
		[1] = function()    -- for case 2
		title = "Sponge tool package"
		end,
		[3] = function()    -- for case 3
		title = "Line brush package"
		end,
		[4] = function()
		title = "Row brush package"
		end,
		[5] = function()
		title = "Extra 5 Clicks"
		end
	}
	local f = switch[magicType]
	if(f) then
   	 f()
	else                -- for case default
  	  title = "title error"
	end
	return title
end

function ExchangeMagicDialog.getMagicDescription(magicType)
	local description
	local switch = {
		[0] = function()    -- for case 1
		description = "Update slime in a cross."
		end,
		[1] = function()    -- for case 2
		description = "Sponge remove all same slime at once!"
		end,
		[3] = function()    -- for case 3
		description = "Kill a column of slime by brush!"
		end,
		[4] = function()
		description = "Kill a row of slime by brush!"
		end,
		[5] = function()
		description = "5 extra clicks to help you finish the target."
		end

	}
	local f = switch[magicType]
	if(f) then
   	 f()
	else                -- for case default
  	  description = "description error"
	end
	return description
end

function ExchangeMagicDialog:addMagicTool(magicType,data)
	local parent = self:getParent()
	print("parent",parent)
	local switch = {
		[0] = function()    -- for case 1
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            db:updateCntChange(3)					
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    data:updateCnt(db:getCntChange())
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"cross",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
		end,
		[1] = function()    -- for case 2
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            db:updateCntSame(3)
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    data:updateCnt(db:getCntSame())
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"same",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
		end,
		[3] = function()    -- for case 3
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            db:updateCntRow(3)					
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    data:updateCnt(db:getCntRow())
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"row",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
		end,
		[4] = function()
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            db:updateCntLine(3)
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    data:updateCnt(db:getCntLine())
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"line",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
		end,
		[5] = function()
			local function callbackLua(param)
		        if "success" == param then
		        	print("call back ok")
		            local gameScene = data:getParent()
					gameScene.numClicks = gameScene.numClicks + 5
					GameState = GameState ~= GameStateDroping and GameStateWaiting or GameStateDroping
		        else
		        	print("call back error")
		        end
		    end
			local function callbackLuaUI(param)
                if "updateUI" == param then
                	print("call back ok")
                    gameScene.clicks:setText(gameScene.numClicks)
					data:removeFromParent()
                else
                	print("call back error")
                end
            end
			local targetPlatform = cc.Application:getInstance():getTargetPlatform()
			if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
				g_args = {"steps",callbackLua,callbackLuaUI}
			    local ok = luaj.callStaticMethod(g_className,"payWithConcent",g_args,g_sigs)
			    if not ok then
			        print("luaj error:")
			    else
			        print("The ret is:")
			    end
			else
				callbackLua("success")
				callbackLuaUI("updateUI")
			end
		end
	}
	local f = switch[magicType]
	if(f) then
		removeMaskBg(parent)
   		f()
	else                -- for case default
  	  print "ExchangeMagicDialog"
	end
end

			

