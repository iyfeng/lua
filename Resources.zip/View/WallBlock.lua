WallBlock = {}  
WallBlock = class("WallBlock",
    function()
        return BasicBlock.create()
    end)
WallBlock.__index = WallBlock







function WallBlock.create(hp)
    local germ = WallBlock.new()
    germ:initWithHp(hp)
    return germ
end


function WallBlock:initWithHp(hp)
    self:setTexture(pngWall)
end

function WallBlock:beHited()
	
end