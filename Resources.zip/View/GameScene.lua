require "View/Map"
require "Data/BlockFactory"
require "View/LosePreloadDialog"
require "View/LoseDialog"
require "View/WinDialog"
require "View/AudioHelper"
require "View/MagicGuideLayer"
require "View/TPanel"
require "View/ExchangeMagicDialog"


local director = cc.Director:getInstance()
local visibleSize = director:getVisibleSize()
local origin = director:getVisibleOrigin()
local winSize = director:getWinSize()
local sfCache = cc.SpriteFrameCache:getInstance()
local schedule = director:getScheduler()

function findFromTable(table_name,value)
  for i,v in ipairs(table_name) do
    if v.x == value.x and v.y == value.y then
      return true
    end
  end
  return false
end


GameScene = class("GameScene")
GameScene.__index = GameScene



function GameScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, GameScene)
    return target
end

function GameScene:init(levelType)
	cclog("begin create")
	self._levelType = levelType
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonGameScene)
	--layer =cc.Layer:create()
	self:addChild(self._widget)
	self.magHintFlag = false
	if getClickedTolLevel() >= db:getCurLevel() then
		self.magHintFlag = true
	end
	self:setTagInfo()
	cclog("init %d",levelType)
	self.menuLevel:setText(levelType)
	self:setButtonCallBack()
	--lv:setMapInfo()
	self:resetMap()
	

end

--设置Tag对应精灵元素
function GameScene:setTagInfo()
	self.menuBox = self._widget:getChildByTag(gMenuBox)
	self.background = self._widget:getChildByTag(gBackground)
	local _indexT = self._levelType < taskIndex and math.floor((self._levelType-1)/15)+1 or math.floor(self._levelType/10000)
	--local _indexT = math.floor((self._levelType-1)/15)+1
	self.background:loadTexture(string.format(pngRoomPart,_indexT))
	self.gameMap = self._widget:getChildByTag(gGameMap)
	self.menuOut = self._widget:getChildByTag(gMenuOut)
	self.menuOut:setZOrder(self.menuBox:getZOrder()-1)
	self.menuOut:setVisible(true)
	self.menuOut:setScale(0.01)


	self.playBox = self._widget:getChildByTag(gPlayBox)
	self.playBox:setLocalZOrder(180)
	self.menuSound = self.menuOut:getChildByTag(gMenuSound)
	self.menuMusic = self.menuOut:getChildByTag(gMenuMusic)
	self.menuExit = self.menuOut:getChildByTag(gMenuExit)
	self.menuLevel = self.menuBox:getChildByTag(gMenuLevel)

	self.menuSound:setTouchEnabled(true)
	self.menuMusic:setTouchEnabled(true)
	self.menuExit:setTouchEnabled(true)

	self.menuSound:setScale(0.01)
	self.menuMusic:setScale(0.01)
	self.menuExit:setScale(0.01)

	if db:getMusicState() == 1 then
		self.menuMusic:loadTexture(pngMusicOn)
	end
	if db:getSoundState() == 1 then
		self.menuSound:loadTexture(pngSoundOn)
	end	


	self.target = {}
	self.toGet = {}
	local tar1 = self.playBox:getChildByTag(gTargetName + 1)
	tar1:setVisible(false)
	self.orgTargetPos = tar1:getWorldPosition()
	self.target = {}
	self.boss ={}

	self.score = self.playBox:getChildByTag(gScore)
	self.score:setText(0)
	self.clicks = self.playBox:getChildByTag(gClicks)
	self.winStarpos = self.clicks:getWorldPosition()
	self.numClicks = lv:getTarget().clicks
	self.clicks:setText(self.numClicks)
	self.scoreBar = self.playBox:getChildByTag(gScoreBar)
	self.loadingBar = self.scoreBar:getChildByTag(gLoadingBar)
	self.loadingBar:setPercent(0)	
	self.scoLine = {}
	self.star = {}
	for i=1,3 do
		self.scoLine[i] = self.scoreBar:getChildByTag(gScoreBar + i)
		self.star[i] = self.scoLine[i]:getChildByTag(gStar)
		self.star[i]:setTag(gStar + i)
		self.star[i]:setColor(cc.c3b(166,166,166))
		self.star[i].shined = false
	end
	self:setStarPosition()
	self.tool = self.playBox:getChildByTag(gTool)
	self.toolBar = self.playBox:getChildByTag(gToolBar)
	self.toolBar:setEnabled(false)
	self.toolBar:setVisible(true)
	self.toolCge = self.toolBar:getChildByTag(gTool1)
	self.toolCln = self.toolBar:getChildByTag(gTool2)
	self.toolHor = self.toolBar:getChildByTag(gTool3)
	self.toolVtl = self.toolBar:getChildByTag(gTool4)

	self.cntCge = TPanel.create(db:getCntChange(),self.toolCge:getChildByTag(40))
	self.cntCln = TPanel.create(db:getCntSame(),self.toolCln:getChildByTag(40))
	self.cntHor = TPanel.create(db:getCntRow(),self.toolHor:getChildByTag(40))
	self.cntVtl = TPanel.create(db:getCntLine(),self.toolVtl:getChildByTag(40))

	self.menuClicked = false
	self.toolClicked = false

	self.map = cc.TMXTiledMap:create(tmxMapBlock)
	self:addChild(self.map)
	local psx,psy = self.gameMap:getPosition()
	self.map:setPosition(psx - self.map:getTileSize().width*2,psy - self.map:getTileSize().width*2)
	print("self.loadingBar",self.loadingBar:getDescription())
	self.mapbg = cc.TMXTiledMap:create(tmxMapBG)
	print(self.mapbg:getTileSize().width)
	self:addChild(self.mapbg,3,300)
	self.mapbg:setPosition(psx,psy)
	--self.mapbg:setAnchorPoint(0.5,0.5)
end

--设置回调函数
function GameScene:setButtonCallBack()
	
	--菜单按钮
	local function menuCallBack(sender,event)
		if ccui.TouchEventType.ended == event then			
			self.menuClicked = not self.menuClicked
			--print(self.menuClicked)
			audio:playEffect("audio/SND008.mp3")
			local bigs = {}
			if self.menuClicked == true then
				function menuOutCallback()
					--cclog("out")
					self.menuOut:runAction(cc.ScaleTo:create(0.4,1.0))
				end
				function menuSoundCallback()
					--cclog("sound")
					self.menuSound:runAction(cc.ScaleTo:create(0.7,1.0))
				end
				function menuMusicCallback()
					--cclog("music")
					self.menuMusic:runAction(cc.ScaleTo:create(0.6,1.0))
				end
				function menuExitCallback()
					--cclog("exit")
					self.menuExit:runAction(cc.ScaleTo:create(0.8,1.0))
				end
				--self.menuOut:runAction(cc.Sequence:create(cc.CallFunc:create(menuOutCallback),cc.CallFunc:create(menuMusicCallback)))
				--self.menuOut:runAction(big)
				self.menuOut:runAction(cc.Spawn:create(cc.CallFunc:create(menuOutCallback),cc.CallFunc:create(menuSoundCallback),cc.CallFunc:create(menuMusicCallback),cc.CallFunc:create(menuExitCallback)))
				self.tool:setTouchEnabled(false)
			else
				self.menuOut:runAction(cc.ScaleTo:create(0.4,0.01))
				self.menuSound:runAction(cc.ScaleTo:create(0.4,0.01))
				self.menuMusic:runAction(cc.ScaleTo:create(0.4,0.01))
				self.menuExit:runAction(cc.ScaleTo:create(0.4,0.01))
				self.tool:setTouchEnabled(true)
			end
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1.1):reverse())) 

		end
	end
	self.menuBox:addTouchEventListener(menuCallBack)

	--音乐按钮
	local function musicCallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("music %d",db:getMusicState())
			if db:getMusicState() == 1 then
				db:updateMusicState(0)
				sender:loadTexture(pngMusicOff)
				cc.SimpleAudioEngine:getInstance():pauseMusic()
				audio:playEffect("audio/SND008.mp3")
			else
				db:updateMusicState(1)
				sender:loadTexture(pngMusicOn)
				audio:playEffect("audio/SND008.mp3")
				cc.SimpleAudioEngine:getInstance():resumeMusic()
			end
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.menuMusic:addTouchEventListener(musicCallBack)

	--音效按钮
	local function soundCallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("music %d",db:getSoundState())
			if db:getSoundState() == 1 then
				db:updateSoundState(0)
				sender:loadTexture(pngSoundOff)
				audio:playEffect("audio/SND008.mp3")
			else
				db:updateSoundState(1)
				sender:loadTexture(pngSoundOn)
				audio:playEffect("audio/SND008.mp3")
			end
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.menuSound:addTouchEventListener(soundCallBack)

	--退出按钮
	local function exitCallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			if self.entry then
				schedule:unscheduleScriptEntry(self.entry)
				self.entry = nil
			end
			cclog("exit clicked")
			audio:playEffect("audio/SND008.mp3")
			local _indexT = self._levelType < taskIndex and math.floor((self._levelType-1)/15)+1 or math.floor(self._levelType/10000)
			runLevelScene(_indexT)

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.menuExit:addTouchEventListener(exitCallBack)
	
	--工具箱按钮
	local function toolCallBack(sender,event)
		
		if ccui.TouchEventType.ended == event then
			cclog("tool clicked")
			if db:getCurLevel() <= 13 then return end
			if GameState ~= GameStateWaiting then return end
			self.toolClicked = not self.toolClicked
			self.toolBar:setEnabled(self.toolClicked)
			audio:playEffect("audio/SND008.mp3")
			--print("self.toolClicked",self.toolClicked)
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			if db:getCurLevel() <= 13 then return end
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.tool:addTouchEventListener(toolCallBack)

	--工具箱-十字按钮
	local function tool1CallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("tool change clicked")
			self.guideFlag = false
			if GameState ~= GameStateWaiting then return end

			if self.magicType and self.magicType ~= magicCross then 
				return 
			elseif self.magicType == magicCross then  
				self.guideFlag = true 
				self.magicType = nil 
			end
			if db:getCntChange() == 0 then 
				addMaskBg(self) 
				local dlg = ExchangeMagicDialog.create(magicCross,self.cntCge)
   				self:addChild(dlg) 
				-- db:updateCntChange(10)
				-- self.cntCge:updateCnt(db:getCntChange())
				return
			end
			db:updateCntChange(db:getCntChange()-1)
			self.cntCge:updateCnt(db:getCntChange())
			--self:dialog(GameStateWin)
			--self:bounsTime()
			audio:playEffect("audio/SND008.mp3")
			self.toolClicked = not self.toolClicked
			self.toolBar:setEnabled(self.toolClicked)
			GameState = GameStateTool
			--self:magicExchange()
			if self:getChildByTag(2500) then
				self:removeChildByTag(2500)
			end

			if self:getChildByTag(5000) ~= nil then
                self:getChildByTag(5000):disappear()
            end

			local magicGL = MagicGuideLayer.create(magicCross,self.mapbg,self.guideFlag)
			self:addChild(magicGL)
			magicGL:setTag(2500)
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.toolCge:addTouchEventListener(tool1CallBack)

	--工具箱-清除按钮
	local function tool2CallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("tool clean clicked")
			self.guideFlag = false
			if GameState ~= GameStateWaiting then return end

			if self.magicType and self.magicType ~= magicSame then 
				return 
			elseif self.magicType == magicSame then
				self.guideFlag = true 
				self.magicType = nil 
			end
			if db:getCntSame() == 0 then 
				addMaskBg(self) 
				local dlg = ExchangeMagicDialog.create(magicSame,self.cntCln)
   				self:addChild(dlg)
				-- db:updateCntSame(10)
				-- self.cntCln:updateCnt(db:getCntSame())
				return
			end
			db:updateCntSame(db:getCntSame()-1)
			self.cntCln:updateCnt(db:getCntSame())

			audio:playEffect("audio/SND008.mp3")
			self.toolClicked = not self.toolClicked
			self.toolBar:setEnabled(self.toolClicked)
			GameState = GameStateTool
			if self:getChildByTag(2500) then
				self:removeChildByTag(2500)
			end

			if self:getChildByTag(5000) ~= nil then
                self:getChildByTag(5000):disappear()
            end

			local magicGL = MagicGuideLayer.create(magicSame,self.mapbg,self.guideFlag)
			self:addChild(magicGL)
			magicGL:setTag(2500)
			--self:dialog(GameStateLose)
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.toolCln:addTouchEventListener(tool2CallBack)

	--工具箱-横向清除按钮
	local function tool3CallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("tool hor clicked")
			self.guideFlag = false
			if GameState ~= GameStateWaiting then return end

			if self.magicType and self.magicType ~= magicLine then 
				return 
			elseif self.magicType == magicLine then
				self.guideFlag = true 
				self.magicType = nil 
			end
			if db:getCntRow() == 0 then 
				addMaskBg(self) 
				local dlg = ExchangeMagicDialog.create(magicLine,self.cntHor)
   				self:addChild(dlg)
				-- db:updateCntRow(10)
				-- self.cntHor:updateCnt(db:getCntRow())
				return
			end
			db:updateCntRow(db:getCntRow()-1)
			self.cntHor:updateCnt(db:getCntRow())

			audio:playEffect("audio/SND008.mp3")
			self.toolClicked = not self.toolClicked
			self.toolBar:setEnabled(self.toolClicked)
			GameState = GameStateTool
			if self:getChildByTag(2500) then
				self:removeChildByTag(2500)
			end

			if self:getChildByTag(5000) ~= nil then
                self:getChildByTag(5000):disappear()
            end

			local magicGL = MagicGuideLayer.create(magicRow,self.mapbg,self.guideFlag)
			self:addChild(magicGL)
			magicGL:setTag(2500)
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.toolHor:addTouchEventListener(tool3CallBack)

	--工具箱-纵向清除按钮
	local function tool4CallBack(sender,event)
		if ccui.TouchEventType.ended == event then
			cclog("tool vtl clicked")
			self.guideFlag = false
			if GameState ~= GameStateWaiting then return end

			if self.magicType and self.magicType ~= magicRow then 
				return 
			elseif self.magicType == magicRow then
				self.guideFlag = true  
				self.magicType = nil 
			end
			if db:getCntLine() == 0 then
				addMaskBg(self) 
				local dlg = ExchangeMagicDialog.create(magicRow,self.cntVtl)
   				self:addChild(dlg)
				-- db:updateCntLine(10)
				-- self.cntVtl:updateCnt(db:getCntLine())
				return
			end
			db:updateCntLine(db:getCntLine()-1)
			self.cntVtl:updateCnt(db:getCntLine())

			audio:playEffect("audio/SND008.mp3")
			self.toolClicked = not self.toolClicked
			self.toolBar:setEnabled(self.toolClicked)
			GameState = GameStateTool
			if self:getChildByTag(2500) then
				self:removeChildByTag(2500)
			end

			if self:getChildByTag(5000) ~= nil then
                self:getChildByTag(5000):disappear()
            end

			local magicGL = MagicGuideLayer.create(magicLine,self.mapbg,self.guideFlag)
			self:addChild(magicGL)
			magicGL:setTag(2500)
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end
	self.toolVtl:addTouchEventListener(tool4CallBack)

	--分数条移动（测试）
	--[[
	local function lineCallBack(sender,event)
		local scolineType = sender:getTag() - gScoreBar
		local socH = self.scoreBar:getWorldPosition().y
		if ccui.TouchEventType.ended == event then		
			cclog("ended pos")
			--sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(replaceSce)))
		elseif ccui.TouchEventType.moved == event then
			local pos= sender:getTouchMovePos()
			cclog("moved pos x: %f,y: %f",socH,pos.y)
			sender:setPositionY(pos.y -socH)
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			cclog("touch began")
		end
	end

	for i=1,3 do
		self.scoLine[i]:setTouchEnabled(true)
		self.scoLine[i]:addTouchEventListener(lineCallBack)
	end
	]]--
	--星星点击，更新分数（测试）
	local function starCallBack(sender,event)
		local starType = sender:getTag() - gStar
		if ccui.TouchEventType.ended == event then		
			--cclog("old score: %d,star: %d",db:getScore(self._levelType),db:getStar(self._levelType))
			--db:updateScoreAndStar(starType*10000,starType,self._levelType)
			--cclog("new score: %d,star: %d",db:getScore(self._levelType),db:getStar(self._levelType))
			--self.score:setText(db:getScore(self._levelType))
			self:bounsTime()
		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			cclog("touch began")
		end
	end

	for i=1,3 do
		self.star[i]:setTouchEnabled(true)
		self.star[i]:addTouchEventListener(starCallBack)
	end
end

function GameScene:resetMap()
	self.preDropTime = 4
	germInFly = 0
	delayT = {0}
	local layer = self.map:getLayer("layer")
	print("LAYER SIZE",layer:getMapTileSize().width)
	self.layerBG = self.mapbg:getLayer("layer")
	--Map.setBlock1(layer,2,3)
	--Map.setBlock1(layer,11,9)
	local map = lv:getMap()
	self:setScore()
	local maxx = MapWidth + 2*2
	local maxy = MapHeight + 2*2
	for i=1,MapHeight do
		for j=1,MapWidth do
			self.layerBG:setTileGID(1,cc.p(j-1,i-1))
		end
	end
	
	for i=2,maxy-1 do
		for j=2,maxx-1 do
			local flag = map[i][j].basic
			if 0 == flag then
				
				Map.setBlock0(map,layer,i,j)
			else
				
				Map.setBlockInfo(self.mapbg,i,j,map[i][j].hp,flag)
				
				Map.setBlock1(layer,i,j)
			end

		end
	end
	print("n!= ",Map.f(5,1))
	self:addTargetBar()
	--if MapEmpty == true then
		
	--[[
	else
		GameState = GameStateWaiting
		
		print("countWeakOther",countWeakOther)
		Map.isWeakOther(self.mapbg)
		Map.checkBombExist(self.mapbg)
	end
	]]--
end

function GameScene:checkWhetherNeedHint()
	if self.hintExist == true then
		return
	end
	if GameState == GameStateWaiting then
		if self:getChildByTag(5002) ~= nil then
			return
		end
		local now = socket.gettime()
		if now - finishDropTime > 5 then
			while true do
				math.randomseed(socket.gettime())
				local i = math.random(8)+2
				local j = math.random(10)+2
				self.hintsp = Map.getBlockSprite(self.mapbg,i,j)
				if self.hintsp ~= nil and self.hintsp.isMask == false and self.hintsp:isType4() == true then
					scaleby =  cc.ScaleBy:create(0.3,1.15)
					self.hintsp:runAction(cc.RepeatForever:create(cc.Sequence:create(scaleby,scaleby:reverse())))
					self.hintExist = true 
					break
				end
			end
		end
	end
end	


function GameScene:setScore()
	havStep = 0
	totalScore = 0
	bombScore = 1000
	Map.IsBounsTime = false
end

----游戏开始时目标提示横条
function GameScene:addTargetBar()
	GameState = GameStateStart
	addMaskBg(self)
	local widget = ccui.Widget:create()
	local targetBar = ccui.ImageView:create()
	targetBar:loadTexture(pngTargetBar)
	
	self:addChild(widget,302,500)
	widget:setSize(self._widget:getSize())
	widget:ignoreContentAdaptWithSize(false)

	targetBar:setPosition(self._widget:getSize().width/2,self._widget:getSize().height)
	targetBar:setSize(cc.size(self._widget:getSize().width,self._widget:getSize().height/8))
	targetBar:ignoreContentAdaptWithSize(false)

    local labHint = ccui.Text:create()
    labHint:setText(text)
    --labHint:setScale(1.1)
    labHint:setFontName(fontName)
    labHint:setFontSize(25)
    labHint:setColor(cc.c3b(255,255,255))
    labHint:setPosition(cc.p(0,-self._widget:getSize().height/30))
    if lv:getTarget().typ == 1 then
    	labHint:setText(string.format("Get %d points in %d clicks!",lv:getScoreTarget()[1],self.numClicks))
    else
    	labHint:setText(string.format("Kill Germs in %d clicks!",self.numClicks))
    end
    targetBar:addChild(labHint,3,30)
    local n = 0
	local function addOne(pngRes,text)
	--目标类型 targetTmp
		local targetTmp = ccui.ImageView:create()
		targetTmp:loadTexture(pngRes)	
		targetTmp:setSize(cc.size(self._widget:getSize().height/15,self._widget:getSize().height/15))
		targetTmp:ignoreContentAdaptWithSize(false)
		

	--alert 目标个数
		local alert = ccui.Text:create()
	    alert:setText(text)
	    --alert:setScale(1.1)
	    alert:setFontName(fontName)
	    alert:setFontSize(25)
	    alert:setColor(cc.c3b(255,127,0))
	    alert:setPosition(cc.p(targetTmp:getSize().width*1.2+alert:getSize().width/2,3))
		
		targetTmp:addChild(alert,3,20)
		n = n + 1
		widget:addChild(targetTmp,2,10000+n)
		table.insert(self.target,widget:getChildByTag(10000+n))
		table.insert(self.toGet,widget:getChildByTag(10000+n):getChildByTag(20))
	end


    if lv:getTarget().typ == 1 then
    	addOne(pngScore,lv:getScoreTarget()[1])
    elseif lv:getTarget().typ == 3 then
    	self.countGerm = lv:getTarget().other
	 	countGerm = self.countGerm
    	addOne(string.format(pngGerm,4),countGerm)
    else
    	local count = {{png = pngBigBoss,cnt = countBigBoss},{png = pngRecover,cnt = countRecover},
    					{png = pngWeakOthers,cnt = countWeakOther},{png = pngDoctor,cnt = countDoctor}}
    	local idx = 1
    	for i=1,#count do
    		if count[i].cnt > 0 then
    			self.boss[i] = idx
    			idx = idx + 1
    			addOne(string.format(count[i].png,1),count[i].cnt)
    		else
    			self.boss[i] = 0
    		end
    	end
    end
	
	local spacing = self.target[1]:getSize().width * 0.5
	local tarN = #self.target
	local distanceW = (self.target[1]:getSize().width*2 + self.toGet[1]:getSize().width + spacing)*tarN - spacing
	local predis = (self._widget:getSize().width - distanceW)/2
	local posY = self._widget:getSize().height/2 + targetBar:getSize().height*0.2
	for i=1,#self.target do
		self.target[i]:setPosition(predis+self.target[1]:getSize().width/2,posY)
		predis = predis + self.target[1]:getSize().width*2 + self.toGet[1]:getSize().width + spacing
		self.target[i]:setVisible(false)
	end
    --targetTmp:setPosition((self._widget:getSize().width-(targetTmp:getSize().width*2+alert:getSize().width))/2,self._widget:getSize().height/2)
    --targetTmp:addChild(alert,3,80)
    --print("pos",alert:getPositionX(),targetTmp:getPositionX())
    local function tarVis()
    	for i=1,#self.target do
			self.target[i]:setVisible(true)
		end
    end
    local spacingH = 5
    local predisH = self.orgTargetPos.y
    local posX = self.orgTargetPos.x
    local cellHeight = self.target[1]:getSize().height
    local function tarsJump()
    	for i=1,#self.target do
    		local moveP = cc.p(posX,predisH)
			self.target[i]:runAction(cc.JumpTo:create(0.8,moveP,60,1))			
			print("self.target[i]",moveP.x,moveP.y)
			predisH = predisH - cellHeight - spacingH
		end
	end

	local function tarsRemove()
		local n = #self.target
		self.toGet = {}
		removeMaskBg(self)
    	for i=1,n do
    		local tmp = self.target[i]
    		self.target[i] = tmp:clone()
			tmp:removeFromParent()
			self.playBox:addChild(self.target[i],2)
			local worldPos = cc.p(self.target[i]:getPosition())
			self.target[i]:setPosition(self.playBox:convertToNodeSpace(worldPos))
			--self.target[i]:setScale(20)
			--self.target[i]:getParent():setVisible(false)
			print("self.target[i]",self.target[i]:getPosition())
			table.insert(self.toGet,self.target[i]:getChildByTag(20))
		end
	end

	local function touEnabledT()
		print("it is run")
		self.background:setTouchEnabled(true)
	end

	local function touEnabledF()
		print("it is run")
		self.background:setTouchEnabled(false)
	end

	local function drop()
		print("dropTime",self.preDropTime)
		Map.drop(self.mapbg)
	end
	--dropDel = cc.DelayTime:create(self.preDropTime)
	dropB = cc.CallFunc:create(drop)
    tarVisB = cc.CallFunc:create(tarVis)
    tarsJumpB = cc.CallFunc:create(tarsJump)
    tarsRemoveB = cc.CallFunc:create(tarsRemove)
    tarTouEnabledBT = cc.CallFunc:create(touEnabledT)
    tarTouEnabledBF = cc.CallFunc:create(touEnabledF)

    tarMovein = cc.MoveTo:create(0.1,cc.p(self._widget:getSize().width/2,self._widget:getSize().height/2))
    tarMoveOut = cc.MoveTo:create(0.1,cc.p(self._widget:getSize().width/2,self._widget:getSize().height+100))
    tarDelay = cc.DelayTime:create(3)
    tarSeq = cc.Sequence:create(tarMovein,tarVisB,tarTouEnabledBT,tarDelay,tarTouEnabledBF,tarsJumpB,tarMoveOut,cc.DelayTime:create(1),tarsRemoveB,dropB)
    targetBar:runAction(tarSeq)


    
	local function widCallBack(sender,event)
		tarSeqR = cc.Sequence:create(tarsJumpB,tarMoveOut,cc.DelayTime:create(1),tarsRemoveB,dropB) 
		if ccui.TouchEventType.began == event then
			print("it is comin")
		elseif ccui.TouchEventType.ended == event then
			print("it is right")
			targetBar:stopAllActions()
			self.background:setTouchEnabled(false)
			targetBar:runAction(tarSeqR)
		end
	end
	self.background:addTouchEventListener(widCallBack)

    widget:addChild(targetBar,1,10000)
	--widget:addChild(targetTmp,2,10001)
	

	--print("Zorder",self._widget:getLocalZOrder(),self.mapbg:getLocalZOrder());
end

----奖励开始时目标提示横条
function GameScene:addBounceBar()
	if self.havBouns == true then
		return
	end
	self.havBouns = true
	local widget = self:getChildByTag(500)
	local targetBar = widget:getChildByTag(10000)
	
	widget:ignoreContentAdaptWithSize(false)

	targetBar:setPosition(self._widget:getSize().width/2,self._widget:getSize().height)
	targetBar:ignoreContentAdaptWithSize(false)

    local labHint = targetBar:getChildByTag(30)
    labHint:setText(text)
    --labHint:setScale(1.1)
    labHint:setFontName(fontName)
    labHint:setFontSize(32)
    labHint:setColor(cc.c3b(255,255,255))
    labHint:setPosition(cc.p(0,0))
    labHint:setText("Bouns Time!")

    tarMovein = cc.MoveTo:create(0.1,cc.p(self._widget:getSize().width/2,self._widget:getSize().height/2))
    tarMoveOut = cc.MoveTo:create(0.1,cc.p(self._widget:getSize().width/2,self._widget:getSize().height+100))
    tarDelay = cc.DelayTime:create(0.5)
    tarSeq = cc.Sequence:create(tarMovein,tarDelay,tarMoveOut)
    targetBar:runAction(tarSeq)
end

--设置星星条位置starScore/bestScore - 0.5
function GameScene:setStarPosition()
	local bestScore = lv:getScoreTarget()[3]
	for i=1,3 do
		local starScore = lv:getScoreTarget()[i]
		local percentY = starScore/bestScore - 0.5
		--print("percent",starScore/bestScore - 0.5)
		self.scoLine[i]:setPositionPercent(cc.p(0,percentY))
	end
end

function GameScene:updateScoreBar()
	--3星所对应分数
	local bestScore = lv:getScoreTarget()[3]

	local star = 0
	for i=1,3 do
		if totalScore >=lv:getScoreTarget()[i] then
			star = star + 1
		end
	end
	for i=1,star do
		local function setColor()
			self.star[i]:setColor(cc.c3b(255,255,255))
		end
		colorBack = cc.CallFunc:create(setColor)
		delay = cc.DelayTime:create(0.2)
		if self.star[i].shined ~= true then
			self.star[i].shined = true
			--print("star com in")
			effect:doAnimation(self.star[i],self,"T",0.2)
			effect:doAnimation(self.star[i],self,"D",0.2)
			audio:playEffect("audio/SND019.mp3")
			if i == 3 then
				effect:doAnimation(self.star[i],self,"G",0.2)
			end
			self.star[i]:runAction(cc.Sequence:create(delay,colorBack))
		end
	end
	
	local percent = 0
	percent = math.floor(totalScore/bestScore * 100)
	if percent >= 100 then
		percent = 100
	end
	self.score:setText(totalScore)
	self.loadingBar:setPercent(percent)	
end

function GameScene:win()
	if self:isWin() == true or Map.IsBounsTime == true then
		print("you win 1")
		self:bounsTime()
		--self:dialog(GameState)
		return true
	end
	return false
end

function GameScene:isWin()
	--print("go in to win",lv:getTarget().typ,tonumber(self.numClicks))
	if lv:getTarget().typ == 0 or lv:getTarget().typ == 2 then
		--print("go in to win")
		if countDoctor + countWeakOther + countBigBoss + countRecover == 0 then
			--print("you win")
			GameState = GameStateWin
			return true
		end
	elseif lv:getTarget().typ == 1 and tonumber(self.numClicks) == 0 then
		print(totalScore,tonumber(lv:getScoreTarget()[1]))
		if totalScore >= tonumber(lv:getScoreTarget()[1]) then
			--print("you win 4")
			GameState = GameStateWin
			return true
		end
	elseif lv:getTarget().typ == 3 then
		--print("you win 13",countGerm)
		if countGerm <= 0 then
			--print("you win 3",countGerm)
			GameState = GameStateWin
			return true
		end
	end
	return false
end


function GameScene:lose()
	if self:isWin() == false and tonumber(self.numClicks) == 0 then
		GameState = GameStateLose
		--print("you lose")
		self:dialog(GameState)
		return true
	end
	return false
end

--state 输赢状态，flag 是否能继续
function GameScene:dialog(state,flag)
	addMaskBg(self)
	local Dlg
	if state == GameStateWin then
		Dlg = WinDialog.create(self._levelType)
	elseif state == GameStateLose then
		Dlg = LosePreDlg.create(self._levelType)
	end
    self:addChild(Dlg)
end

function GameScene:bounsTime()
	if self.numClicks > 0 then
		self:addBounceBar()
	end
	if self.entry then
		schedule:unscheduleScriptEntry(self.entry)
		self.entry = nil
	end
	local time = 0.4
	Map.Bombs = {}
	Map.IsBounsTime = true
	GameState = GameStateWin
	self.AllbombsBeHitted = false
	local function bounsTime()
		if self.AllbombsBeHitted == true then return end
		if self.numClicks <= 0 then
			print("goto here")
			self:dialog(GameStateWin)
			return
		else
			self.numClicks = self.numClicks - 1
			self.clicks:setText(self.numClicks)
			if Map.germExists <= 0 then				
				totalScore = totalScore + 2000
				self:updateScoreBar()
			else
				bombScore = bombScore + 1000
				totalScore = totalScore + bombScore				
				self:updateScoreBar()

				local winStar = cc.Sprite:create(pngWinStar)		
				self:addChild(winStar,50)
				winStar:setPosition(self.winStarpos)
				winStar:setAnchorPoint(0.5,0)
				winStar:setRotation(-45)
				winStar:setScale(0)

				local winStarPar = effect:getParticleWithFile(self,self.clicks,parScoreToBomb)
				winStarPar:setScale(1)
				winStarPar:setAnchorPoint(0.5,0)

				-- lhf流星动画
				local skd = 0
				while true do
					math.randomseed(socket.gettime())
					local i = math.random(8)+2
					local j = math.random(10)+2

					local sp = Map.getBlockSprite(self.mapbg ,i,j)

					if sp ~= nil  and sp:isGerm() == true then
						table.insert(Map.Bombs,cc.p(i,j))
						mapInfo[i][j].isEmpty = 1

							local p = cc.pAdd(cc.p(sp:getPosition()),cc.p(self.mapbg:getPosition()))

							-- sp:removeFromParent()
							-- 起点
							local posFrom = self.winStarpos
							-- 终点
							local posTo = p

							local angle = math.atan2(-(posTo.y - posFrom.y), posTo.x - posFrom.x )
							winStar:setRotation(angle*180/math.pi - 90)

							-- 流星偏移量
							local offsetX = winStar:getContentSize().height*winStar:getScaleX()*math.sin(winStar:getRotation()/180*math.pi)
							local offsetY = winStar:getContentSize().height*winStar:getScaleX()*math.cos(winStar:getRotation()/180*math.pi)
							winStar:setPosition(self.winStarpos.x - offsetX,self.winStarpos.y - offsetY)
							winStarPar:setPosition(self.winStarpos.x - offsetX,self.winStarpos.y - offsetY)
							-- 流星粒子变大
							local winStarBig = cc.ScaleTo:create(0.15,0.5)
							local winStarParBig = cc.ScaleTo:create(0.15,0.5)
							-- 流星粒子移动
							local distance = cc.pGetDistance(posFrom,posTo)
							local distanceNormalization = cc.pGetDistance(self.winStarpos,cc.p(winSize.width,winSize.height))
							local distanceRatio = distance/distanceNormalization
							--print("distance:",distance,distanceNormalization,distanceRatio)

							local winStarMove = cc.MoveTo:create(0.5 * distanceRatio,cc.p(posTo))
							local winStarParMove = cc.MoveTo:create(0.5 * distanceRatio,cc.p(posTo))

						-- 流星粒子消除
						local function winStarRemove()
							--print("do not die1")
							local i,j = Map.getTileCoordinateFromSprite(sp)
    						i,j = i+2,j+2
							winStar:removeFromParent()
							winStarPar:removeFromParent()
							math.randomseed(socket.gettime())
							local bombType = math.random(2)
							local bomb =  Map.setBlockInfo(self.mapbg,i,j,bombType,15)
							--print("do not die2")
							audio:playEffect("audio/SND022.mp3")
							self.mapbg:addChild(GermScore.create(bombScore,bomb))
							Map.germExists = Map.germExists - 1
							-- print("germsandClicks:",Map.germExists,self.numClicks)
							if Map.germExists <= 0 or self.numClicks <= 0 then
								
								for i=1,#Map.Bombs do
									--print("bombs",Map.Bombs[i].x,Map.Bombs[i].y)
									local sp = Map.getBlockSprite(self.mapbg,Map.Bombs[i].x,Map.Bombs[i].y)
									sp:beHited()
									mapInfo[Map.Bombs[i].x][Map.Bombs[i].y].isEmpty = 1											
								end
								--local del = cc.DelayTime:create(2)
								--self:runAction(del)
								self.AllbombsBeHitted = true
								return
							end
						end
						
						-- 变成噬菌体
						function change()
							
						end
						winStarPar:runAction(cc.Spawn:create(winStarParBig,winStarParMove))
						time = math.max(0.5 * distanceRatio,0.15) + 0.2
						--delay = cc.DelayTime:create()
						--local seq = cc.Sequence:create(delay,cc.CallFunc:create(winStarRemove))
						--cc.Sequence:create(cc.Spawn:create(winStarBig,winStarMove,winStarRemove),cc.CallFunc:create(winStarRemove))
						winStar:runAction(cc.Sequence:create(cc.Spawn:create(winStarBig,winStarMove),cc.CallFunc:create(winStarRemove)))
						--winStarRemove()
						break
					else
						skd = skd + 1
						--print("do not die2",skd)
					end
				end
			end
			print("time",time)
			delay = cc.DelayTime:create(time)
			local bounsTimeCall = cc.CallFunc:create(bounsTime)
			self:runAction(cc.Sequence:create(delay,bounsTimeCall))
		end
	end
	bounsTime()
end

--Magic

--1 交换
function GameScene:magicExchange()
	print("began change")
	local tars = {}
	local idx = 1
	for i=3,10 do
		for j=3,12 do
			local sp = Map.getBlockSprite(self.mapbg,i,j)			
			if sp and sp:isGerm() then
				sp:removeAllChildren()
				table.insert(tars,cc.p(i,j))
			end
		end
	end
	local tt = 0.5
	local called = false
	print("tars count",#tars)
	while #tars > 1 do
		--print("tars count",#tars)
		math.randomseed(socket.gettime())
		local idx = math.random(#tars)
		local i1,j1 = tars[idx].x,tars[idx].y
		table.remove(tars,idx)
		local sp1 = Map.getBlockSprite(self.mapbg,i1,j1) 

		local idx = math.random(#tars)
		local i2,j2 = tars[idx].x,tars[idx].y
		table.remove(tars,idx)
		local sp2 = Map.getBlockSprite(self.mapbg,i2,j2)
		sp1:setTag(mapInfo[i2][j2].tag)
		sp2:setTag(mapInfo[i1][j1].tag)

		mapInfo[i1][j1].hp,mapInfo[i2][j2].hp = mapInfo[i2][j2].hp,mapInfo[i1][j1].hp
		mapInfo[i1][j1].isEmpty,mapInfo[i2][j2].isEmpty = mapInfo[i2][j2].isEmpty,mapInfo[i1][j1].isEmpty
		--local p1 = cc.pAdd(cc.p(sp1:getPosition()),cc.p(self.mapbg:getPosition()))
		--local p2 = cc.pAdd(cc.p(sp2:getPosition()),cc.p(self.mapbg:getPosition()))
		local m1 = cc.MoveTo:create(tt,cc.p(sp2:getPosition()))
		local m2 = cc.MoveTo:create(tt,cc.p(sp1:getPosition()))
		if not called then 
			called = true
		else
		end
		sp1:runAction(m1)
		sp2:runAction(m2)
	end

	local function checkBombBack()
		GameState = GameStateWaiting
		Map.checkBombExist(self.mapbg)
	end

	self:runAction(cc.Sequence:create(cc.DelayTime:create(tt*2),cc.CallFunc:create(checkBombBack)))
end

--1 十字架周围变成四号
function GameScene:magicToCross(magicTool,spTouch)
	
	local scale = magicTool:getScale()
	local touchPos = cc.p(spTouch:getPosition())
	local touchType = spTouch.itemType
	local i0,j0 = Map.getTileCoordinateFromSprite(spTouch)
    i0,j0 = i0+2,j0+2
	if spTouch:isType4() then
		self.hintsp = nil 
		self.hintExist = false
	end
	magicTool:setScale(magicTool:getScale()*4)
	magicTool:setPosition(0,winSize.height - magicTool:getContentSize().height * magicTool:getScale()/2)
	local moveP = cc.pAdd(touchPos,cc.p(spTouch:getParent():getPosition()))
    --变大移动
    local toolMove = cc.MoveTo:create(0.3,cc.p(winSize.width/5,winSize.height+magicTool:getContentSize().height/2))    
    local toolBig = cc.ScaleBy:create(0.3,5)
    --移动掉落
    local toolSmall = toolBig:reverse()
    local toolJump = cc.JumpTo:create(0.2,moveP,60,1)
    --弹动
    local toolspring1 = cc.ScaleTo:create(0.1,1.1*scale,0.9*scale)
    local toolspring2 = cc.ScaleTo:create(0.1,0.9*scale,1.1*scale)
    local toolspring3 = cc.ScaleTo:create(0.1,scale)
    --local toolFadeOut = cc.FadeOut:create(0.2)

    local function crossToType4()
	    for j=j0-1,j0+1 do
	    	for i=i0-1,i0+1 do
	    		if j == j0 or i == i0 then
	    			local bk = Map.getBlockSprite(self.mapbg,i,j)
	    			if bk and bk:isGerm() then
	    				bk:updateToType4()
	    			end
	    		end
	    	end
	    end
	end

    local toTypes = cc.CallFunc:create(crossToType4)
    local removeDelay = cc.DelayTime:create(0.2)
    local Delay1 = cc.DelayTime:create(0.65)
    local Delay2 = cc.DelayTime:create(0.7)
    local function drop()
    	Map.drop(self.mapbg)
    end
    local removeDone = cc.CallFunc:create(drop)
    local function toolRun1()
    	magicTool:runAction(cc.Sequence:create(cc.Spawn:create(toolBig,toolMove),cc.Spawn:create(toolSmall,toolJump),toolspring1,toolspring2,toolspring3))
	end

	local function toolRun2()
		print("run dddd")
		magicTool:runAction(cc.FadeOut:create(0.2))
		magicTool:getParent():removeFromParent()
	end    
	local run1 = cc.CallFunc:create(toolRun1)
	local run2 = cc.CallFunc:create(toolRun2)
		
	self:runAction(cc.Sequence:create(run1,Delay1,run2,toTypes,removeDelay,removeDone))
end



--2 消除同一类型
function GameScene:magicCleanSame(magicTool,spTouch)
	
	local scale = magicTool:getScale()
	local touchPos = cc.p(spTouch:getPosition())
	local touchType = spTouch.itemType
	if spTouch:isType4() then
		self.hintsp = nil 
		self.hintExist = false
	end
	magicTool:setScale(magicTool:getScale()*4)
	magicTool:setPosition(0,winSize.height - magicTool:getContentSize().height * magicTool:getScale()/2)
	local moveP = cc.pAdd(touchPos,cc.p(spTouch:getParent():getPosition()))
    --变大移动
    local toolMove = cc.MoveTo:create(0.3,cc.p(winSize.width/5,winSize.height+magicTool:getContentSize().height/2))    
    local toolBig = cc.ScaleBy:create(0.3,5)
    --移动掉落
    local toolSmall = toolBig:reverse()
    local toolJump = cc.JumpTo:create(0.2,moveP,60,1)
    --弹动
    local toolspring1 = cc.ScaleTo:create(0.1,1.1*scale,0.9*scale)
    local toolspring2 = cc.ScaleTo:create(0.1,0.9*scale,1.1*scale)
    local toolspring3 = cc.ScaleTo:create(0.1,scale)
    --local toolFadeOut = cc.FadeOut:create(0.2)

    local actions = {}
    
    local actCount = 0
    for j=3,MapWidth+2 do
    	for i=3,MapHeight+2 do
    		local bk = Map.getBlockSprite(self.mapbg,i,j)
    		if bk and bk:isGerm() then
    			if bk.itemType == touchType then
    				local bubble = cc.Sprite:create(pngPaoPao)
    				
    				self.mapbg:addChild(bubble,bk:getLocalZOrder()-1)
    				bubble:setScale(0)
    				bubble:setPosition(touchPos)
    				local delay = cc.DelayTime:create(0.3)
    				local function block()
    					--产生泡泡
    					local scale = bk:getScale()
    					local birth = cc.ScaleTo:create(0.1,0.25*scale,0.15*scale)
    					--移动泡泡
    					local distance = cc.pGetDistance(touchPos,cc.p(bk:getPosition()))
    					local distanceNormalization = cc.pGetLength(cc.pMul(cc.pFromSize(bk:getContentSize()),bk:getScale()))
    					local distanceRatio = distance/distanceNormalization
    					local moveto = cc.MoveTo:create(0.05*distanceRatio,cc.p(bk:getPosition()))
    					local angle = cc.pToAngleSelf(cc.pSub(touchPos,cc.p(bk:getPosition())))
    					bubble:setRotation(-math.deg(angle))

    					--泡泡弹动
    					local act1 = cc.ScaleTo:create(0.15,1.0*scale,0.6*scale)
    					local act2 = cc.ScaleTo:create(0.2,0.9*scale,1.2*scale)
    					local act3 = cc.ScaleTo:create(0.05,1.1*scale,1.1*scale)
    					local act4 = cc.ScaleTo:create(0.05,0.9*scale,1.0*scale)
    					local act5 = cc.ScaleTo:create(0.15,1.0*scale,1.0*scale)

    					local act8 = cc.ScaleTo:create(0.15,0)

    					local function killGermsAndBubble()
    						
    						bubble:removeFromParent()
    						bk:removeFromParent()
    						mapInfo[i][j].hp = 0
    						mapInfo[i][j].isEmpty = 1
    						--actCount = actCount + 1
    						--print("kill")
    					end

    					local function runAct9()
    						--print("act9")
    						bk:runAction(cc.ScaleTo:create(0.15,0))
    					end
    					bubble:runAction(cc.Sequence:create(birth,cc.Spawn:create(moveto,act1),act2,act3,act4,act5,cc.Spawn:create(act8,cc.CallFunc:create(runAct9)),cc.CallFunc:create(killGermsAndBubble),delay))
    					--time = math.max(0.5*distanceRatio,0.15) + 0.1 + 0.2 + 0.05 + 0.05 + 0.15 + 0.15
    				end
    				--print("block time",time)
    				
    				table.insert(actions,cc.CallFunc:create(block))
    				table.insert(actions,delay)
    			end
    		end
    	end
    end
    local function test()
    	print("this called",#actions)
    end 
    table.insert(actions,cc.CallFunc:create(test))
    local removeDelay = cc.DelayTime:create(0.65)
    local Delay1 = cc.DelayTime:create(0.65)
    local Delay2 = cc.DelayTime:create(0.7)
    local function drop()
    	Map.drop(self.mapbg)
    end
    local removeDone = cc.CallFunc:create(drop)
    local function toolRun1()
    	magicTool:runAction(cc.Sequence:create(cc.Spawn:create(toolBig,toolMove),cc.Spawn:create(toolSmall,toolJump),toolspring1,toolspring2,toolspring3))
	end

	local function toolRun2()
		print("run dddd")
		magicTool:runAction(cc.FadeOut:create(0.2))
		magicTool:getParent():removeFromParent()
	end    
	local run1 = cc.CallFunc:create(toolRun1)
	local run2 = cc.CallFunc:create(toolRun2)
		
	self:runAction(cc.Sequence:create(run1,Delay1,cc.Sequence:create(actions),Delay2,run2,removeDelay,removeDone))
end

--3 消除一行
function GameScene:magicCleanRow(magicTool,spTouch)
	if spTouch:isType4() then
		self.hintsp = nil 
		self.hintExist = false
	end
	local tileW = self.mapbg:getTileSize().width
	local scale = spTouch:getScale()
	magicTool:getParent():removeFromParent()
	local spTouchI = Map.getTileCoordinateFromSprite(spTouch)-1
	local startPos = self.mapbg:getLayer("layer"):getPositionAt(cc.p(MapWidth-1,spTouchI))
	ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniMagic)
    local armature =  ccs.Armature:create("MagicAnimation")
    armature:getAnimation():play("magic")
    armature:setRotation(-90)
    armature:setScale(scale)
    self.mapbg:addChild(armature,200,2001)
	
	armature:setPosition(cc.pAdd(startPos,cc.p(tileW/2,tileW/2)))     
	self:magicFly(armature,cc.p(-tileW,0))
  
end

--4 消除一列
function GameScene:magicCleanLine(magicTool,spTouch)
	if spTouch:isType4() then
		self.hintsp = nil 
		self.hintExist = false
	end
	local tileW = self.mapbg:getTileSize().width
	local scale = spTouch:getScale()
	magicTool:getParent():removeFromParent()
	local spTouchI,spTouchJ = Map.getTileCoordinateFromSprite(spTouch)
	spTouchJ = spTouchJ-1
	local startPos = self.mapbg:getLayer("layer"):getPositionAt(cc.p(spTouchJ,MapHeight-1))
	ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniMagic)
    local armature =  ccs.Armature:create("MagicAnimation")
    armature:getAnimation():play("magic")
    armature:setScale(scale*1.2)
    self.mapbg:addChild(armature,200,2001)
	
	armature:setPosition(cc.pAdd(startPos,cc.p(tileW/2,tileW/2)))    
	self:magicFly(armature,cc.p(0,tileW))
end

function GameScene:magicFly(arm,pt)
	local i,j =  Map.getTileCoordinateFromPos(self.mapbg:getLayer("layer"),cc.p(arm:getPosition()))
	i,j = i+2,j+2
	--print("arm pos",i,j)
	if i < 3 or j < 3 then
		--print("arm pos",i,j)
		arm:removeFromParent()
		return
	end
	local sp = Map.getBlockSprite(self.mapbg,i,j)
	if sp and sp:isGerm() then
		sp:createDirections(sp)
	end
	local moveby = cc.MoveBy:create(0.04,pt)
	local function magicFlyBlock()
		self:magicFly(arm,pt)
	end
	local flyCall = cc.CallFunc:create(magicFlyBlock)
	arm:runAction(cc.Sequence:create(moveby,flyCall))

end
function GameScene.create(levelType)
	local scene = cc.Scene:create()
	local layer = GameScene.extend(cc.Layer:create())
	layer:init(levelType)
	scene:addChild(layer)
	return scene
end


function runGameScene(levelType)
	local scene = GameScene.create(levelType)
	director:replaceScene(scene)
end

