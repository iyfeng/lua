GermScore = {}  
GermScore = class("GermScore",
    function()
        return cc.Sprite:create()
    end)
GermScore.__index = GermScore







function GermScore.create(hp,germ)
    local germS = GermScore.new()
    germS:initWithHp(hp,germ)
    return germS
end


function GermScore:initWithHp(hp,germ)
	local numberBg = cc.Sprite:create(pngNull)
	self:addChild(numberBg)
	local scale = germ:getScale()
	local fontSize = germ:getContentSize().width * scale * 0.5
	self.label = cc.LabelTTF:create()
	self.label:setColor(cc.c3b(0,255,0))
	self.label:setFontName(fontName)
	self.label:setFontSize(fontSize)
	self.label:setString(string.format("%d",hp))
	self.label:setPosition(germ:getPosition())
	numberBg:addChild(self.label,10)
	numberBg:setAnchorPoint(0, 0)
	
	local move = cc.MoveBy:create(0.8,cc.p(0,germ:getContentSize().width*1.5*scale))

	remv = cc.CallFunc:create(self.removeFromParent)
	self:runAction(cc.Sequence:create(move,remv))
end

