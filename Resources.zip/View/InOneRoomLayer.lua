require "View/LevelLayer"

local director = cc.Director:getInstance()
local visibleSize = director:getVisibleSize()
local origin = director:getVisibleOrigin()
local winSize = director:getWinSize()
local sfCache = cc.SpriteFrameCache:getInstance()
local schedule = director:getScheduler()

InOneRoomLayer = class("InOneRoomLayer")
InOneRoomLayer.__index = InOneRoomLayer
InOneRoomLayer._widget = nil
InOneRoomLayer._roomType = nil

function InOneRoomLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, InOneRoomLayer)
    return target
end



function InOneRoomLayer:init(roomType)
	self._roomType = roomType
	self._widget = ccs.GUIReader:getInstance():widgetFromJsonFile(string.format(jsonMainRoomPath,roomType))
	ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniUnlocking)
	self.armature = ccs.Armature:create("Unlockeding")
	--layer =cc.Layer:create()
	self:addChild(self._widget)
	self.roomLayer = self._widget:getChildByTag(roomBg)
	--self.roomLayer:setScale(0.5)
	self._widget:setPosition(winSize.width/2 - self._widget:getContentSize().width/2,0)
	--cclog("node width %f",self.roomLayer:getPositionX())
	local cellButton = {}
	for i=0,totalIndex do
		if i == 0 then
			cellButton[i] = self._widget:getChildByTag(roomBack)
			cellButton[i]:setPositionPercent(cc.p(0.05,0.09))
			--cclog("position %f",cellButton[i]:getPositionY())
		else
			cellButton[i] = self.roomLayer:getChildByTag(roomBack + i)
			cellButton[i]:getChildByTag(20):setVisible(false)
			
			--设置为系统字体
			local nlbl = ccui.Text:create()
			nlbl:setFontName(fontName)
			nlbl:setFontSize(32)
			nlbl:setScale(1.2)
			nlbl:setPositionType(ccui.PositionType.percent)
			nlbl:setPositionPercent(cc.p(0,0.07))
			nlbl:setText(string.format("%d",i + (roomType-1)*totalIndex))
			cellButton[i]:addChild(nlbl,2,22)
			--nlbl:setVisible(false)
		end
	end 
	--cellButton[6]:setPosition(cc.p(0,0))
	self:setlevelLocked()
	-- lhf添加粒子效果测试
	self:addOrRemoveParticle(true)

	--设置大关按钮和返回按钮的回调函数
	function indexCallBack(sender,event)
		local indexTag = sender:getTag() - roomBack
		local indexType = indexTag + (self._roomType -1) * totalIndex
		setClickedIndex(indexType)
		if ccui.TouchEventType.ended == event then
			-- lhf音乐
			local function playeffect1( ... )
				audio:playEffect("audio/SND008.mp3")
			end
			if indexTag == 0 then
				local function replaceSce( ... )
					local scene = MainMenu.CreateMainMenuScene()
					director:replaceScene(scene)
				end
				
				sender:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(playeffect1),cc.CallFunc:create(replaceSce)))
			else

				--是否被锁
				--if sender.isLocked == true then	return end
				--是否为最后一关
				if indexType > allIndex then
						cclog("the levels havent build")
						audio:playEffect("audio/SND008.mp3")
						return
				end
				
				local function replaceSce()					
					local scene = LevelLayer.create(indexType)
					director:replaceScene(scene)
				end
				local bgSize = self.roomLayer:getContentSize()
				local posX = sender:getPositionX() + winSize.width/2
				local posY = sender:getPositionY() + winSize.height/2
				local dx = nil
				local dy = nil

				self.roomLayer:setPosition(posX,posY)
				self.roomLayer:setAnchorPoint(cc.p(posX/winSize.width,posY/winSize.height))
				
				cellButton[0]:setVisible(false)
				self.roomLayer:removeAllChildren()
				
				local scale = 3
				
				dx = winSize.width/2 - posX
				dy = bgSize.height - posY

				--dx = posX*(scale-1)
				
				if posX * scale <winSize.width/2 then
					dx = posX * (scale-1)
				end
				if (winSize.width - posX) * scale < winSize.width/2 then
					dx = (posX - winSize.width) * (scale - 1)
				end
				self.roomLayer:runAction(cc.MoveBy:create(1,cc.p(dx,dy)))
				self.roomLayer:runAction(cc.Sequence:create(cc.ScaleBy:create(1,3),cc.CallFunc:create(replaceSce)))
				-- lhf音乐
				audio:playEffect("audio/SND005.mp3")
				----lhf添加粒子效果测试
				self:addOrRemoveParticle(false)
			end			

		elseif ccui.TouchEventType.began == event then
			--local type = sender:getTag()
			sender:runAction(cc.Sequence:create(cc.ScaleBy:create(0.1,1.1),cc.ScaleBy:create(0.1,1/1.1))) 
		end
	end

	for i=0,totalIndex do
		cellButton[i]:addTouchEventListener(indexCallBack)
	end

end



----设置大关锁
function InOneRoomLayer:setlevelLocked()
	local x = math.floor((curIndex-1)/totalIndex) + 1
	if x < self._roomType then
		self:levelsLocked(0)
	elseif x == self._roomType then
		self:levelsLocked((curIndex-1)%totalIndex + 1)
	else
		return
	end
end

function InOneRoomLayer:levelsLocked(curIdx)
	for i = curIdx + 1,totalIndex do
		local index = self.roomLayer:getChildByTag(roomBack + i)
		index:getChildByTag(22):setVisible(false)
		index:loadTexture(pngBgLock)
		index.isLocked = true
	end
end

function InOneRoomLayer:setLevelUnLocked(curIdx)
	local index = self.roomLayer:getChildByTag(roomBack + curIdx)
	index:getChildByTag(22):setVisible(true)
	index:loadTexture(pngBgUnLock)
	--cclog("check the count %d",index:getTag())

	-- lhf音乐
	audio:playEffect("audio/SND003.mp3")
	-- lhf添加粒子效果测试
	self:addOrRemoveParticle(false)
	self:addOrRemoveParticle(true)
end

-----判断当前被点击大关是否被锁
function InOneRoomLayer:isLocked(curTouch)
	if curTouch > curLevel[self._roomType] then
		return true
	end
	return false
end

--lhf添加粒子效果测试
function InOneRoomLayer:addOrRemoveParticle(parBool)
	if parBool == true then
		for i=totalIndex, 1,-1 do
			local index = self.roomLayer:getChildByTag(roomBack + i)
			if index.isLocked ~= true then
				effect:setParticleForPart(self,index)
				break
			end
		end
	else
		if effect ~=nil then 
			self:removeChildByTag(10086)
		end
	end
end

function InOneRoomLayer.create( roomType )
	local scene = cc.Scene:create()
	local layer = InOneRoomLayer.extend(cc.Layer:create())
	layer:init(roomType)
	scene:addChild(layer)
	layer:setTag(0)
	return scene
end

function runInRoomScene(roomType)
	local scene = InOneRoomLayer.create(roomType)
	director:replaceScene(scene)
end
