BossBlock = {}  
BossBlock = class("BossBlock",
    function()
        return BasicBlock.create()
    end)
BossBlock.__index = BossBlock







function BossBlock.create(hp)
    local germ = BossBlock.new()
    germ:initWithHp(hp)
    return germ
end


function BossBlock:initWithHp(hp)
    self:setTexture(pngBoss)
   	self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function BossBlock:beHited( ... )
	if self:smashed() == true then
        audio:playEffect("audio/SND014.mp3")
        countBigBoss = countBigBoss - 1
        self:getParent():getParent().toGet[2]:setText(countBigBoss)
    end
end