DoctorBlock = {}  
DoctorBlock = class("DoctorBlock",
    function()
        return BasicBlock.create()
    end)
DoctorBlock.__index = DoctorBlock







function DoctorBlock.create(hp)
    local germ = DoctorBlock.new()
    germ:initWithHp(hp)
    return germ
end


function DoctorBlock:initWithHp(hp)
    self:setTexture(pngDoctor)
    self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel,100)
end

function DoctorBlock:beHited( ... )
	self:smashed()
end