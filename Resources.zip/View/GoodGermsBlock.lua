GoodGermsBlock = {}  
GoodGermsBlock = class("GoodGermsBlock",
    function()
        return BasicBlock.create()
    end)
GoodGermsBlock.__index = GoodGermsBlock







function GoodGermsBlock.create(hp)
    local germ = GoodGermsBlock.new()
    germ:initWithHp(hp)
    return germ
end


function GoodGermsBlock:initWithHp(hp)
    self:setTexture(pngGood)
    self.remainHp = hp
    self.maxHp = hp
    self.hpPanel = HpPanel.create(hp)
    self:addChild(self.hpPanel)
end

function GoodGermsBlock:beHited( ... )
	self:smashed()
end