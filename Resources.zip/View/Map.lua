require("Data/HintText")

local director = cc.Director:getInstance()
local schedule = director:getScheduler()

Map = {}
Map.existBomb = false
Map.BombI = nil
Map.BombJ = nil
Map.bombType = 0
Map.Bombs = {}
Map.IsBounsTime = false
Map.BombHited = true
Map.dirTime = 0.15
--Map.__index = Map
function Map.setBlock0(map,mapLayer,i,j)
	--cclog("block0")
	
	local up = map[i-1][j].basic
	local down = map[i+1][j].basic
	local left = map[i][j-1].basic
	local right = map[i][j+1].basic
	local a = {}
	if up == 0 and down == 0 and left == 0 and right == 0 then
		a = {map[i-1][j-1].basic ~= 0 and 11 or 0,map[i-1][j+1].basic ~= 0 and 9 or 0,map[i+1][j-1].basic ~= 0 and 3 or 0,map[i+1][j+1].basic ~= 0 and 1 or 0}
	elseif up == 0 and down == 0 and left == 0 and right ~= 0 then
		a = {map[i-1][j-1].basic ~= 0 and 11 or 0,5,map[i+1][j-1].basic ~= 0 and 3 or 0,5}
	elseif up == 0 and down == 0 and left ~= 0 and right == 0 then
		a = {7,map[i-1][j+1].basic ~= 0 and 9 or 0,7,map[i+1][j+1].basic ~= 0 and 1 or 0}
	elseif up == 0 and down == 0 and left ~= 0 and right ~= 0 then
		a = {7,5,7,5}
	elseif up == 0 and down ~= 0 and left == 0 and right == 0 then
		a = {map[i-1][j-1].basic ~= 0 and 11 or 0,map[i-1][j+1].basic ~= 0 and 9 or 0,2,2}
	elseif up == 0 and down ~= 0 and left == 0 and right ~= 0 then
		a = {map[i-1][j-1].basic ~= 0 and 11 or 0,19,22,23}
	elseif up == 0 and down ~= 0 and left ~= 0 and right == 0 then
		a = {17,map[i-1][j+1].basic ~= 0 and 9 or 0,21,22}
	elseif up == 0 and down ~= 0 and left ~= 0 and right ~= 0 then
		a = {17,19,21,23}
	elseif up ~= 0 and down == 0 and left == 0 and right == 0 then
		a = {10,10,map[i+1][j-1].basic ~= 0 and 3 or 0,map[i+1][j+1].basic ~= 0 and 1 or 0}
	elseif up ~= 0 and down == 0 and left == 0 and right ~= 0 then
		a = {14,15,map[i+1][j-1].basic ~= 0 and 3 or 0,19}
	elseif up ~= 0 and down == 0 and left ~= 0 and right == 0 then
		a = {13,14,17,map[i+1][j+1].basic ~= 0 and 1 or 0}
	elseif up ~= 0 and down == 0 and left ~= 0 and right ~= 0 then
		a = {13,15,17,19}
	elseif up ~= 0 and down ~= 0 and left == 0 and right == 0 then
		a = {10,10,2,2}
	elseif up ~= 0 and down ~= 0 and left == 0 and right ~= 0 then
		a = {14,15,22,23}
	elseif up ~= 0 and down ~= 0 and left ~= 0 and right == 0 then
		a = {13,14,21,22}
	elseif up ~= 0 and down ~= 0 and left ~= 0 and right ~= 0 then
		a = {13,15,21,23}
	end
	Map.setBlock(mapLayer,i,j,a)
end

function Map.setBlock1(mapLayer,i,j)
	local a = {}
	a = {4,6,8,12}
	Map.setBlock(mapLayer,i,j,a)
	--cclog("i1 = %d,j1 = %d",mapLayer:getLayerSize().width,mapLayer:getLayerSize().height)
end

function Map.setBlock(mapLayer,i,j,a)

	local i1 = (i-2)*2
	local i2 = i1 + 1
	local j1 = (j-2)*2
	local j2 = j1 + 1
	--cclog("i1 %d,j1 %d",i1,j1)
	mapLayer:setTileGID(a[1],cc.p(j1,i1))
	mapLayer:setTileGID(a[2],cc.p(j2,i1))
	mapLayer:setTileGID(a[3],cc.p(j1,i2))
	mapLayer:setTileGID(a[4],cc.p(j2,i2))	
end

function Map.setBlockInfo(map,i,j,type,basic)
	--local i1 = (i-2)*2
	--local j2 = (j-2)*2 + 1
	local i1 = nil
	if i == 2 then
		i1 = i-3 + 1
	else
		i1 = i-3
	end
	local j2 = j-3
	local p = map:getLayer("layer"):getPositionAt(cc.p(j2,i1))
	local sprite = BlockFactory.create(basic,type)
	mapInfo[i][j].hp = type
	--mapInfo[i][j].type = basic
	if basic == 1 then
		--print("basic type ",type,basic)
		mapInfo[i][j].isEmpty = (type == 0 and 1 or 0)   --1为空，0为有
		--print("mapInfo[i][j].isEmpty",mapInfo[i][j].isEmpty)
	else
		mapInfo[i][j].isEmpty = 2
		if basic == 15 then
			mapInfo[i][j].isEmpty = 1
		end
	end
	sprite:setAnchorPoint(0.5,0.5)
	local pngSizeW = sprite:getContentSize().width
	local tileW = map:getTileSize().width
	local scale = tileW/pngSizeW 
	sprite:setScale(scale)
	sprite:setPosition(p.x+tileW/2,p.y+tileW/2)
	map:addChild(sprite)
	if i == 2 then
		local py = p.y + tileW
		local px = p.x
		sprite:setPosition(cc.p(px+tileW/2,py+tileW/2))
		return sprite
	end
	if map:getChildByTag(j-2 + (i-3)*MapWidth) ~= nil then
		--print("remove ok")
		map:removeChildByTag(j-2 + (i-3)*MapWidth,true)
	end
	sprite:setTag(j-2 + (i-3)*MapWidth)
	mapInfo[i][j].tag = j-2 + (i-3)*MapWidth
	--cclog("tag isEmpty %d",mapInfo[i][j].isEmpty)
	if mapInfo[i][j].isEmpty == 1 and type == 0 then
		sprite:removeFromParent()
		sprite = nil
	end
	--cclog("sprite tad %d",sprite:getTag())
	return sprite
end

function Map.getBlockSprite(map,i,j)
	if mapInfo[i][j].tag == nil then
		return nil
	end
	local sprite = map:getChildByTag(mapInfo[i][j].tag)
	return sprite
end
function Map.f(n,acc)
	if n < 1 then
		return acc
	end
	return Map.f(n-1,n*acc)
end

--local maps = lv:getMap()

local movePs = {} --路径存储
local needMove = 0
function Map.moveBlock(i,j,flag)
	movePs = {}
	--needMove = 0
	flagI = i
	flagJ = j
	return Map.moveBlcok(i,j,flag)
end

function Map.moveBlcok(i,j,flag) ---add a flag here
	local i1 = nil
	local j1 = nil
	table.insert(movePs,cc.p(j,i))
	needMove = needMove + 1
	--print(#movePs)
	if i == 2 then
		needMove = needMove - 1
		return movePs
	end
	if mapInfo[i][j].isEmpty ~= 1 then
		needMove = needMove - 1
		return movePs
	else
		i1 = i-1
		j1 = j
		if mapInfo[i1][j1].isEmpty == 2 then
			if j <= 7 then
				j1 = j-1
			else
				j1 = j+1
			end
			if mapInfo[i1][j1].isEmpty == 2 then
				if j > 7 then
					j1 = j-1
				else
					j1 = j+1
				end
				if mapInfo[i1][j1].isEmpty == 2 then
					mapInfo[i][j].isEmpty = 2
					
					table.remove(movePs)
					needMove = needMove - 1
					if #movePs == 0 then
						mapInfo[i][j].isEmpty = 1
						--needMove = needMove - 1
						return movePs
					end
					--print(#movePs)
					i1 = movePs[#movePs].y
					j1 = movePs[#movePs].x
					table.remove(movePs)
					needMove = needMove - 1
					
					Map.moveBlcok(i1,j1)

					mapInfo[i][j].isEmpty = 1
					--needMove = needMove - 1
					return movePs
				end
			end
		end
		if mapInfo[i1][j1].isEmpty == 0 then
			table.insert(movePs,cc.p(j1,i1))
			mapInfo[i1][j1].isEmpty = 1
			return movePs
		elseif mapInfo[i1][j1].isEmpty == 1 then
			return Map.moveBlcok(i1,j1)
		else
			needMove = needMove - 1
			return movePs
		end

	end
end

function Map.setEveryVerPath()
	local verPath = {}
	local addAtVer = {}


	for i=1,8 do
		addAtVer[i] = {}
		for j=1,10 do
			addAtVer[i][j] = j	
		end
	end

	for j=1,10 do
		verPath[j] = {}
	end

	for i=10,3,-1 do
		ii = 10 - i + 1 
		for j=3,12 do
			jj = j - 2				
			local movPath = Map.moveBlock(i,j)
			if #movPath > 1 then
				table.insert(verPath[jj],{tag = mapInfo[i][j].tag,idI = i,idJ = j,orgPos = 1,path = movPath})
			end
		end
	end
	-- for j=1,#verPath do
	-- 	for i=1,#verPath[j] do
	-- 		print("verPath[j][i]",verPath[j][i].tag,j)
	-- 	end
	-- end


	local function getKeyPosFromTable(table,i,j)
		for k = 1,#table do
			if table[k].idI == i and table[k].idJ == j then
				return k 
			end
		end
		return 1
	end

	for j=1,#verPath do
		local i = 1
		while i <= #verPath[j] do
			local vi,vj,orgPos = verPath[j][i].idI,verPath[j][i].idJ,verPath[j][i].orgPos
			--print("vi,vj",vi,vj)
			local tmpPath = verPath[j][i].path
			-- for k,v in pairs(tmpPath) do
			-- 	print(k,v.x)
			-- end
			for ii=orgPos,#tmpPath do

				local curI,curJ = tmpPath[ii].y,tmpPath[ii].x
				if ii + 1 > #tmpPath then break end
				local nextI,nextJ = tmpPath[ii + 1].y,tmpPath[ii + 1].x
				if nextI < curI and curJ ~= nextJ and nextJ-2 ~= j then
					local temp = verPath[j][i]
					temp.orgPos = ii + 1
					local toAddAtJ = addAtVer[nextI-2][nextJ-2]
					-- if j == 2 then
					-- 	print("toAddAtJ",toAddAtJ,nextI,nextJ)
					-- end
					
					table.remove(verPath[j],i)
					local pos = getKeyPosFromTable(verPath[toAddAtJ],nextI,nextJ)
					local iii,jjj = temp.idI-2,temp.idJ-2
					addAtVer[iii][jjj] = toAddAtJ
					table.insert(verPath[toAddAtJ],pos,temp)
					--print("verPath[j][i]",temp.tag,j,pos)
					i = i - 1
					break
				end
			end
			
			i = i + 1
		end	
	end	

	-- needMove = 0
	-- for j=1,#verPath do
	-- 	for i=1,#verPath[j] do
	-- 		local vi,vj = verPath[j][i].idI,verPath[j][i].idJ
	-- 		verPath[j][i].path = Map.moveBlock(vi,vj,true)
	-- 	end
	-- end
	print("function end")	
	return verPath
end



function Map.getTileCoordinateFromPos(layer,pos)
	local px,py = layer:getPosition()
	local width = layer:getMapTileSize().width
	local layerW = layer:getLayerSize().width
	local layerH = layer:getLayerSize().height
	local layerSW = width * layerW
	local layerSH = width * layerH
	local ox = px
	local oy = py + layerSH - width
	--print("ox oy",ox,oy)
	--print("pos x y",pos.x,pos.y)
	local i = math.floor((oy - pos.y)/width)
	local j = math.floor((pos.x - ox)/width)
	return i+2,j+1
end


function Map.getTileCoordinateFromSprite(sprite)
	local posX,posY = sprite:getPosition()
    --local pos = cc.p(posX,posY)
    local layer =  sprite:getParent():getLayer("layer")
	local px,py = layer:getPosition()
	local width = layer:getMapTileSize().width
	local layerW = layer:getLayerSize().width
	local layerH = layer:getLayerSize().height
	local layerSW = width * layerW
	local layerSH = width * layerH
	local ox = px
	local oy = py + layerSH - width
	--print("ox oy",ox,oy)
	--print("pos x y",pos.x,pos.y)
	local i = math.floor((oy - posY)/width)
	local j = math.floor((posX - ox)/width)
	if tostring(i) == "nan" then
		print("i is nan from the map",width,oy,sprite:getPosition())
	end
	return i+2,j+1
end

function Map.isWeakOther(mapbg)
	if Map.existBomb == true then return end
	if countWeakOther > 0 then
		local co = coroutine.create(function()
			GameState = GameStateDroping
			for i=1,countWeakOther do
					Map.getBlockSprite(mapbg,targetWeakOther[i].x,targetWeakOther[i].y):result()
			end
			coroutine.yield()				
		end)
		coroutine.resume(co)
	end
end

function Map.drop(mapbg)
	print("now Drop")
	Map.dirTime = 0.2
	GameState = GameStateDroping
	needMove = 0
	if Map.existBomb == true then
		mapInfo[Map.BombI][Map.BombJ].isEmpty = 2
	end
	local function first()
		if Map.existBomb == true then
			Map.bombType = 0
			local sprite
			local function h()
				if Map.bombH ~= 0 then
					audio:playEffect("audio/SND022.mp3")
					Map.circlesMoveH(Map.bombHI,mapbg,Map.dirTime*2)
					local function bombCreate()
						Map.bombType = Map.bombType + Map.bombH
						local sprite =  Map.setBlockInfo(mapbg,Map.BombI,Map.BombJ,Map.bombType,15)
						sprite:setLocalZOrder(dirZOrder+1)
					end
					local bCBack = cc.CallFunc:create(bombCreate)
					local delay = cc.DelayTime:create(Map.dirTime)
					mapbg:runAction(cc.Sequence:create(delay,bCBack))
				end
			end
			local function v()
				if Map.bombV ~= 0 then
					audio:playEffect("audio/SND022.mp3")
					Map.circlesMoveV(Map.bombVI,mapbg,Map.dirTime*2)
					local function bombCreate()
						Map.bombType = Map.bombType + Map.bombV

						local sprite =  Map.setBlockInfo(mapbg,Map.BombI,Map.BombJ,Map.bombType,15)
						sprite:setLocalZOrder(dirZOrder+1)
						print("Map.bombType",Map.bombType)
					end
					local bCBack = cc.CallFunc:create(bombCreate)
					local delay = cc.DelayTime:create(Map.dirTime)
					mapbg:runAction(cc.Sequence:create(delay,bCBack))
				end
			end
			local function s()
				if Map.bombS ~= 0 then
					audio:playEffect("audio/SND022.mp3")
					Map.circlesMoveS(Map.bombSI,mapbg,Map.dirTime*2)
					local function bombCreate()
						Map.bombType = Map.bombType + Map.bombS
						local sprite =  Map.setBlockInfo(mapbg,Map.BombI,Map.BombJ,Map.bombType,15)
						sprite:setLocalZOrder(dirZOrder+1)
					end
					local bCBack = cc.CallFunc:create(bombCreate)
					local delay = cc.DelayTime:create(Map.dirTime)
					mapbg:runAction(cc.Sequence:create(delay,bCBack))
				end
			end
			local H = cc.CallFunc:create(h)
			local V = cc.CallFunc:create(v)
			local S = cc.CallFunc:create(s)
	        local _delayh = Map.bombH ~= 0 and cc.DelayTime:create(Map.dirTime) or cc.DelayTime:create(0)
	        local _delayv = Map.bombV ~= 0 and  cc.DelayTime:create(Map.dirTime) or cc.DelayTime:create(0)
	        local _delays = Map.bombS ~= 0 and  cc.DelayTime:create(Map.dirTime) or cc.DelayTime:create(0)

	        Map.delayBomb = (Map.bombH + Map.bombV/2 + Map.bombS/4) * Map.dirTime

			mapbg:runAction(cc.Sequence:create(H,_delayh,V,_delayv,S,_delays))
			-- audio:playEffect("audio/SND022.mp3")
			mapInfo[Map.BombI][Map.BombJ].isEmpty = 2
	    end
	end
	
	-- ---
	-- 	local function second()
	-- 		local mov = {}
	-- 		local layerBG = mapbg:getLayer("layer")
	-- 		local tileW = layerBG:getMapTileSize().width/2
	-- 		--print("mapInfo[7][10].hp",mapInfo[7][10].hp)

	-- 	-- 	local verPaths = Map.setEveryVerPath()


	-- 		for i=10,3,-1 do
	-- 			mov[10-i+1] = {}
	-- 			for j=3,12 do --maxx-2
	-- 				local movePs
	-- 				local co = coroutine.create(
	-- 				function()
	-- 					movePs = Map.moveBlock(i,j)
	-- 					--print("coroutine",j - 2 + (i - 3)*MapWidth)
	-- 					coroutine.yield()				
	-- 				end)
	-- 				coroutine.resume(co)
	-- 				local n = #movePs
	-- 				--print(table.getn(Map.moveBlcok(9,4)))
	-- 				--print("movePs n ",n)
	-- 				local moveAction = {}
					
	-- 				if n > 1 then
						
	-- 					--print(movePs[n].y)
	-- 					local sprite = nil
	-- 					local i1,j1 = movePs[n].y,movePs[n].x

	-- 					local n = #movePs
						

	-- 					if i1 == 2 then
	-- 						--print("mapInfo[i1][j1].isEmpty i1 j1",i1,j1,mapInfo[i1][j1].isEmpty)
	-- 						if mapbg:getChildByTag(mapInfo[i][j].tag) ~= nil then
	-- 							mapbg:removeChildByTag(mapInfo[i][j].tag)
	-- 						end

	-- 						sprite = Map.setBlockInfo(mapbg,i1,j1,5,1)
							
	-- 					else
	-- 						--print("mapInfo.isEmpty",movePs[n].y,movePs[n].x)
	-- 						sprite =  Map.getBlockSprite(mapbg,i1,j1)
	-- 					end	
	-- 					mapInfo[i][j].isEmpty = 0				
	-- 					mapInfo[i][j].hp = sprite.itemType
	-- 					sprite.itemType = mapInfo[i][j].hp
	-- 					if i == 9 and j == 3 then
	-- 						--print("germ type 1",sprite.itemType)
	-- 					end
	-- 					sprite:setTag(mapInfo[i][j].tag)
	-- 					--print("mapInfo.isEmpty",i,j)
	-- 					--sprite:runAction(cc.DelayTime:create(0.01*(j-4)))
	-- 					--print(sprite:getPosition())
	-- 					--local sprite = Map.getBlockSprite(self.mapbg,3,movePs[n].y)			
	-- 					moveAction = {}
						
	-- 					mov[10-i+1][j-2] = n-1
	-- 					local function dropCallBack()
	-- 						--print("mov[j-3]",j,mov[j-2])
	-- 						if mov[10-i+1][j-2] == 0 then
	-- 							return
	-- 						end
	-- 						--sprite:runAction(cc.DelayTime:create(0.5*(j-4)))
	-- 						local ix,iy = movePs[mov[10-i+1][j-2]].x,movePs[mov[10-i+1][j-2]].y
	-- 						local px = ix - 3
	-- 						local py = iy - 3
	-- 						--print("px py i",px,py,i)
									
	-- 						if mapInfo[iy][ix].moveflag == false then
	-- 							mapInfo[iy][ix].moveflag = true	
	-- 							--delay = cc.DelayTime:create(0.01)
	-- 							local p = layerBG:getPositionAt(cc.p(px,py))

	-- 							moveto = cc.MoveTo:create(Map.dirTime,cc.p(p.x+tileW,p.y+tileW))
	-- 							function call()
	-- 								mov[10-i+1][j-2] = mov[10-i+1][j-2] -1
	-- 								mapInfo[iy][ix].moveflag = false
	-- 								needMove = needMove - 1
	-- 								--print("needMove",needMove)
	-- 								if needMove <= 0 then
	-- 									Map.checkBomb(mapbg) 
	-- 									print("2 second")
	-- 								end
	-- 							end
	-- 							caback = cc.CallFunc:create(call)
	-- 							sprite:runAction(cc.Sequence:create(moveto,caback))
	-- 						else
	-- 							--print("here killed")				
	-- 						end
	-- 						delay = cc.DelayTime:create(1.01*Map.dirTime)
	-- 						sprite:runAction(cc.Sequence:create(delay,cc.CallFunc:create(dropCallBack)))				
	-- 					end
	-- 					dropCallBack()
	-- 				else
	-- 					if i == 3 and j == 12 and needMove <= 0 then
							
	-- 						Map.checkBomb(mapbg)
	-- 						print("1 first")
	-- 					end 
	-- 				end
	-- 			end
	-- 		end
	-- 	end

	local function second()
		local mov = {}
		local layerBG = mapbg:getLayer("layer")
		local tileW = layerBG:getMapTileSize().width/2
		--print("mapInfo[7][10].hp",mapInfo[7][10].hp)
		
		local verPaths = Map.setEveryVerPath()
		-- for j=1,#verPaths do
		-- 	for i=1,#verPaths[j] do
		-- 		print("verPaths",verPaths[j][i].tag,j)
		-- 	end
		-- end
		--print("verPaths",verPaths[1][3].path)
		--needMove = 0
		local breakFlag = false
		for j=1,#verPaths do --maxx-2
			mov[j] = {}
			for i=1,#verPaths[j] do
				local movePs,tag

				local co = coroutine.create(
				function()
					tag = verPaths[j][i].tag
					ii,jj = verPaths[j][i].idI,verPaths[j][i].idJ
					movePs = verPaths[j][i].path
					--print("coroutine",j - 2 + (i - 3)*MapWidth)
					coroutine.yield()				
				end)
				coroutine.resume(co)

				if movePs == nil then
					print("ver i j ",i,j,tag)
				end
				local n = #movePs

				
				if n > 1 then
					
					--print(movePs[n].y)
					local sprite = nil
					local i1,j1 = movePs[n].y,movePs[n].x

					if i1 == 2 then
						--print("mapInfo[i1][j1].isEmpty i1 j1",i1,j1,mapInfo[i1][j1].isEmpty)
						-- if mapbg:getChildByTag(tag) ~= nil then
						-- 	mapbg:removeChildByTag(tag)
						-- end

						sprite = Map.setBlockInfo(mapbg,i1,j1,5,1)
						
					else
						
						sprite =  Map.getBlockSprite(mapbg,i1,j1)
						if sprite == nil then
							print("mapInfo.isEmpty",movePs[n].y,movePs[n].x,n)
						end
					end	
					mapInfo[ii][jj].isEmpty = 0				
					mapInfo[ii][jj].hp = sprite.itemType
					sprite.itemType = mapInfo[ii][jj].hp

					

					
					mov[j][i] = n-1
					local function dropCallBack()
						--print("mov[j-3]",j,mov[j-2])
						if mov[j][i] == 0 then
							sprite:setTag(tag)
							return
						end
						if breakFlag == true then
							sprite:setTag(tag)
							return
						end
						--sprite:runAction(cc.DelayTime:create(0.5*(j-4)))
						local ix,iy = movePs[mov[j][i]].x,movePs[mov[j][i]].y
						local px = ix - 3
						local py = iy - 3
						--print("px py i",px,py,i)
								
						if mapInfo[iy][ix].moveflag == false then
							mapInfo[iy][ix].moveflag = true	
							--delay = cc.DelayTime:create(0.01)
							local p = layerBG:getPositionAt(cc.p(px,py))

							moveto = cc.MoveTo:create(Map.dirTime,cc.p(p.x+tileW,p.y+tileW))
							function call()
								mov[j][i] = mov[j][i] -1
								mapInfo[iy][ix].moveflag = false
								needMove = needMove - 1
								--print("needMove",needMove)
								if needMove <= 0 then
									print("began check")
									Map.checkBomb(mapbg)
									breakFlag = true
								end
							end
							caback = cc.CallFunc:create(call)
							sprite:runAction(cc.Sequence:create(moveto,caback))
						else
							--print("here killed")				
						end
						delay = cc.DelayTime:create(1.01*Map.dirTime)
						sprite:runAction(cc.Sequence:create(delay,cc.CallFunc:create(dropCallBack)))				
					end
					dropCallBack()
				end
			end
			if breakFlag == true then
				break
			end
			if j == #verPaths and needMove <= 0 then
				breakFlag = true
				print("began check")
				Map.checkBomb(mapbg)
			end 
		end

	end



	local firstBack = cc.CallFunc:create(first)
	local secondBack = cc.CallFunc:create(second)
	--local m_delay = cc.DelayTime:create(Map.dirTime*2)
	local seq = cc.Sequence:create(firstBack,secondBack)
	mapbg:runAction(seq)
	
	--[[
	print("Map.existBomb",Map.existBomb)
	if  Map.existBomb == false  then
		if mapbg:getParent():win() == false then
			mapbg:getParent():lose()
		end
	end
	]]--
end

function Map.createHintText(gameScene)
	local key = havStep + gameScene._levelType*100
    local text = hintText:getHintTextByKey(key)
    if gameScene:getChildByTag(5000) ~= nil and text ~= nil then
    	gameScene:getChildByTag(5000):appear(text)
    else    	
	    local hintLayer = HintDialog.create(text)
	    if hintLayer ~= nil then
	    	gameScene:addChild(hintLayer)
	    	gameScene:getChildByTag(5000):appear(text)
	    end
	end
		
end

function Map.addHintHand(mapbg)
	local gameScene = mapbg:getParent()
	local hints = lv:getHintPoint()
	if hints == false then
		return
	end
	if hints[havStep+1] ~= nil then
   		local i,j = hints[havStep+1].y,hints[havStep+1].x
   		i,j = i+3,j+3
   		print("i,j",i,j)
    	local sp = Map.getBlockSprite(mapbg,i,j)
    	if sp ~= nil then
			ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniHand)
	   		local armature =  ccs.Armature:create("handAnimation")
	   		local p = cc.pAdd(cc.p(sp:getPosition()),cc.p(mapbg:getPosition()))
	   		armature:setAnchorPoint(0.25,0.75)
	   		armature:getAnimation():play("hintHand")  	
		    armature:setPosition(p)
		    armature:setScale(sp:getScale())    
		    gameScene:addChild(armature,gameScene:getLocalZOrder()+mapbg:getLocalZOrder()+1,5002)
		else
			print("sp is nil")
		end
	end
end

function Map.addMagicHintHand(mapbg,magicType)
	local gameScene = mapbg:getParent()

	local p

	if magicType == magicCross then
		p = gameScene.toolCge:getWorldPosition()
	elseif magicType == magicSame then
		p = gameScene.toolCln:getWorldPosition()
	elseif magicType == magicLine then
		p = gameScene.toolHor:getWorldPosition()
	elseif magicType == magicRow then
		p = gameScene.toolVtl:getWorldPosition()
	end

	ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(jsonAniHand)
	local armature =  ccs.Armature:create("handAnimation")
	--local p = cc.pAdd(cc.p(sp:getPosition()),cc.p(mapbg:getPosition()))
	armature:setAnchorPoint(0.25,0.75)
	armature:getAnimation():play("hintHand")  	
    armature:setPosition(p)
    local scale = gameScene.toolVtl:getContentSize().width / gameScene.toolBar:getContentSize().width
    armature:setScale(scale)    
    gameScene:addChild(armature,gameScene:getLocalZOrder()+mapbg:getLocalZOrder()+1,5002)

end



function Map.checkBomb(mapbg)
	local gameScene = mapbg:getParent()
	
    

	local function weakother()
		Map.isWeakOther(mapbg)
	end
	
	local function checkB()
		if Map.existBomb ~= true then
			GameState = (GameState ~= GameStateLose and GameState ~= GameStateWin) and GameStateWaiting or GameStateLose
			local germ4Exist,germExists =  Map.checkBombExist(mapbg)
			Map.germExists = germExists
			--print("here killed hehe",germExists)

			--胜负判断
			if gameScene:win() == true then  return end
			if gameScene:lose() == true then return end
			
			local magicType = lv:getMagicType()
			if magicType == false then
				--if gameScene.MagicClicked == true then
					print("why add here")
					Map.createHintText(gameScene)
					Map.addHintHand(mapbg)
				--end
			else
				if havStep == 0 and gameScene.MagicClicked == nil then
					gameScene.magicType = magicType
					gameScene.MagicClicked = true
					gameScene.toolClicked = true
					gameScene.toolBar:setEnabled(gameScene.toolClicked)
					Map.createHintText(gameScene)
					if gameScene.magHintFlag == true then
						Map.addMagicHintHand(mapbg,magicType)
					end
				elseif havStep ~= 0 and gameScene.MagicClicked == true then
					Map.createHintText(gameScene)
					Map.addHintHand(mapbg)
				end
			end
			if germ4Exist == false and tonumber(gameScene.numClicks) ~= 0 and germExists > 0 then
				while true do
					math.randomseed(socket.gettime())
					local i = math.random(8)+2
					local j = math.random(10)+2
					local sp = Map.getBlockSprite(mapbg,i,j)
					if sp ~= nil and sp.isMask == false and sp:isGerm() == true then
						sp:updateToType4()	
						break
					end
				end
			end
			if germExists <= 0 then 
				if gameScene:isWin() == false then
					if lv:getTarget().typ == 1 and totalScore >= tonumber(lv:getScoreTarget()[1]) then
						print("2 second")
						GameState = GameStateWin
						--gameScene:dialog(GameState)
						gameScene:bounsTime()
					end
					GameState = GameStateLose
					print("you lose 1")
					local Dlg =  LoseDialog.create(gameScene._levelType)
					gameScene:addChild(Dlg)
				else
					print("3 tirth")
					gameScene:win()
				end
			end
			finishDropTime = socket.gettime()
			local function checkNeedHint()
				if gameScene.checkWhetherNeedHint then
					gameScene:checkWhetherNeedHint()
				end
			end
			--local checkHintB = cc.CallFunc:create(checkNeedHint)
			if gameScene.entry == nil then
				gameScene.entry  = schedule:scheduleScriptFunc(checkNeedHint,1,false)
			else
				--print("gameScene.entry",gameScene.entry)
			end
			
		else
			print("GameState2",GameState,Map.BombI,Map.BombJ)
			local sp = Map.getBlockSprite(mapbg,Map.BombI,Map.BombJ)
			if sp == nil then
				local function spCreate()
					local sp = Map.getBlockSprite(mapbg,Map.BombI,Map.BombJ)
					sp:beHited()
				end
				spC = cc.CallFunc:create(spCreate)
				gameScene:runAction(cc.Sequence:create(cc.DelayTime:create(Map.dirTime*2),spC))
			else
				sp:beHited()
			end
			--Map.isWeakOther(mapbg)
			
			--mapInfo[Map.BombI][Map.BombJ].isEmpty = 1
		end		
	end

	local weak = cc.CallFunc:create(weakother)
	local check = cc.CallFunc:create(checkB)
	local delay = countWeakOther>0 and cc.DelayTime:create(1.4) or cc.DelayTime:create(0)
	local seq = cc.Sequence:create(weak,delay,check)
	gameScene:runAction(seq)
	--print("wobuxianghuola")
end

function Map.checkBombExist(mapbg)
	local type4Exist = false
	local germExist = 0
	for i=3,10 do
		for j=3,12 do --maxx-2
			local sprite = Map.getBlockSprite(mapbg,i,j)
			if sprite ~= nil and sprite:isGerm() then
				--print("sp type i j",sprite.itemType,i,j)
				germExist = germExist + 1
				sprite:removeAllChildren()
			end
			if sprite ~= nil and sprite:isType4() then
				type4Exist = true
				if not (getClickedIndex() == 1 and getClickedLevel() <= 5) == true then
					local bombType = sprite:isH()+sprite:isV()+sprite:isS()
					if bombType ~= 0 then
						--print("bombType",bombType)
						local bombHint = cc.Sprite:create(string.format(pngSjtHint,bombType))
						sprite:addChild(bombHint)
						bombHint:setPosition(sprite:getContentSize().width/2,sprite:getContentSize().height/2)
						local blink = cc.FadeIn:create(0.5)
						local rep = cc.RepeatForever:create(cc.Sequence:create(blink,blink:reverse()))
						bombHint:runAction(rep)
						if bombType == 7 then
							local big = cc.ScaleTo:create(0.5,1.1)
							local small = cc.ScaleTo:create(0.5,1)
							local rep1 = cc.RepeatForever:create(cc.Sequence:create(big,small))
							bombHint:runAction(rep1)
						end
					end
				end
			end
		end
	end
	return type4Exist,germExist
end


function Map.circlesMoveH(p,mapbg,dTime)
    local i,j = Map.BombI,Map.BombJ
    if j-p < 3 then
        return false
    end

    for k=j-p,j-p+3 do
        local bombHint = cc.Sprite:create(string.format(pngSjtHint,1))
        mapbg:addChild(bombHint)
        local pngSizeW = bombHint:getContentSize().width
		local tileW = mapbg:getTileSize().width
		local scale = tileW/pngSizeW 
		local padd = cc.p(tileW/2,tileW/2) 
		bombHint:setScale(scale)
		bombHint:setPosition(cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(k-3,i-3)),padd))
		local moveto = cc.MoveTo:create(dTime,cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(j-3,i-3)),padd))
		local function remove()
			bombHint:removeFromParent()
		end
		local remBack = cc.CallFunc:create(remove)
		local delay = cc.DelayTime:create(dTime)

		bombHint:runAction(cc.Sequence:create(moveto,delay,remBack))
    end
    
end

function Map.circlesMoveV(p,mapbg,dTime)
    local i,j = Map.BombI,Map.BombJ
    if i-p < 3 then
        return false
    end
    for k=i-p,i-p+3 do
        local bombHint = cc.Sprite:create(string.format(pngSjtHint,2))
		mapbg:addChild(bombHint)
		local pngSizeW = bombHint:getContentSize().width
		local tileW = mapbg:getTileSize().width
		local scale = tileW/pngSizeW 
		local padd = cc.p(tileW/2,tileW/2) 
		bombHint:setScale(scale)
		bombHint:setPosition(cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(j-3,k-3)),padd))
		local moveto = cc.MoveTo:create(dTime,cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(j-3,i-3)),padd))
		local function remove()
			bombHint:removeFromParent()
		end
		local remBack = cc.CallFunc:create(remove)
		local delay = cc.DelayTime:create(dTime)
		bombHint:runAction(cc.Sequence:create(moveto,delay,remBack))
    end
end

function Map.circlesMoveS(p,mapbg,dTime)
    local i,j = Map.BombI,Map.BombJ
    local pnt = {cc.p(1,1),cc.p(0,1),cc.p(1,0),cc.p(0,0)}
    local pi,pj = pnt[p].x,pnt[p].y
    if j-pj < 3 then
        return false
    end
    if i-pi < 3 then
        return false
    end
    for k=i-pi,i-pi+1 do
        for l=j-pj,j-pj+1 do
            local bombHint = cc.Sprite:create(string.format(pngSjtHint,4))
			mapbg:addChild(bombHint)
			local pngSizeW = bombHint:getContentSize().width
			local tileW = mapbg:getTileSize().width
			local scale = tileW/pngSizeW
			local padd = cc.p(tileW/2,tileW/2) 
			bombHint:setScale(scale)
			bombHint:setPosition(cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(l-3,k-3)),padd))
			local moveto = cc.MoveTo:create(dTime,cc.pAdd(mapbg:getLayer("layer"):getPositionAt(cc.p(j-3,i-3)),padd))
			local function remove()
				bombHint:removeFromParent()
			end
			local remBack = cc.CallFunc:create(remove)
			local delay = cc.DelayTime:create(dTime)
			bombHint:runAction(cc.Sequence:create(moveto,delay,remBack))
        end
    end
end

