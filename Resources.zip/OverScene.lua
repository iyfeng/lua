local director = cc.Director:getInstance()
local audioEngine = cc.SimpleAudioEngine:getInstance()
local schedulerEntry = nil
local scheduler = director:getScheduler()


OverScene = class("OverScene",
	function ()
		return cc.LayerColor:create(cc.c4b(255,255,255,255))
	end
	)
OverScene.__index = OverScene

function OverScene:createOS(str)
	local overScene = OverScene.new()
	overScene:myInit(str)
	return overScene
end

function OverScene:myInit(str)
	local winSize = director:getWinSize()
	local fonT = cc.LabelTTF:create(str, "Verdana-BoldItalic", 32)
	fonT:setPosition(winSize.width/2,winSize.height/2)
	fonT:setColor(cc.c3b(0,0,0))
	self:addChild(fonT)
	self._fonT = fonT

	local function onNodeEvent(event)
		if event=="cleanup" then
		    self._fonT =  nil
		end
    end
  	self:registerScriptHandler(onNodeEvent)

  	function changeScene()
  		self:changeScene()
  	end

  	self:runAction(cc.Sequence:create(cc.DelayTime:create(5),cc.CallFunc:create(changeScene)))
end

function OverScene:changeScene()
	local scene = cc.Scene:create()
	require "MainScene"
	--local layer = MainScene:createMS()
	scene:addChild(MainScene:createMS())
	director:replaceScene(scene)
end
