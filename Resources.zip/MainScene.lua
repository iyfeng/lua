require "extern"
require "hello2"

local function function_name( ... )
	-- body
end 

local director = cc.Director:getInstance()
local audioEngine = cc.SimpleAudioEngine:getInstance()
local schedulerEntry = nil
local scheduler = director:getScheduler()


MainScene = class("MainScene",
	function ()
		return cc.LayerColor:create(cc.c4b(255,255,255,255))
	end
	)
MainScene.__index = MainScene

function MainScene:createMS()
	local mainScene = MainScene.new()
	mainScene:myInit()
	return mainScene
end

function MainScene:myInit()
	local bRet = false
	repeat
		--[[
		if not self:initWithColor(cc.c4b(255,255,255,255)) then
			break
		end
		--]]
		--the close button
		local closeItem = cc.MenuItemImage:create("hd/CloseNormal.png","hd/CloseSelected.png")
		local function menuCloseCallback()
			self:menuCloseCallback()
		end

		
		closeItem:registerScriptTapHandler(menuCloseCallback)

		visibleSize = director:getVisibleSize()
		origin = director:getVisibleOrigin()

		closeItem:setPosition(origin.x + visibleSize.width - closeItem:getContentSize().width/2,
							origin.y + closeItem:getContentSize().height/2)
		local menu = cc.Menu:create(closeItem)
		menu:setPosition(0,0)
		if not menu then
			break
		end
		self:addChild(menu,1)

		--the player sprite
		player = cc.Sprite:create("hd/Player.png")
		player:setPosition(origin.x + player:getContentSize().width/2,origin.y + visibleSize.height/2)
		if not player then 
			break
		end
		self:addChild(player)

		--add Target
		local targets = {}
		local projectiles = {}

		self._targets = targets
		self._projectiles = projectiles
		self._projectilesDestroyed = 0

		--LayerCallBack
		local function onLayerEvent(event)
			--cclog("game event: "..event)
			if event == "cleanup" then
				self:myCleanUp()
			elseif event == "exit" then
				self:myOnExit()
			elseif event == "enter" then
				self:myOnEnter()
			end
		end
		self:registerScriptHandler(onLayerEvent)

		--TouchCallBack
		local function onTouchBegan(x, y)
            --cclog("onTouchBegan: %0.2f, %0.2f", x, y)
            -- CCTOUCHBEGAN event must return true
            return true
        end

        local function onTouchMoved(x, y)
            --cclog("onTouchMoved: %0.2f, %0.2f", x, y)
        end

        local function onTouchEnded(x, y)
            --cclog("onTouchEnded: %0.2f, %0.2f", x, y)
            self:myOnTouchEnded(x,y)
        end

		local function onLayerTouch(event,x,y)
			--cclog("game Touched Event:\n")
			if event == "began" then
				return onTouchBegan(x,y)
			elseif event == "moved" then
				return onTouchMoved(x,y)
			elseif event == "ended" then
				return onTouchEnded(x,y) 
				--return self:myOnTouchEnded(x,y)
			end
		end
		self:setTouchEnabled(true)
		self:registerScriptTouchHandler(onLayerTouch)

		--updateCallBack
		local function update( dt )
			self:updateGame(dt)
		end
		self:scheduleUpdateWithPriorityLua(update,0)

		--cclog("gameLayer inited")
		bRet = true
	until bRet
	return bRet
end

function MainScene:menuCloseCallback()
	director:endToLua()
end

function MainScene:addTarget()
	
	--add target
	local target = cc.Sprite:create("hd/Target.png")
	local winSize = director:getVisibleSize()
	local minY = target:getContentSize().height/2
	local maxY = winSize.height - target:getContentSize().height/2
	local actualY = math.random(minY,maxY)
	target:setPosition(winSize.width + target:getContentSize().width/2 ,
					director:getVisibleOrigin().y+ actualY)
	self:addChild(target)

	--set speed
	local actualDuration = math.random(2,4)

	--create the actions
	local function spriteMoveFinished(sender)
		self:spriteMoveFinished(sender)
	end
	local actionMove = cc.MoveTo:create(actualDuration,cc.p(0 - target:getContentSize().width/2,actualY))
	local actionMoveDone = cc.CallFunc:create(spriteMoveFinished)
	target:runAction(cc.Sequence:create(actionMove,actionMoveDone))

	--add to targets
	target:setTag(1)
	table.insert(self._targets,target)

	--cclog("target added")

end

function MainScene:spriteMoveFinished(sender)	--maybe use tolua.cast(x,”CCSprite”)
	--cclog("ok lets move")
	self:removeChild(sender,true)
	if sender:getTag() == 1 then
		for i,v in ipairs(self._targets) do
			if v == sender then
				table.remove(self._targets,i)
			end
		end
		--goto gameover scene
		self:changeScene("You Lose")
	elseif sender:getTag() == 2 then
		for i,v in ipairs(self._projectiles) do
			if v == sender then
				table.remove(self._projectiles,i)
			end
		end
	end
end

function MainScene:gameLogic(dt)
	self:addTarget()
end

function MainScene:updateGame(dt)
	local projectilesToDelete = {}

	for i,it in ipairs(self._projectiles) do
		local projectile = it
		--cclog("x:%f,y:%f",projectile:getPosition())
		local projectileRect = cc.rect(projectile:getPositionX() - projectile:getContentSize().width/2,
								projectile:getPositionY() - projectile:getContentSize().height/2,
								projectile:getContentSize().width,
								projectile:getContentSize().height)

		local targetsToDelete = {}

		for j,jt in ipairs(self._targets) do
			local target = jt
			local targetRect = cc.rect(target:getPositionX() - target:getContentSize().width/2,
								target:getPositionY() - target:getContentSize().height/2,
								target:getContentSize().width,
								target:getContentSize().height)
			--cclog(tracebackex())
			--cclog("targetRect x:%f,y:%f,width:%f,height:%f",targetRect.x,targetRect.y,targetRect.width,targetRect.height)
			--cclog("projectileRect x:%f,y:%f,width:%f,height:%f",projectileRect.x,projectileRect.y,projectileRect.width,projectileRect.height)
			--if targetRect:intersectsRect(projectileRect) then
			if math.abs(targetRect.x - projectileRect.x) <= math.min(targetRect.width,projectileRect.width) 
				and math.abs(targetRect.y - projectileRect.y) <= math.min(targetRect.height,projectileRect.height) then
				table.insert(targetsToDelete,target)
			end
		end

		for k,kt in ipairs(targetsToDelete) do
			local target = kt
			removeChildFromTable(self._targets,target)
			self:removeChild(target,true)
			self._projectilesDestroyed = self._projectilesDestroyed + 1
			cclog("destoryed: %d",self._projectilesDestroyed)
			if self._projectilesDestroyed >= 5 then
				self:changeScene("You Win")
			end
		end

		if getCount(targetsToDelete) > 0 then
			table.insert(projectilesToDelete,projectile)
		end
		targetsToDelete = nil		
	end

	for l,lt in ipairs(projectilesToDelete) do
		local projectile = lt
		removeChildFromTable(self._projectiles,projectile)
		self:removeChild(projectile,true)
	end

	projectilesToDelete = nil
end

function MainScene:myOnTouchEnded(x,y)
	--cclog("clicked x: %f,y:,%f",x,y)

	--set up inital location of projectile
	local winSize = director:getVisibleSize()
	local origin = director:getVisibleOrigin()
	local projectile = cc.Sprite:create("hd/Projectile.png")
	projectile:setPosition(origin.x + 20,origin.y + winSize.height/2)
	
	--cclog(projectile)
	--cclog(tracebackex())
	local x11 = projectile:getPositionX()
	local y11 = projectile:getPositionY()
	--cclog(tracebackex())
	cclog("projectile position x:%f y:%f",x11,y11)
	local offX = x - x11
	local offY = y - y11

	if offX <= 0 then 
		return
	end
	self:addChild(projectile)
	--cclog("projectile added")

	local realX = origin.x + winSize.width + projectile:getContentSize().width/2 --maybe use x
	local ratio = offY / offX
	local realY = realX * ratio + projectile:getPositionY()

	local offRealX = realX - projectile:getPositionX()
	local offRealY = realY - projectile:getPositionY()
	local length = math.sqrt(offRealX,offRealY)
	local velocity = winSize.width/2

	local realMoveDuration = length/velocity

	--actions set
	--cclog("start move")
	local function spriteMoveFinished(sender)
		self:spriteMoveFinished(sender)
	end
	--cclog("move finished")
	projectile:runAction(cc.Sequence:create(cc.MoveTo:create(realMoveDuration,cc.p(realX,realY)),
		cc.CallFunc:create(spriteMoveFinished)))	

	projectile:setTag(2)
	table.insert(self._projectiles,projectile)
	audioEngine:playEffect("pew-pew-lei.wav")
	

end

function MainScene:myCleanUp()
	self._targets = nil
	self._projectiles =nil
end

function MainScene:myOnEnter()
	audioEngine:playBackgroundMusic("background-music-aac.wav",true)

	function gameLogic(dt)
		self:gameLogic(dt)
	end
	schedulerEntry = scheduler:scheduleScriptFunc(gameLogic, 1.0, false)
end

function MainScene:myOnExit()
	--audioEngine:end()
	scheduler:unscheduleScriptEntry(schedulerEntry)
end

function MainScene:changeScene(title)
	local scene = cc.Scene:create()
    --local fonT = cc.LabelTTF:create(title, "Verdana-BoldItalic", 20)
    --fonT:setPosition(50,100)
    --scene:addChild(fonT)
    require "OverScene"
    local overLayer = OverScene:createOS(title)
    scene:addChild(overLayer)
    director:replaceScene(scene)
end